-- =====================================================================
-- Reglas de oro: triggers, funciones y vistas de reportes
-- =====================================================================
BEGIN;

-- ---------------------------------------------------------------------
-- 3.1 Soft delete obligatorio: se prohíbe el DELETE físico en todas las tablas
-- ---------------------------------------------------------------------
CREATE OR REPLACE FUNCTION fn_prohibir_delete() RETURNS trigger AS $$
BEGIN
  RAISE EXCEPTION 'DELETE físico prohibido en "%". Use soft delete (eliminado_en / estado).', TG_TABLE_NAME;
END $$ LANGUAGE plpgsql;

DO $$
DECLARE t TEXT;
BEGIN
  FOR t IN SELECT tablename FROM pg_tables WHERE schemaname = 'public' LOOP
    EXECUTE format('CREATE TRIGGER trg_%s_no_delete BEFORE DELETE ON %I FOR EACH ROW EXECUTE FUNCTION fn_prohibir_delete()', t, t);
  END LOOP;
END $$;

-- La bitácora es inmutable
CREATE OR REPLACE FUNCTION fn_bitacora_inmutable() RETURNS trigger AS $$
BEGIN
  RAISE EXCEPTION 'bitacora_auditoria es inmutable';
END $$ LANGUAGE plpgsql;
CREATE TRIGGER trg_bitacora_no_update BEFORE UPDATE ON bitacora_auditoria
  FOR EACH ROW EXECUTE FUNCTION fn_bitacora_inmutable();

-- ---------------------------------------------------------------------
-- 3.2 Auditoría: actualizado_en automático
-- ---------------------------------------------------------------------
CREATE OR REPLACE FUNCTION fn_set_actualizado_en() RETURNS trigger AS $$
BEGIN
  NEW.actualizado_en := NOW();
  RETURN NEW;
END $$ LANGUAGE plpgsql;

DO $$
DECLARE t TEXT;
BEGIN
  FOR t IN SELECT table_name FROM information_schema.columns
           WHERE table_schema = 'public' AND column_name = 'actualizado_en' LOOP
    EXECUTE format('CREATE TRIGGER trg_%s_actualizado_en BEFORE UPDATE ON %I FOR EACH ROW EXECUTE FUNCTION fn_set_actualizado_en()', t, t);
  END LOOP;
END $$;

-- ---------------------------------------------------------------------
-- 11. Superusuario intocable (roles con es_sistema = TRUE y sus usuarios)
-- ---------------------------------------------------------------------
CREATE OR REPLACE FUNCTION fn_proteger_rol_sistema() RETURNS trigger AS $$
BEGIN
  IF OLD.es_sistema THEN
    RAISE EXCEPTION 'El rol "%" es de sistema y no se puede modificar', OLD.nombre;
  END IF;
  RETURN NEW;
END $$ LANGUAGE plpgsql;
CREATE TRIGGER trg_roles_proteger BEFORE UPDATE ON roles
  FOR EACH ROW EXECUTE FUNCTION fn_proteger_rol_sistema();

CREATE OR REPLACE FUNCTION fn_proteger_usuario_sistema() RETURNS trigger AS $$
BEGIN
  IF EXISTS (SELECT 1 FROM roles r WHERE r.id = OLD.rol_id AND r.es_sistema)
     -- solo se permite registrar login (ultimo_acceso / intentos)
     AND (NEW.username, NEW.password_hash, NEW.rol_id, NEW.estado, NEW.eliminado_en)
         IS DISTINCT FROM (OLD.username, OLD.password_hash, OLD.rol_id, OLD.estado, OLD.eliminado_en) THEN
    RAISE EXCEPTION 'El usuario "%" es de sistema y no se puede modificar', OLD.username;
  END IF;
  IF NEW.rol_id <> OLD.rol_id AND EXISTS (SELECT 1 FROM roles r WHERE r.id = NEW.rol_id AND r.es_sistema) THEN
    RAISE EXCEPTION 'No se puede asignar un rol de sistema';
  END IF;
  RETURN NEW;
END $$ LANGUAGE plpgsql;
CREATE TRIGGER trg_usuarios_proteger BEFORE UPDATE ON usuarios
  FOR EACH ROW EXECUTE FUNCTION fn_proteger_usuario_sistema();

CREATE OR REPLACE FUNCTION fn_proteger_permisos_sistema() RETURNS trigger AS $$
BEGIN
  IF EXISTS (SELECT 1 FROM roles r WHERE r.id = COALESCE(NEW.rol_id, OLD.rol_id) AND r.es_sistema)
     AND current_setting('erp.seed', true) IS DISTINCT FROM 'on' THEN
    RAISE EXCEPTION 'Los permisos de un rol de sistema no se pueden modificar';
  END IF;
  RETURN NEW;
END $$ LANGUAGE plpgsql;
CREATE TRIGGER trg_permisos_proteger BEFORE INSERT OR UPDATE ON permisos
  FOR EACH ROW EXECUTE FUNCTION fn_proteger_permisos_sistema();

-- ---------------------------------------------------------------------
-- 3.5 Stock unificado: productos matriciales = suma de variantes activas
-- ---------------------------------------------------------------------
CREATE OR REPLACE FUNCTION fn_sync_stock_matricial() RETURNS trigger AS $$
BEGIN
  UPDATE productos p
     SET stock_actual = COALESCE((SELECT SUM(v.stock_actual) FROM variantes_productos v
                                   WHERE v.producto_id = p.id AND v.eliminado_en IS NULL), 0)
   WHERE p.id = NEW.producto_id AND p.es_matricial;
  IF TG_OP = 'UPDATE' AND OLD.producto_id <> NEW.producto_id THEN
    UPDATE productos p
       SET stock_actual = COALESCE((SELECT SUM(v.stock_actual) FROM variantes_productos v
                                     WHERE v.producto_id = p.id AND v.eliminado_en IS NULL), 0)
     WHERE p.id = OLD.producto_id AND p.es_matricial;
  END IF;
  RETURN NULL;
END $$ LANGUAGE plpgsql;
CREATE TRIGGER trg_variantes_sync_stock AFTER INSERT OR UPDATE ON variantes_productos
  FOR EACH ROW EXECUTE FUNCTION fn_sync_stock_matricial();

-- productos.stock_actual es solo lectura cuando es_matricial = TRUE
CREATE OR REPLACE FUNCTION fn_stock_matricial_solo_lectura() RETURNS trigger AS $$
BEGIN
  IF NEW.es_matricial THEN
    IF TG_OP = 'INSERT' THEN
      NEW.stock_actual := 0;
    ELSIF NOT OLD.es_matricial THEN
      NEW.stock_actual := COALESCE((SELECT SUM(stock_actual) FROM variantes_productos
                                     WHERE producto_id = NEW.id AND eliminado_en IS NULL), 0);
    ELSIF NEW.stock_actual IS DISTINCT FROM OLD.stock_actual AND pg_trigger_depth() <= 1 THEN
      RAISE EXCEPTION 'El stock del producto matricial "%" es la suma de sus variantes; modifique variantes_productos', NEW.codigo;
    END IF;
  END IF;
  RETURN NEW;
END $$ LANGUAGE plpgsql;
CREATE TRIGGER trg_productos_stock_matricial BEFORE INSERT OR UPDATE ON productos
  FOR EACH ROW EXECUTE FUNCTION fn_stock_matricial_solo_lectura();

-- Variantes solo para productos matriciales
CREATE OR REPLACE FUNCTION fn_variante_requiere_matricial() RETURNS trigger AS $$
BEGIN
  IF NOT EXISTS (SELECT 1 FROM productos WHERE id = NEW.producto_id AND es_matricial) THEN
    RAISE EXCEPTION 'El producto % no es matricial (es_matricial = FALSE); no admite variantes', NEW.producto_id;
  END IF;
  RETURN NEW;
END $$ LANGUAGE plpgsql;
CREATE TRIGGER trg_variantes_requiere_matricial BEFORE INSERT ON variantes_productos
  FOR EACH ROW EXECUTE FUNCTION fn_variante_requiere_matricial();

-- ---------------------------------------------------------------------
-- Partida doble: cada asiento REGISTRADO debe cuadrar (debe = haber = totales).
-- Se valida al hacer COMMIT, así se puede insertar cabecera y detalle en la misma transacción.
-- ---------------------------------------------------------------------
CREATE OR REPLACE FUNCTION fn_validar_asiento() RETURNS trigger AS $$
DECLARE
  v_id INT;
  a RECORD; v_debe DECIMAL; v_haber DECIMAL;
BEGIN
  IF TG_TABLE_NAME = 'asientos_contables' THEN
    v_id := NEW.id;
  ELSE
    v_id := NEW.asiento_id;
  END IF;
  SELECT * INTO a FROM asientos_contables WHERE id = v_id;
  IF a.estado <> 'REGISTRADO' OR a.eliminado_en IS NOT NULL THEN RETURN NULL; END IF;
  SELECT COALESCE(SUM(debe),0), COALESCE(SUM(haber),0) INTO v_debe, v_haber
    FROM detalle_asientos WHERE asiento_id = v_id AND eliminado_en IS NULL;
  IF v_debe <> v_haber OR v_debe <> a.total_debe OR v_haber <> a.total_haber THEN
    RAISE EXCEPTION 'Asiento % descuadrado: detalle debe=% haber=%, cabecera debe=% haber=%',
      v_id, v_debe, v_haber, a.total_debe, a.total_haber;
  END IF;
  RETURN NULL;
END $$ LANGUAGE plpgsql;
CREATE CONSTRAINT TRIGGER trg_asientos_cuadre AFTER INSERT OR UPDATE ON asientos_contables
  DEFERRABLE INITIALLY DEFERRED FOR EACH ROW EXECUTE FUNCTION fn_validar_asiento();
CREATE CONSTRAINT TRIGGER trg_detalle_asientos_cuadre AFTER INSERT OR UPDATE ON detalle_asientos
  DEFERRABLE INITIALLY DEFERRED FOR EACH ROW EXECUTE FUNCTION fn_validar_asiento();

-- ---------------------------------------------------------------------
-- 5.1 Motor de precios: tasa activa
-- Última tasa del día -> última disponible -> configuracion 'tasa_defecto'
-- ---------------------------------------------------------------------
CREATE OR REPLACE FUNCTION fn_tasa_activa(p_tipo tipo_cambio_pref DEFAULT 'DEFECTO_SISTEMA')
RETURNS DECIMAL(10,4) AS $$
DECLARE
  v_tipo  tipo_tasa;
  v_valor DECIMAL(10,4);
BEGIN
  -- 3.6 Tasa de cambio obligatoria
  IF NOT EXISTS (SELECT 1 FROM tasas_de_cambio) THEN
    RAISE EXCEPTION 'No hay tasas de cambio registradas. Registre al menos una antes de calcular precios.';
  END IF;

  IF p_tipo = 'DEFECTO_SISTEMA' THEN
    SELECT valor::tipo_tasa INTO v_tipo FROM configuracion_sistema WHERE clave = 'tipo_tasa_sistema';
    v_tipo := COALESCE(v_tipo, 'BCB');
  ELSE
    v_tipo := p_tipo::text::tipo_tasa;
  END IF;

  SELECT valor INTO v_valor FROM tasas_de_cambio
   WHERE tipo = v_tipo AND fecha = CURRENT_DATE
   ORDER BY hora DESC, id DESC LIMIT 1;

  IF v_valor IS NULL THEN
    SELECT valor INTO v_valor FROM tasas_de_cambio
     WHERE tipo = v_tipo ORDER BY fecha DESC, hora DESC, id DESC LIMIT 1;
  END IF;

  IF v_valor IS NULL THEN
    SELECT valor::DECIMAL(10,4) INTO v_valor FROM configuracion_sistema WHERE clave = 'tasa_defecto';
  END IF;

  RETURN v_valor;
END $$ LANGUAGE plpgsql STABLE;

-- 5.4 Redondeo configurable: NINGUNO | MEDIO_BOLIVIANO | ENTERO_SUPERIOR
CREATE OR REPLACE FUNCTION fn_redondear_precio(p_monto DECIMAL) RETURNS DECIMAL(10,2) AS $$
DECLARE v_regla TEXT;
BEGIN
  SELECT valor INTO v_regla FROM configuracion_sistema WHERE clave = 'redondeo_precios';
  RETURN CASE COALESCE(v_regla, 'NINGUNO')
    WHEN 'MEDIO_BOLIVIANO' THEN ROUND(CEIL(p_monto * 2) / 2, 2)
    WHEN 'ENTERO_SUPERIOR' THEN ROUND(CEIL(p_monto), 2)
    ELSE ROUND(p_monto, 2)
  END;
END $$ LANGUAGE plpgsql STABLE;

-- 5.2 Precio Venta (BOB) = (Costo Base USD × Tasa Activa) × (1 + % Margen)
CREATE OR REPLACE FUNCTION fn_calcular_precio(p_costo_usd DECIMAL, p_margen DECIMAL, p_tipo tipo_cambio_pref)
RETURNS DECIMAL(10,2) AS $$
BEGIN
  RETURN fn_redondear_precio(p_costo_usd * fn_tasa_activa(p_tipo) * (1 + p_margen / 100));
END $$ LANGUAGE plpgsql STABLE;

-- 5.3 Recálculo masivo (con auditoría). Devuelve cantidad de registros actualizados.
CREATE OR REPLACE FUNCTION fn_recalcular_precios(p_usuario_id INT, p_ip VARCHAR DEFAULT NULL)
RETURNS INT AS $$
DECLARE
  r RECORD;
  v_nuevo DECIMAL(10,2);
  v_total INT := 0;
BEGIN
  FOR r IN SELECT id, costo_base_usd, margen_ganancia, tipo_cambio_preferido, precio_venta_bob
             FROM productos WHERE eliminado_en IS NULL AND NOT es_matricial LOOP
    v_nuevo := fn_calcular_precio(r.costo_base_usd, r.margen_ganancia, r.tipo_cambio_preferido);
    IF v_nuevo IS DISTINCT FROM r.precio_venta_bob THEN
      UPDATE productos SET precio_venta_bob = v_nuevo, actualizado_por = p_usuario_id WHERE id = r.id;
      INSERT INTO bitacora_auditoria (usuario_id, tabla_afectada, registro_id, accion, datos_anteriores, datos_nuevos, ip_origen)
      VALUES (p_usuario_id, 'productos', r.id, 'EDITAR',
              jsonb_build_object('precio_venta_bob', r.precio_venta_bob),
              jsonb_build_object('precio_venta_bob', v_nuevo, 'motivo', 'RECALCULO_MASIVO'), p_ip);
      v_total := v_total + 1;
    END IF;
  END LOOP;

  FOR r IN SELECT v.id, v.costo_usd, v.precio_venta_bob, p.margen_ganancia, p.tipo_cambio_preferido
             FROM variantes_productos v JOIN productos p ON p.id = v.producto_id
            WHERE v.eliminado_en IS NULL AND p.eliminado_en IS NULL LOOP
    v_nuevo := fn_calcular_precio(r.costo_usd, r.margen_ganancia, r.tipo_cambio_preferido);
    IF v_nuevo IS DISTINCT FROM r.precio_venta_bob THEN
      UPDATE variantes_productos SET precio_venta_bob = v_nuevo, actualizado_por = p_usuario_id WHERE id = r.id;
      INSERT INTO bitacora_auditoria (usuario_id, tabla_afectada, registro_id, accion, datos_anteriores, datos_nuevos, ip_origen)
      VALUES (p_usuario_id, 'variantes_productos', r.id, 'EDITAR',
              jsonb_build_object('precio_venta_bob', r.precio_venta_bob),
              jsonb_build_object('precio_venta_bob', v_nuevo, 'motivo', 'RECALCULO_MASIVO'), p_ip);
      v_total := v_total + 1;
    END IF;
  END LOOP;

  RETURN v_total;
END $$ LANGUAGE plpgsql;

-- ---------------------------------------------------------------------
-- 2.8 MÓDULO REPORTES (solo vistas, sin tablas propias)
-- ---------------------------------------------------------------------
CREATE OR REPLACE VIEW v_stock_actual AS
SELECT p.id AS producto_id, NULL::INT AS variante_id, p.codigo, p.nombre,
       c.nombre AS categoria, p.stock_actual, p.stock_minimo,
       p.costo_base_usd AS costo_usd, p.precio_venta_bob, p.sucursal_id
  FROM productos p JOIN categorias c ON c.id = p.categoria_id
 WHERE p.eliminado_en IS NULL AND NOT p.es_matricial
UNION ALL
SELECT p.id, v.id, v.codigo_variante, p.nombre || ' ' || v.eje_x_valor || ' x ' || v.eje_y_valor,
       c.nombre, v.stock_actual, p.stock_minimo, v.costo_usd, v.precio_venta_bob, p.sucursal_id
  FROM variantes_productos v
  JOIN productos p  ON p.id = v.producto_id
  JOIN categorias c ON c.id = p.categoria_id
 WHERE v.eliminado_en IS NULL AND p.eliminado_en IS NULL;

CREATE OR REPLACE VIEW v_stock_bajo AS
SELECT * FROM v_stock_actual WHERE stock_actual <= stock_minimo;

CREATE OR REPLACE VIEW v_valorizacion_inventario AS
SELECT categoria,
       SUM(stock_actual)                     AS unidades,
       ROUND(SUM(stock_actual * costo_usd), 2) AS valor_costo_usd,
       SUM(stock_actual * precio_venta_bob)  AS valor_venta_bob
  FROM v_stock_actual
 GROUP BY categoria;

CREATE OR REPLACE VIEW v_productos_vendidos AS
SELECT dv.producto_id, dv.variante_id, p.codigo, p.nombre,
       SUM(dv.cantidad) AS cantidad_vendida, SUM(dv.subtotal_bob) AS total_bob
  FROM detalle_ventas dv
  JOIN ventas v    ON v.id = dv.venta_id AND v.estado = 'COMPLETADA' AND v.eliminado_en IS NULL
  JOIN productos p ON p.id = dv.producto_id
 GROUP BY dv.producto_id, dv.variante_id, p.codigo, p.nombre;

CREATE OR REPLACE VIEW v_arqueo_caja AS
SELECT c.sucursal_id, c.usuario_id, u.username, c.fecha_hora::date AS fecha,
       SUM(CASE WHEN c.tipo_movimiento = 'ENTRADA_VENTA' THEN c.monto_bob ELSE 0 END) AS entradas_bob,
       SUM(CASE WHEN c.tipo_movimiento = 'SALIDA_COMPRA' THEN c.monto_bob ELSE 0 END) AS salidas_bob,
       SUM(CASE WHEN c.tipo_movimiento = 'AJUSTE'        THEN c.monto_bob ELSE 0 END) AS ajustes_bob,
       SUM(CASE WHEN c.tipo_movimiento = 'SALIDA_COMPRA' THEN -c.monto_bob ELSE c.monto_bob END) AS saldo_bob
  FROM caja c JOIN usuarios u ON u.id = c.usuario_id
 GROUP BY c.sucursal_id, c.usuario_id, u.username, c.fecha_hora::date;

CREATE OR REPLACE VIEW v_permisos_usuario AS
SELECT u.id AS usuario_id, u.username, r.nombre AS rol, p.modulo, p.accion,
       m.nombre AS modulo_nombre, m.orden AS modulo_orden
  FROM usuarios u
  JOIN roles r    ON r.id = u.rol_id AND r.eliminado_en IS NULL
  JOIN permisos p ON p.rol_id = r.id AND p.eliminado_en IS NULL
  JOIN modulos m  ON m.codigo = p.modulo
 WHERE u.eliminado_en IS NULL AND u.estado = 'ACTIVO';

COMMIT;
