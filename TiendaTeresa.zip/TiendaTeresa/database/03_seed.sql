-- =====================================================================
-- Datos semilla: sucursal, roles, permisos, usuario admin, configuración
-- Usuario inicial:  admin / 1234   (rol Administrador)
-- =====================================================================
BEGIN;
SET LOCAL erp.seed = 'on';

-- Sucursal principal (creado_por = 1 -> admin; FK diferida hasta COMMIT)
INSERT INTO sucursales (id, nombre, direccion, estado, creado_por)
VALUES (1, 'Casa Matriz', 'Por definir', 'ACTIVA', 1);

-- 4.1 Roles preconfigurados
INSERT INTO roles (id, nombre, descripcion, es_sistema, creado_por) VALUES
 (1, 'Superusuario',    'Rol técnico (El Ing.). Intocable. Sin acceso a datos financieros sensibles.', TRUE,  1),
 (2, 'Administrador',   'Dueño. Control total del sistema.',                                            FALSE, 1),
 (3, 'Jefe de Almacén', 'Inventario y Proveedores. No ve márgenes ni Contabilidad.',                     FALSE, 1),
 (4, 'Contador',        'Contabilidad y Activos Fijos. Solo consulta Inventario y Proveedores.',         FALSE, 1),
 (5, 'Cajero',          'Acceso exclusivo al módulo VENTA (POS) y reporte de su caja.',                  FALSE, 1);

-- Usuario admin / 1234 (hash bcrypt compatible con bcrypt/bcryptjs de Node)
INSERT INTO usuarios (id, username, nombre_completo, password_hash, rol_id, sucursal_id,
                      estado, debe_cambiar_password, creado_por)
VALUES (1, 'admin', 'Administrador', crypt('1234', gen_salt('bf', 10)), 2, 1,
        'ACTIVO', FALSE, 1);

-- 4.3 Permisos granulares (modulo + accion)
-- Los 8 módulos, en el orden del documento
INSERT INTO modulos (codigo, nombre, orden, descripcion, creado_por) VALUES
 ('administrador', 'Administrador', 1, 'Seguridad y configuración: usuarios, roles, tasas, bitácora', 1),
 ('activos_fijos', 'Activos Fijos', 2, 'Registro y depreciación de bienes de la empresa', 1),
 ('contabilidad',  'Contabilidad',  3, 'Plan de cuentas, asientos, estados financieros y submódulo Caja', 1),
 ('inventario',    'Inventario',    4, 'Productos, variantes, stock, kardex y precios', 1),
 ('proveedor',     'Proveedor',     5, 'Proveedores y compras', 1),
 ('venta',         'Venta',         6, 'Administración y auditoría de ventas (consultar, editar, anular)', 1),
 ('VENTA',         'VENTA',         7, 'Punto de venta (POS) del cajero', 1),
 ('reportes',      'Reportes',      8, 'Reportes filtrados por rol', 1);

INSERT INTO permisos (rol_id, modulo, accion, creado_por)
SELECT rol_id, modulo, accion, 1 FROM (VALUES
  -- Superusuario: técnico (usuarios/roles/config), sin datos financieros
  (1,'administrador','ver'),(1,'administrador','crear'),(1,'administrador','editar'),
  (1,'administrador','resetear_password'),(1,'administrador','ver_auditoria'),
  -- Cajero
  (5,'VENTA','cobrar'),(5,'VENTA','consultar_propias'),(5,'reportes','arqueo_propio'),
  -- Jefe de Almacén
  (3,'inventario','ver'),(3,'inventario','crear'),(3,'inventario','editar'),(3,'inventario','anular'),
  (3,'proveedor','ver'),(3,'proveedor','crear'),(3,'proveedor','editar'),(3,'proveedor','anular'),
  (3,'reportes','stock'),(3,'reportes','valorizacion'),(3,'reportes','compras'),(3,'reportes','stock_bajo'),
  -- Contador
  (4,'contabilidad','ver'),(4,'contabilidad','crear'),(4,'contabilidad','editar'),(4,'contabilidad','anular'),
  (4,'contabilidad','caja_ver'),(4,'activos_fijos','ver'),(4,'activos_fijos','crear'),(4,'activos_fijos','editar'),
  (4,'activos_fijos','anular'),(4,'inventario','ver'),(4,'proveedor','ver'),
  (4,'reportes','financieros'),(4,'reportes','activos_fijos'),(4,'reportes','flujo_caja')
) AS t(rol_id, modulo, accion);

-- Administrador: 100% de los módulos
INSERT INTO permisos (rol_id, modulo, accion, creado_por)
SELECT 2, m, a, 1
  FROM unnest(ARRAY['administrador','activos_fijos','contabilidad','inventario','proveedor','venta','VENTA','reportes']) m
 CROSS JOIN unnest(ARRAY['ver','crear','editar','anular']) a
UNION ALL SELECT 2, x.m, x.a, 1 FROM (VALUES
  ('administrador','resetear_password'),('administrador','ver_auditoria'),('administrador','tasas_cambio'),
  ('contabilidad','caja_ver'),('contabilidad','caja_crear'),('contabilidad','caja_editar'),('contabilidad','caja_anular'),
  ('inventario','ver_margenes'),('inventario','recalcular_precios'),
  ('VENTA','cobrar'),('VENTA','consultar_propias'),
  ('venta','consultar'),('venta','ver_auditoria'),
  ('reportes','globales'),('reportes','bitacora')
) AS x(m, a)
ON CONFLICT DO NOTHING;

-- 2.1 Configuración del sistema
INSERT INTO configuracion_sistema (clave, valor, descripcion, creado_por) VALUES
 ('moneda_base',        'BOB',     'Moneda base del sistema', 1),
 ('tasa_defecto',       '6.96',    'Tasa por defecto (USD->BOB) si no hay tasas registradas del tipo solicitado', 1),
 ('tipo_tasa_sistema',  'BCB',     'Tipo de tasa usado cuando un producto/proveedor tiene DEFECTO_SISTEMA (BCB | PARALELO)', 1),
 ('redondeo_precios',   'MEDIO_BOLIVIANO', 'Regla de redondeo: NINGUNO | MEDIO_BOLIVIANO | ENTERO_SUPERIOR', 1),
 ('max_intentos_login', '5',       'Intentos fallidos antes de BLOQUEAR al usuario', 1),
 ('nombre_empresa',     'TiendaTeresa', 'Nombre comercial', 1);

-- 3.6 Al menos una tasa registrada
INSERT INTO tasas_de_cambio (tipo, valor, fuente, usuario_id, creado_por)
VALUES ('BCB', 6.9600, 'MANUAL', 1, 1);

-- 7.2 Cliente genérico
INSERT INTO clientes (nombre, nit, es_generico, creado_por)
VALUES ('Público General', '0', TRUE, 1);

-- Categoría inicial
INSERT INTO categorias (nombre, descripcion, creado_por)
VALUES ('General', 'Categoría por defecto', 1);

-- Plan de cuentas básico (para asientos automáticos de compra/venta)
INSERT INTO plan_cuentas (id, codigo, nombre, tipo, cuenta_padre_id, creado_por) VALUES
 (1,  '1',       'ACTIVO',                 'ACTIVO',     NULL, 1),
 (2,  '1.1',     'Activo Corriente',       'ACTIVO',     1,    1),
 (3,  '1.1.01',  'Caja',                   'ACTIVO',     2,    1),
 (4,  '1.1.02',  'Inventario de Mercadería','ACTIVO',    2,    1),
 (5,  '1.2',     'Activo No Corriente',    'ACTIVO',     1,    1),
 (6,  '1.2.01',  'Activos Fijos',          'ACTIVO',     5,    1),
 (7,  '1.2.02',  'Depreciación Acumulada', 'ACTIVO',     5,    1),
 (8,  '2',       'PASIVO',                 'PASIVO',     NULL, 1),
 (9,  '2.1.01',  'Cuentas por Pagar',      'PASIVO',     8,    1),
 (10, '3',       'PATRIMONIO',             'PATRIMONIO', NULL, 1),
 (11, '3.1.01',  'Capital',                'PATRIMONIO', 10,   1),
 (12, '4',       'INGRESOS',               'INGRESO',    NULL, 1),
 (13, '4.1.01',  'Ventas',                 'INGRESO',    12,   1),
 (14, '5',       'GASTOS',                 'GASTO',      NULL, 1),
 (15, '5.1.01',  'Costo de Ventas',        'GASTO',      14,   1),
 (16, '5.1.02',  'Gasto por Depreciación', 'GASTO',      14,   1);

-- Ajustar secuencias tras inserts con id explícito
SELECT setval('sucursales_id_seq',   (SELECT MAX(id) FROM sucursales));
SELECT setval('roles_id_seq',        (SELECT MAX(id) FROM roles));
SELECT setval('usuarios_id_seq',     (SELECT MAX(id) FROM usuarios));
SELECT setval('plan_cuentas_id_seq', (SELECT MAX(id) FROM plan_cuentas));

COMMIT;
