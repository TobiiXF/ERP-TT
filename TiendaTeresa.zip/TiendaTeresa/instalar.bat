@echo off
chcp 65001 >nul
title TiendaTeresa - Instalacion
cd /d "%~dp0"
echo.
echo ==========================================
echo   TiendaTeresa - Instalacion (una sola vez)
echo ==========================================
echo.

where node >nul 2>nul
if errorlevel 1 (
  echo [X] No se encontro Node.js. Instala Node.js 20 LTS desde https://nodejs.org y vuelve a ejecutar este archivo.
  pause
  exit /b 1
)

set "PSQL="
for /d %%D in ("%ProgramFiles%\PostgreSQL\*") do if exist "%%D\bin\psql.exe" set "PSQL=%%D\bin\psql.exe"
if not defined PSQL (
  echo [X] No se encontro PostgreSQL en "%ProgramFiles%\PostgreSQL". Instala PostgreSQL y vuelve a ejecutar este archivo.
  pause
  exit /b 1
)
echo PostgreSQL encontrado: "%PSQL%"
echo.

set /p "PGPASSWORD=Escribe la contrasena del usuario postgres - la que pusiste al instalar PostgreSQL: "
set "PGCLIENTENCODING=UTF8"
"%PSQL%" -U postgres -h localhost -tAc "SELECT 1" >nul 2>nul
if errorlevel 1 (
  echo [X] Contrasena incorrecta o PostgreSQL apagado.
  pause
  exit /b 1
)

set "EXISTE="
"%PSQL%" -U postgres -h localhost -tAc "SELECT 1 FROM pg_database WHERE datname='tiendateresa'" > "%TEMP%\tt_existe.txt"
set /p EXISTE=<"%TEMP%\tt_existe.txt"
if "%EXISTE%"=="1" (
  echo La base de datos tiendateresa ya existe: no se modifica.
) else (
  echo [1/4] Creando la base de datos tiendateresa...
  "%PSQL%" -U postgres -h localhost -q -c "CREATE DATABASE tiendateresa"
  if errorlevel 1 goto :error
  "%PSQL%" -U postgres -h localhost -d tiendateresa -q -v ON_ERROR_STOP=1 -f "%~dp0tiendateresa_completo.sql" >nul
  if errorlevel 1 goto :error
)

echo [2/4] Configurando backend\.env ...
if not exist "backend\.env" (
  copy "backend\.env.example" "backend\.env" >nul
  powershell -NoProfile -Command "$f = Join-Path (Get-Location) 'backend\.env'; $s = Get-Content $f | ForEach-Object { if ($_ -like 'DB_PASSWORD=*') { 'DB_PASSWORD=' + $env:PGPASSWORD } elseif ($_ -like 'JWT_SECRET=*') { 'JWT_SECRET=' + [guid]::NewGuid().ToString('N') + [guid]::NewGuid().ToString('N') } else { $_ } }; [IO.File]::WriteAllLines($f, $s)"
) else (
  echo backend\.env ya existe: no se modifica.
)

echo [3/4] Instalando el backend - puede tardar unos minutos...
cd /d "%~dp0backend"
call npm install --omit=dev
if errorlevel 1 goto :error

echo [4/4] Instalando y compilando el frontend...
cd /d "%~dp0frontend"
call npm install
if errorlevel 1 goto :error
call npm run build
if errorlevel 1 goto :error

cd /d "%~dp0"
echo.
echo ==========================================
echo   Listo. Ahora haz doble clic en iniciar.bat
echo   Usuario: admin   Contrasena: 1234
echo ==========================================
pause
exit /b 0

:error
cd /d "%~dp0"
echo.
echo [X] Ocurrio un error. Lee el mensaje de arriba o envialo para revisarlo.
pause
exit /b 1
