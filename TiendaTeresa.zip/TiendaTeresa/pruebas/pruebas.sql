-- =====================================================================
-- Pruebas de regresión. Todo corre en una transacción y se revierte (ROLLBACK):
-- no deja datos en la base. Uso: psql -d erp_ferreteria -f pruebas/pruebas.sql
-- Debe terminar con "TODAS LAS PRUEBAS PASARON".
-- =====================================================================
\set ON_ERROR_STOP on
\pset tuples_only on
\pset format unaligned
BEGIN;

CREATE FUNCTION pg_temp.debe_fallar(p_sql TEXT, p_desc TEXT) RETURNS VOID AS $$
BEGIN
  BEGIN
    EXECUTE p_sql;
  EXCEPTION WHEN OTHERS THEN
    RAISE NOTICE 'OK (rechazado): %', p_desc;
    RETURN;
  END;
  RAISE EXCEPTION 'FALLO: se esperaba error en: %', p_desc;
END $$ LANGUAGE plpgsql;

CREATE FUNCTION pg_temp.afirmar(p_cond BOOLEAN, p_desc TEXT) RETURNS VOID AS $$
BEGIN
  IF p_cond IS NOT TRUE THEN RAISE EXCEPTION 'FALLO: %', p_desc; END IF;
  RAISE NOTICE 'OK: %', p_desc;
END $$ LANGUAGE plpgsql;

-- 1. Estructura y semilla
SELECT pg_temp.afirmar((SELECT count(*) FROM pg_tables WHERE schemaname='public') = 24, '24 tablas (23 del documento + catálogo de módulos)');
SELECT pg_temp.afirmar((SELECT password_hash = crypt('1234', password_hash) FROM usuarios WHERE username='admin'), 'login admin/1234');
SELECT pg_temp.afirmar((SELECT r.nombre FROM usuarios u JOIN roles r ON r.id=u.rol_id WHERE u.username='admin') = 'Administrador', 'admin tiene rol Administrador');
SELECT pg_temp.afirmar(EXISTS (SELECT 1 FROM v_permisos_usuario WHERE username='admin' AND modulo='venta' AND accion='anular'), 'admin tiene permiso venta.anular');
SELECT pg_temp.afirmar(current_setting('TimeZone') = 'America/La_Paz', 'zona horaria America/La_Paz');

-- 2. Reglas de oro
SELECT pg_temp.debe_fallar($$DELETE FROM clientes$$, 'DELETE físico');
INSERT INTO bitacora_auditoria (usuario_id, accion) VALUES (1, 'LOGIN');
SELECT pg_temp.debe_fallar($$UPDATE bitacora_auditoria SET accion='LOGIN'$$, 'editar bitácora');
SELECT pg_temp.debe_fallar($$UPDATE roles SET nombre='X' WHERE es_sistema$$, 'modificar rol Superusuario');
SELECT pg_temp.debe_fallar($$UPDATE usuarios SET rol_id=1 WHERE username='admin'$$, 'asignar rol de sistema');
SELECT pg_temp.debe_fallar($$INSERT INTO permisos (rol_id,modulo,accion,creado_por) VALUES (1,'contabilidad','ver',1)$$, 'dar permisos al Superusuario');
SELECT pg_temp.afirmar((SELECT string_agg(nombre, ',' ORDER BY orden) FROM modulos) = 'Administrador,Activos Fijos,Contabilidad,Inventario,Proveedor,Venta,VENTA,Reportes', 'los 8 módulos existen en el orden del documento');
SELECT pg_temp.debe_fallar($$INSERT INTO permisos (rol_id,modulo,accion,creado_por) VALUES (2,'caja','ver',1)$$, 'permiso con módulo inexistente');

-- 3. Motor de precios
SELECT pg_temp.afirmar(fn_tasa_activa('BCB') = 6.96, 'tasa BCB activa = 6.96');
SELECT pg_temp.afirmar(fn_tasa_activa('PARALELO') = 6.96, 'PARALELO sin registros -> tasa_defecto');
INSERT INTO tasas_de_cambio (tipo, valor, fuente, creado_por) VALUES ('PARALELO', 10.5, 'API', 1);
SELECT pg_temp.afirmar(fn_tasa_activa('PARALELO') = 10.5, 'PARALELO usa la última tasa del día');
SELECT pg_temp.afirmar(fn_calcular_precio(1, 30, 'BCB') = 9.50, '1 USD * 6.96 * 1.30 = 9.048 -> 9.50 (medio boliviano)');
UPDATE configuracion_sistema SET valor='ENTERO_SUPERIOR' WHERE clave='redondeo_precios';
SELECT pg_temp.afirmar(fn_calcular_precio(1, 30, 'BCB') = 10.00, 'redondeo ENTERO_SUPERIOR');
UPDATE configuracion_sistema SET valor='NINGUNO' WHERE clave='redondeo_precios';
SELECT pg_temp.afirmar(fn_calcular_precio(0.0350, 30, 'BCB') = 0.32, 'costo con 4 decimales (0.0350 USD)');

-- 4. Productos simples y matriciales
INSERT INTO productos (id, codigo, nombre, categoria_id, costo_base_usd, margen_ganancia, stock_actual, stock_minimo, sucursal_id, creado_por)
VALUES (1000, 'TOR-01', 'Tornillo', 1, 0.05, 40, 10, 20, 1, 1);
INSERT INTO productos (id, codigo, nombre, categoria_id, es_matricial, margen_ganancia, sucursal_id, creado_por)
VALUES (1001, 'PH', 'Perno Hexagonal', 1, TRUE, 30, 1, 1);
INSERT INTO variantes_productos (id, producto_id, codigo_variante, eje_x_valor, eje_y_valor, costo_usd, stock_actual, creado_por) VALUES
 (2000, 1001, 'PH-10MM-5CM', '10MM', '5CM', 0.10, 50, 1),
 (2001, 1001, 'PH-10MM-8CM', '10MM', '8CM', 0.15, 30, 1);
SELECT pg_temp.afirmar((SELECT stock_actual FROM productos WHERE id=1001) = 80, 'stock matricial = suma de variantes (80)');
SELECT pg_temp.debe_fallar($$UPDATE productos SET stock_actual=5 WHERE id=1001$$, 'editar stock de producto matricial a mano');
SELECT pg_temp.debe_fallar($$INSERT INTO variantes_productos (producto_id,codigo_variante,eje_x_valor,eje_y_valor,creado_por) VALUES (1000,'X','a','b',1)$$, 'variante en producto no matricial');
SELECT pg_temp.debe_fallar($$UPDATE productos SET stock_actual=-1 WHERE id=1000$$, 'stock negativo en producto');
SELECT pg_temp.debe_fallar($$UPDATE variantes_productos SET stock_actual=-1 WHERE id=2000$$, 'stock negativo en variante');
UPDATE variantes_productos SET eliminado_en=NOW(), eliminado_por=1 WHERE id=2001;
SELECT pg_temp.afirmar((SELECT stock_actual FROM productos WHERE id=1001) = 50, 'soft delete de variante recalcula stock (50)');
SELECT pg_temp.afirmar(fn_recalcular_precios(1) >= 2, 'recálculo masivo actualiza precios');
SELECT pg_temp.afirmar((SELECT count(*) FROM bitacora_auditoria WHERE datos_nuevos->>'motivo'='RECALCULO_MASIVO') >= 2, 'recálculo masivo queda en bitácora');
SELECT pg_temp.afirmar(EXISTS (SELECT 1 FROM v_stock_bajo WHERE codigo='TOR-01'), 'reporte stock bajo');

-- 5. Flujo de compra completo (stock + kardex + caja + asiento)
INSERT INTO proveedores (id, nombre, creado_por) VALUES (3000, 'Proveedor Prueba', 1);
INSERT INTO compras (id, numero_compra, proveedor_id, tipo_documento, subtotal_usd, tasa_cambio_aplicada, total_bob, estado, usuario_id, sucursal_id, creado_por)
VALUES (4000, 'C-PRUEBA-1', 3000, 'FACTURA', 5.00, 6.96, 34.80, 'PAGADA', 1, 1, 1);
INSERT INTO detalle_compras (compra_id, producto_id, cantidad, costo_unitario_usd, subtotal_usd, creado_por) VALUES (4000, 1000, 100, 0.05, 5.00, 1);
UPDATE productos SET stock_actual = stock_actual + 100 WHERE id=1000;
INSERT INTO kardex_inventario (producto_id, tipo_movimiento, cantidad, stock_anterior, stock_nuevo, costo_unitario_usd, compra_id, usuario_id, sucursal_id, creado_por)
VALUES (1000, 'ENTRADA_COMPRA', 100, 10, 110, 0.05, 4000, 1, 1, 1);
INSERT INTO caja (tipo_movimiento, monto_bob, compra_id, usuario_id, sucursal_id, creado_por) VALUES ('SALIDA_COMPRA', 34.80, 4000, 1, 1, 1);
INSERT INTO asientos_contables (id, documento_origen, compra_id, total_debe, total_haber, usuario_id, creado_por) VALUES (5000, 'C-PRUEBA-1', 4000, 34.80, 34.80, 1, 1);
INSERT INTO detalle_asientos (asiento_id, cuenta_id, debe, haber, creado_por) VALUES (5000, 4, 34.80, 0, 1), (5000, 3, 0, 34.80, 1);
SET CONSTRAINTS ALL IMMEDIATE;
SET CONSTRAINTS ALL DEFERRED;
SELECT pg_temp.afirmar((SELECT stock_actual FROM productos WHERE id=1000) = 110, 'compra suma stock (110)');

-- 6. Flujo de venta completo
INSERT INTO ventas (id, numero_venta, cliente_id, subtotal_bob, total_bob, monto_recibido, cambio_devuelto, cajero_id, sucursal_id, creado_por)
VALUES (6000, 'V-PRUEBA-1', (SELECT id FROM clientes WHERE es_generico), 20, 20, 50, 30, 1, 1, 1);
INSERT INTO detalle_ventas (venta_id, producto_id, variante_id, cantidad, precio_unitario_bob, subtotal_bob, creado_por) VALUES (6000, 1001, 2000, 20, 1.00, 20, 1);
UPDATE variantes_productos SET stock_actual = stock_actual - 20 WHERE id=2000;
INSERT INTO caja (tipo_movimiento, monto_bob, venta_id, usuario_id, sucursal_id, creado_por) VALUES ('ENTRADA_VENTA', 20, 6000, 1, 1, 1);
SELECT pg_temp.afirmar((SELECT stock_actual FROM productos WHERE id=1001) = 30, 'venta de variante descuenta stock del padre (30)');
SELECT pg_temp.debe_fallar($$UPDATE variantes_productos SET stock_actual = stock_actual - 999 WHERE id=2000$$, 'vender más de lo que hay');
SELECT pg_temp.afirmar(EXISTS (SELECT 1 FROM v_productos_vendidos WHERE producto_id=1001 AND cantidad_vendida=20), 'reporte productos vendidos');
SELECT pg_temp.afirmar((SELECT saldo_bob FROM v_arqueo_caja WHERE usuario_id=1 AND fecha=CURRENT_DATE) = 20 - 34.80, 'arqueo de caja');
UPDATE ventas SET estado='ANULADA', actualizado_por=1 WHERE id=6000;
SELECT pg_temp.afirmar(NOT EXISTS (SELECT 1 FROM v_productos_vendidos WHERE producto_id=1001), 'venta anulada sale de reportes');
SELECT pg_temp.debe_fallar($$UPDATE ventas SET total_bob=-5 WHERE id=6000$$, 'monto negativo en venta');

-- 7. Partida doble
SAVEPOINT sp;
INSERT INTO asientos_contables (id, total_debe, total_haber, usuario_id, creado_por) VALUES (5001, 10, 10, 1, 1);
INSERT INTO detalle_asientos (asiento_id, cuenta_id, debe, haber, creado_por) VALUES (5001, 3, 10, 0, 1);
SELECT pg_temp.debe_fallar($$SET CONSTRAINTS ALL IMMEDIATE$$, 'asiento descuadrado');
ROLLBACK TO SAVEPOINT sp;

DO $$ BEGIN RAISE NOTICE '=== TODAS LAS PRUEBAS PASARON ==='; END $$;
ROLLBACK;
