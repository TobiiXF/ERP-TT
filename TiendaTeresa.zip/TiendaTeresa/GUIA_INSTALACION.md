# TiendaTeresa: guía de instalación en tu laptop (Windows)

Todo funciona **local**, en tu laptop, sin internet (solo se necesita internet una vez, para descargar los programas).

## Paso 1: Abrir el .zip
1. Descarga `TiendaTeresa.zip`.
2. Ve a la carpeta **Descargas**, haz **clic derecho** sobre `TiendaTeresa.zip` y elige **"Extraer todo..."**.
3. En "Seleccionar destino" escribe `C:\` y pulsa **Extraer**.
4. Te queda la carpeta `C:\TiendaTeresa` con los archivos `instalar.bat`, `iniciar.bat` y las carpetas `backend`, `frontend`, `database`...

> No trabajes dentro del zip sin extraerlo: Windows no deja ejecutar los archivos desde ahí.

## Paso 2: Instalar Node.js (una sola vez)
1. Entra a https://nodejs.org y descarga la versión **LTS** (20 o superior).
2. Instálalo con "Siguiente, Siguiente, Instalar" (deja todas las opciones como vienen).

## Paso 3: Instalar PostgreSQL (una sola vez)
1. Entra a https://www.postgresql.org/download/windows/ y descarga el instalador (versión 16 o 17).
2. Durante la instalación:
   - Te pedirá una **contraseña para el usuario `postgres`**. **Anótala**: la necesitas en el paso 4.
   - Puerto: deja **5432**.
   - Al final puedes desmarcar "Stack Builder".
3. pgAdmin se instala junto con PostgreSQL. Te sirve para ver la base de datos.

## Paso 4: Instalar TiendaTeresa (una sola vez)
1. Abre `C:\TiendaTeresa` y haz **doble clic en `instalar.bat`**.
   - Si Windows muestra "Windows protegió su PC", pulsa **Más información** y luego **Ejecutar de todas formas**.
2. Escribe la contraseña de `postgres` del paso 3 y pulsa Enter. Lo que escribes se ve en pantalla: es normal.
3. El instalador hace solo estas cosas:
   - crea la base de datos `tiendateresa` con el usuario `admin`;
   - configura el archivo `backend\.env` con tu contraseña y una clave secreta aleatoria;
   - descarga las librerías y compila la pantalla.
   Tarda de 2 a 5 minutos.
4. Cuando diga **"Listo"**, pulsa una tecla para cerrar.

## Paso 5: Usar el sistema (todos los días)
1. Doble clic en **`iniciar.bat`**. Se abre una ventana negra y, a los 3 segundos, el navegador en **http://localhost:3000**.
2. Entra con usuario **admin** y contraseña **1234**.
3. **Cambia la contraseña** la primera vez, en el menú de abajo a la izquierda: "Cambiar contraseña".
4. **No cierres la ventana negra** mientras uses el sistema. Para apagarlo, ciérrala.

Truco: clic derecho en `iniciar.bat`, luego **Enviar a** y **Escritorio (crear acceso directo)**. Así lo abres desde el escritorio.

## Usarlo desde otra PC o celular de la misma red (opcional)
1. En la laptop, abre "cmd" y escribe `ipconfig`. Anota la "Dirección IPv4" (ejemplo: 192.168.1.20).
2. Desde la otra PC o celular, conectado al mismo WiFi, abre `http://192.168.1.20:3000`.
3. Si Windows pregunta por el firewall la primera vez que abres `iniciar.bat`, pulsa **Permitir acceso** (red privada).

## Copias de seguridad (muy recomendado)
En pgAdmin:
1. Abre Servers, luego PostgreSQL y luego Databases.
2. Haz clic derecho en `tiendateresa`, elige **Backup...**, ponle un nombre de archivo (ej. `respaldo-2026-10-26.backup`) y pulsa **Backup**.
3. Guarda ese archivo en un USB o en otro disco.

Las fotos de los productos están en `C:\TiendaTeresa\backend\public\uploads\productos`. Cópialas también.

## Problemas comunes
| Mensaje | Solución |
|---|---|
| "No se encontró Node.js" | Instala Node.js (paso 2) y vuelve a abrir `instalar.bat`. |
| "No se encontró PostgreSQL" | Instala PostgreSQL (paso 3). Si lo instalaste en otra carpeta, usa la instalación manual de abajo. |
| "Contraseña incorrecta o PostgreSQL apagado" | Revisa la contraseña de `postgres`. Si sigue igual: tecla Windows, escribe "Servicios" y verifica que "postgresql" esté "En ejecución". |
| El navegador dice "No se puede acceder a este sitio" | La ventana negra de `iniciar.bat` está cerrada o muestra un error. Vuelve a abrirla. |
| "Usuario bloqueado por exceso de intentos" | Otro administrador lo desbloquea en Administrador, Usuarios. Si es el admin, ver abajo. |

**Desbloquear al admin:** en pgAdmin, clic derecho en `tiendateresa`, abre **Query Tool** y ejecuta:
```sql
UPDATE usuarios SET estado = 'ACTIVO', intentos_fallidos = 0 WHERE username = 'admin';
```

## Instalación manual (si `instalar.bat` no funciona)
1. **Base de datos:** en pgAdmin, clic derecho en Databases, **Create**, **Database...**, nombre `tiendateresa` y **Save**.
   Luego clic derecho en `tiendateresa`, **Query Tool**, abre el archivo `tiendateresa_completo.sql` (ícono de carpeta) y pulsa ▶ (Execute).
2. **Configuración:** copia `backend\.env.example` como `backend\.env` y ábrelo con el Bloc de notas:
   - `DB_PASSWORD=` la contraseña de postgres;
   - `JWT_SECRET=` cualquier texto largo y difícil de adivinar.
3. **Programas:** abre "cmd" en `C:\TiendaTeresa` y ejecuta:
   ```
   cd backend
   npm install
   cd ..\frontend
   npm install
   npm run build
   ```
4. Listo: usa `iniciar.bat`.
