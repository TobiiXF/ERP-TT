-- Migración para bases instaladas antes del catálogo de módulos (no hace falta en instalaciones nuevas)
BEGIN;
SET LOCAL erp.seed = 'on';

CREATE TABLE modulos (
    id              SERIAL PRIMARY KEY,
    codigo          VARCHAR(50) NOT NULL UNIQUE,
    nombre          VARCHAR(60) NOT NULL,
    orden           SMALLINT NOT NULL UNIQUE,
    descripcion     TEXT,
    creado_por      INT NOT NULL REFERENCES usuarios(id),
    creado_en       TIMESTAMP NOT NULL DEFAULT NOW(),
    actualizado_por INT NULL REFERENCES usuarios(id),
    actualizado_en  TIMESTAMP NULL,
    eliminado_en    TIMESTAMP NULL,
    eliminado_por   INT NULL REFERENCES usuarios(id)
);
CREATE TRIGGER trg_modulos_no_delete BEFORE DELETE ON modulos FOR EACH ROW EXECUTE FUNCTION fn_prohibir_delete();
CREATE TRIGGER trg_modulos_actualizado_en BEFORE UPDATE ON modulos FOR EACH ROW EXECUTE FUNCTION fn_set_actualizado_en();

INSERT INTO modulos (codigo, nombre, orden, descripcion, creado_por) VALUES
 ('administrador', 'Administrador', 1, 'Seguridad y configuración: usuarios, roles, tasas, bitácora', 1),
 ('activos_fijos', 'Activos Fijos', 2, 'Registro y depreciación de bienes de la empresa', 1),
 ('contabilidad',  'Contabilidad',  3, 'Plan de cuentas, asientos, estados financieros y submódulo Caja', 1),
 ('inventario',    'Inventario',    4, 'Productos, variantes, stock, kardex y precios', 1),
 ('proveedor',     'Proveedor',     5, 'Proveedores y compras', 1),
 ('venta',         'Venta',         6, 'Administración y auditoría de ventas (consultar, editar, anular)', 1),
 ('VENTA',         'VENTA',         7, 'Punto de venta (POS) del cajero', 1),
 ('reportes',      'Reportes',      8, 'Reportes filtrados por rol', 1);

-- 'caja' deja de ser un módulo aparte: es submódulo de Contabilidad
UPDATE permisos SET modulo = 'contabilidad', accion = 'caja_' || accion WHERE modulo = 'caja';
ALTER TABLE permisos ADD CONSTRAINT permisos_modulo_fkey FOREIGN KEY (modulo) REFERENCES modulos(codigo) ON UPDATE CASCADE;

DROP VIEW v_permisos_usuario;
CREATE VIEW v_permisos_usuario AS
SELECT u.id AS usuario_id, u.username, r.nombre AS rol, p.modulo, p.accion,
       m.nombre AS modulo_nombre, m.orden AS modulo_orden
  FROM usuarios u
  JOIN roles r    ON r.id = u.rol_id AND r.eliminado_en IS NULL
  JOIN permisos p ON p.rol_id = r.id AND p.eliminado_en IS NULL
  JOIN modulos m  ON m.codigo = p.modulo
 WHERE u.eliminado_en IS NULL AND u.estado = 'ACTIVO';

UPDATE configuracion_sistema SET valor = 'TiendaTeresa' WHERE clave = 'nombre_empresa';
COMMIT;
