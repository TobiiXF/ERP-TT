/** @type {import('tailwindcss').Config} */
export default {
  content: ['./index.html', './src/**/*.{vue,js}'],
  darkMode: 'class',
  theme: {
    extend: {
      colors: {
        // Paleta de 2 colores: primario (azul acero) + acento (ámbar ferretería)
        primario: { 50: '#eef4fb', 100: '#d5e3f4', 500: '#2f6db5', 600: '#245a98', 700: '#1c467a', 900: '#0f2440' },
        acento: { 400: '#fbbf24', 500: '#f59e0b', 600: '#d97706' },
      },
    },
  },
  plugins: [],
}
