import { createRouter, createWebHistory } from 'vue-router'
import { useAuth } from './stores/auth'

// Agrupado por los 8 módulos (el nombre y el orden de cada módulo vienen de la tabla `modulos`)
export const modulosDefecto = [
  { codigo: 'administrador', nombre: 'Administrador' }, { codigo: 'activos_fijos', nombre: 'Activos Fijos' },
  { codigo: 'contabilidad', nombre: 'Contabilidad' }, { codigo: 'inventario', nombre: 'Inventario' },
  { codigo: 'proveedor', nombre: 'Proveedor' }, { codigo: 'venta', nombre: 'Venta' },
  { codigo: 'VENTA', nombre: 'VENTA' }, { codigo: 'reportes', nombre: 'Reportes' },
]
const Ventas = () => import('./views/Ventas.vue')
const Caja = () => import('./views/Caja.vue')
export const menu = [
  { modulo: 'administrador', path: '/usuarios', nombre: 'Usuarios', icono: 'usuarios', perms: ['administrador.ver'], comp: () => import('./views/Usuarios.vue') },
  { modulo: 'administrador', path: '/tasas', nombre: 'Tasas y precios', icono: 'tasas', perms: ['administrador.tasas_cambio', 'inventario.recalcular_precios'], comp: () => import('./views/Tasas.vue') },
  { modulo: 'administrador', path: '/bitacora', nombre: 'Bitácora', icono: 'bitacora', perms: ['reportes.bitacora', 'administrador.ver_auditoria'], comp: () => import('./views/Bitacora.vue') },
  { modulo: 'activos_fijos', path: '/activos-fijos', nombre: 'Activos fijos', icono: 'activos', perms: ['activos_fijos.ver'], comp: () => import('./views/ActivosFijos.vue') },
  { modulo: 'contabilidad', path: '/libro-diario', nombre: 'Libro diario', icono: 'contabilidad', perms: ['contabilidad.ver'], comp: () => import('./views/LibroDiario.vue') },
  { modulo: 'contabilidad', path: '/caja', nombre: 'Caja', icono: 'caja', perms: ['contabilidad.caja_ver'], comp: Caja },
  { modulo: 'inventario', path: '/inventario', nombre: 'Productos y stock', icono: 'inventario', perms: ['inventario.ver'], comp: () => import('./views/Inventario.vue') },
  { modulo: 'proveedor', path: '/proveedores', nombre: 'Proveedores', icono: 'proveedores', perms: ['proveedor.ver'], comp: () => import('./views/Proveedores.vue') },
  { modulo: 'proveedor', path: '/compras', nombre: 'Compras', icono: 'compras', perms: ['proveedor.ver'], comp: () => import('./views/Compras.vue') },
  { modulo: 'venta', path: '/ventas', nombre: 'Administrar ventas', icono: 'ventas', perms: ['venta.consultar'], comp: Ventas },
  { modulo: 'VENTA', path: '/pos', nombre: 'Punto de venta', icono: 'pos', perms: ['VENTA.cobrar'], comp: () => import('./views/Pos.vue') },
  { modulo: 'VENTA', path: '/mis-ventas', nombre: 'Mis ventas', icono: 'ventas', perms: ['VENTA.consultar_propias'], ocultarSi: ['venta.consultar'], comp: Ventas },
  { modulo: 'reportes', path: '/dashboard', nombre: 'Dashboard', icono: 'dashboard', perms: ['reportes.ver', 'reportes.globales'], comp: () => import('./views/Dashboard.vue') },
  { modulo: 'reportes', path: '/mi-arqueo', nombre: 'Arqueo de mi turno', icono: 'caja', perms: ['reportes.arqueo_propio'], ocultarSi: ['contabilidad.caja_ver'], comp: Caja },
]

const router = createRouter({
  history: createWebHistory(),
  routes: [
    { path: '/login', component: () => import('./views/Login.vue'), meta: { publica: true } },
    { path: '/cambiar-password', component: () => import('./views/CambiarPassword.vue') },
    {
      path: '/',
      component: () => import('./components/Layout.vue'),
      children: [
        { path: '', name: 'inicio', component: { render: () => null } },
        ...menu.map((m) => ({ path: m.path.slice(1), component: m.comp, meta: { perms: m.perms } })),
        { path: 'inventario/:id', component: () => import('./views/ProductoDetalle.vue'), meta: { perms: ['inventario.ver'] } },
      ],
    },
    { path: '/:pathMatch(.*)*', redirect: '/' },
  ],
})

export const visible = (auth, m) => auth.puede(...m.perms) && !(m.ocultarSi && auth.puede(...m.ocultarSi))
export const primeraRuta = (auth) => {
  const v = menu.filter((m) => visible(auth, m))
  return (v.find((m) => m.path === '/dashboard') || v.find((m) => m.path === '/pos') || v[0])?.path || '/cambiar-password'
}

router.beforeEach(async (to) => {
  const auth = useAuth()
  if (to.meta.publica) return auth.logueado && auth.user ? primeraRuta(auth) : true
  if (!auth.logueado) return '/login'
  if (!auth.user) await auth.cargar()
  if (!auth.user) return '/login'
  if (auth.user.debe_cambiar_password && to.path !== '/cambiar-password') return '/cambiar-password'
  if (to.name === 'inicio') return primeraRuta(auth)
  if (to.meta.perms && !auth.puede(...to.meta.perms)) return primeraRuta(auth)
  return true
})

// Si se recompiló el frontend con la pestaña abierta, los archivos viejos ya no existen: recargar una vez
router.onError((err, to) => {
  if (/dynamically imported module|Importing a module script failed|Failed to fetch/i.test(err?.message || '') && !sessionStorage.recargado) {
    sessionStorage.recargado = '1'
    window.location.assign(to?.fullPath || '/')
  }
})
router.afterEach(() => sessionStorage.removeItem('recargado'))

export default router
