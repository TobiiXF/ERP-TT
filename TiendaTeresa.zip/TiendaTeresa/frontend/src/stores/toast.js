import { reactive } from 'vue'

export const toasts = reactive([])
let n = 0
export function avisar(texto, tipo = 'ok') {
  const id = ++n
  toasts.push({ id, texto, tipo })
  setTimeout(() => { const i = toasts.findIndex((t) => t.id === id); if (i >= 0) toasts.splice(i, 1) }, 4000)
}
export const error = (e) => avisar(e?.mensaje || e?.message || String(e), 'error')
