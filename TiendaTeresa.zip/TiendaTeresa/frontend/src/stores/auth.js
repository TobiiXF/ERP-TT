import { defineStore } from 'pinia'
import api from '../api'

export const useAuth = defineStore('auth', {
  state: () => ({ user: null, token: localStorage.getItem('token') }),
  getters: {
    logueado: (s) => !!s.token,
  },
  actions: {
    puede(...perms) {
      const p = this.user?.permisos || []
      return perms.some((x) => p.includes(x))
    },
    async login(username, password) {
      const { data } = await api.post('/auth/login', { username, password })
      this.token = data.token
      localStorage.setItem('token', data.token)
      this.user = data.user
      return data.user
    },
    async cargar() {
      if (!this.token) return null
      try {
        const { data } = await api.get('/auth/me')
        this.user = data
      } catch {
        this.salirLocal()
      }
      return this.user
    },
    async logout() {
      try { await api.post('/auth/logout') } catch { /* sin conexión */ }
      this.salirLocal()
    },
    salirLocal() {
      this.user = null
      this.token = null
      localStorage.removeItem('token')
    },
  },
})
