<script setup>
import { ref, onMounted } from 'vue'
import api, { fecha } from '../api'
import { useAuth } from '../stores/auth'
import { avisar, error } from '../stores/toast'
import Modal from '../components/Modal.vue'

const auth = useAuth()
const filas = ref([])
const roles = ref([])
const form = ref(null)
const clave = ref(null)
async function cargar() {
  try {
    const [u, r] = await Promise.all([api.get('/usuarios'), api.get('/usuarios/roles')])
    filas.value = u.data; roles.value = r.data
  } catch (e) { error(e) }
}
onMounted(cargar)
async function guardar() {
  try {
    if (form.value.id) {
      await api.put(`/usuarios/${form.value.id}`, { nombre_completo: form.value.nombre_completo, rol_id: form.value.rol_id, estado: form.value.estado })
      avisar('Usuario actualizado')
    } else {
      const { data } = await api.post('/usuarios', form.value)
      clave.value = { username: data.username, password: data.password_temporal }
    }
    form.value = null; cargar()
  } catch (e) { error(e) }
}
async function reset(u) {
  if (!confirm(`¿Generar nueva contraseña temporal para ${u.username}?`)) return
  try { const { data } = await api.post(`/usuarios/${u.id}/reset-password`); clave.value = { username: u.username, password: data.password_temporal }; cargar() } catch (e) { error(e) }
}
async function eliminar(u) {
  if (!confirm(`¿Dar de baja a ${u.username}?`)) return
  try { await api.delete(`/usuarios/${u.id}`); cargar() } catch (e) { error(e) }
}
const colorEstado = { ACTIVO: 'bg-green-100 text-green-700', INACTIVO: 'bg-slate-200 text-slate-600', BLOQUEADO: 'bg-red-100 text-red-700' }
</script>
<template>
  <div>
    <div class="flex items-center justify-between mb-4">
      <h1 class="titulo mb-0">Usuarios</h1>
      <button v-if="auth.puede('administrador.crear')" class="btn-primario" @click="form = { username: '', nombre_completo: '', rol_id: roles.find((r) => !r.es_sistema)?.id }">+ Nuevo usuario</button>
    </div>
    <div class="card overflow-x-auto">
      <table class="tabla">
        <thead><tr><th>Usuario</th><th>Nombre</th><th>Rol</th><th>Estado</th><th>Último acceso</th><th></th></tr></thead>
        <tbody><tr v-for="u in filas" :key="u.id">
          <td class="font-medium">{{ u.username }}</td><td>{{ u.nombre_completo }}</td><td>{{ u.rol }}</td>
          <td><span class="badge" :class="colorEstado[u.estado]">{{ u.estado }}</span> <span v-if="u.debe_cambiar_password" class="badge bg-acento-400/20 text-acento-600">clave temporal</span></td>
          <td>{{ fecha(u.ultimo_acceso) || '—' }}</td>
          <td class="text-right whitespace-nowrap">
            <template v-if="!u.es_sistema">
              <button v-if="auth.puede('administrador.editar')" class="text-primario-600 text-xs mr-3" @click="form = { ...u }">editar</button>
              <button v-if="auth.puede('administrador.resetear_password')" class="text-acento-600 text-xs mr-3" @click="reset(u)">resetear clave</button>
              <button v-if="auth.puede('administrador.anular') && u.id !== auth.user.id" class="text-red-600 text-xs" @click="eliminar(u)">baja</button>
            </template>
            <span v-else class="text-xs text-slate-400">protegido</span>
          </td>
        </tr></tbody>
      </table>
    </div>
    <Modal v-if="form" :titulo="form.id ? 'Editar usuario' : 'Nuevo usuario'" @cerrar="form = null">
      <form class="space-y-3" @submit.prevent="guardar">
        <div><label class="label">Usuario</label><input v-model="form.username" class="input" required :disabled="!!form.id" /></div>
        <div><label class="label">Nombre completo</label><input v-model="form.nombre_completo" class="input" required /></div>
        <div><label class="label">Rol</label><select v-model="form.rol_id" class="input" required><option v-for="r in roles.filter((r) => !r.es_sistema)" :key="r.id" :value="r.id">{{ r.nombre }}</option></select></div>
        <div v-if="form.id"><label class="label">Estado</label><select v-model="form.estado" class="input"><option>ACTIVO</option><option>INACTIVO</option><option>BLOQUEADO</option></select></div>
        <p v-if="!form.id" class="text-xs text-slate-500">Se generará una contraseña temporal; el usuario deberá cambiarla en su primer ingreso.</p>
        <button class="btn-primario w-full">Guardar</button>
      </form>
    </Modal>
    <Modal v-if="clave" titulo="Contraseña temporal" @cerrar="clave = null">
      <p class="text-sm mb-2">Entregue estas credenciales a <b>{{ clave.username }}</b>. No se volverán a mostrar.</p>
      <div class="text-2xl font-mono text-center p-3 rounded bg-slate-100 dark:bg-slate-800 select-all">{{ clave.password }}</div>
      <button class="btn-primario w-full mt-3" @click="clave = null">Entendido</button>
    </Modal>
  </div>
</template>
