<script setup>
import { ref, onMounted } from 'vue'
import api, { bs, fecha } from '../api'
import { useAuth } from '../stores/auth'
import { avisar, error } from '../stores/toast'
import Modal from '../components/Modal.vue'

const auth = useAuth()
const filas = ref([])
const f = ref({ q: '', desde: '', hasta: '', estado: '' })
const det = ref(null)
const motivo = ref('')

async function cargar() {
  try {
    const p = Object.fromEntries(Object.entries(f.value).filter(([, v]) => v))
    filas.value = (await api.get('/ventas', { params: p })).data
  } catch (e) { error(e) }
}
async function ver(id) {
  try { det.value = (await api.get(`/ventas/${id}`)).data; motivo.value = '' } catch (e) { error(e) }
}
async function anular() {
  if (!motivo.value.trim()) return error('Indique el motivo')
  if (!confirm(`¿Anular la venta ${det.value.numero_venta}? Se devolverá el stock y se revertirá la caja.`)) return
  try {
    await api.post(`/ventas/${det.value.id}/anular`, { motivo: motivo.value })
    avisar('Venta anulada')
    await ver(det.value.id)
    cargar()
  } catch (e) { error(e) }
}
onMounted(cargar)
</script>
<template>
  <div>
    <h1 class="titulo">Ventas</h1>
    <div class="card mb-4 grid sm:grid-cols-5 gap-2 items-end">
      <div class="sm:col-span-2"><label class="label">Buscar</label><input v-model="f.q" class="input" placeholder="Número o cliente" @keyup.enter="cargar" /></div>
      <div><label class="label">Desde</label><input v-model="f.desde" type="date" class="input" /></div>
      <div><label class="label">Hasta</label><input v-model="f.hasta" type="date" class="input" /></div>
      <div class="flex gap-2"><select v-model="f.estado" class="input"><option value="">Todas</option><option>COMPLETADA</option><option>ANULADA</option></select><button class="btn-primario" @click="cargar">Filtrar</button></div>
    </div>
    <div class="card overflow-x-auto">
      <table class="tabla">
        <thead><tr><th>N°</th><th>Fecha</th><th>Cliente</th><th>Cajero</th><th>Documento</th><th class="text-right">Total</th><th>Estado</th></tr></thead>
        <tbody>
          <tr v-for="v in filas" :key="v.id" class="cursor-pointer" @click="ver(v.id)">
            <td class="font-medium text-primario-600 dark:text-primario-100">{{ v.numero_venta }}</td><td>{{ fecha(v.fecha_venta) }}</td><td>{{ v.cliente }}</td><td>{{ v.cajero }}</td>
            <td>{{ v.tipo_documento }}</td><td class="text-right">{{ bs(v.total_bob) }}</td>
            <td><span class="badge" :class="v.estado === 'ANULADA' ? 'bg-red-100 text-red-700' : 'bg-green-100 text-green-700'">{{ v.estado }}</span></td>
          </tr>
        </tbody>
      </table>
      <p v-if="!filas.length" class="text-sm text-slate-500 text-center py-6">Sin ventas</p>
    </div>

    <Modal v-if="det" :titulo="`Venta ${det.numero_venta}`" ancho="max-w-3xl" @cerrar="det = null">
      <div class="grid sm:grid-cols-3 gap-2 text-sm mb-3">
        <div><span class="label">Fecha</span>{{ fecha(det.fecha_venta) }}</div>
        <div><span class="label">Cliente</span>{{ det.cliente }} {{ det.cliente_nit }}</div>
        <div><span class="label">Cajero</span>{{ det.cajero }}</div>
        <div><span class="label">Estado</span>{{ det.estado }}</div>
        <div><span class="label">Recibido / Cambio</span>{{ bs(det.monto_recibido) }} / {{ bs(det.cambio_devuelto) }}</div>
        <div><span class="label">Observaciones</span>{{ det.observaciones || '—' }}</div>
      </div>
      <table class="tabla mb-3">
        <thead><tr><th>Producto</th><th>Cant.</th><th>Unidad</th><th class="text-right">P. unit</th><th class="text-right">Desc.</th><th class="text-right">Subtotal</th></tr></thead>
        <tbody><tr v-for="d in det.detalle" :key="d.id">
          <td>{{ d.nombre }} <span class="text-xs text-slate-500">{{ d.codigo_variante }}</span></td><td>{{ d.cantidad }}</td><td>{{ d.unidad }}</td>
          <td class="text-right">{{ bs(d.precio_unitario_bob) }}</td><td class="text-right">{{ bs(d.descuento_bob) }}</td><td class="text-right">{{ bs(d.subtotal_bob) }}</td>
        </tr></tbody>
        <tfoot><tr><td colspan="5" class="text-right font-bold">Total</td><td class="text-right font-bold">{{ bs(det.total_bob) }}</td></tr></tfoot>
      </table>
      <div v-if="det.auditoria?.length" class="mb-3">
        <h4 class="font-semibold text-sm mb-1">Historial (bitácora)</h4>
        <ul class="text-xs space-y-1"><li v-for="(a, k) in det.auditoria" :key="k">{{ fecha(a.fecha_hora) }} · <b>{{ a.accion }}</b> · {{ a.username }} {{ a.datos_nuevos?.motivo ? '· ' + a.datos_nuevos.motivo : '' }}</li></ul>
      </div>
      <div v-if="det.estado !== 'ANULADA' && auth.puede('venta.anular')" class="flex gap-2 border-t dark:border-slate-800 pt-3">
        <input v-model="motivo" class="input" placeholder="Motivo de anulación (obligatorio)" />
        <button class="btn-peligro whitespace-nowrap" @click="anular">Anular venta</button>
      </div>
    </Modal>
  </div>
</template>
