<script setup>
import { ref, computed, onMounted } from 'vue'
import api, { bs, fecha } from '../api'
import { useAuth } from '../stores/auth'
import { avisar, error } from '../stores/toast'
import Modal from '../components/Modal.vue'

const auth = useAuth()
const filas = ref([])
const proveedores = ref([])
const productos = ref([])
const tasas = ref({})
const form = ref(null)
const det = ref(null)
const motivo = ref('')

async function cargar() {
  try { filas.value = (await api.get('/compras')).data } catch (e) { error(e) }
}
onMounted(cargar)

async function nueva() {
  try {
    const [pv, pr, t] = await Promise.all([api.get('/proveedores'), api.get('/productos'), api.get('/tasas/activas')])
    proveedores.value = pv.data.filter((x) => x.estado === 'ACTIVO')
    productos.value = pr.data
    tasas.value = t.data
    form.value = { proveedor_id: proveedores.value[0]?.id, tipo_documento: 'FACTURA', numero_documento: '', tasa_cambio_aplicada: '', observaciones: '', items: [] }
    agregarItem()
  } catch (e) { error(e) }
}
const detalles = ref({})
async function cargarDetalle(id) {
  if (id && !detalles.value[id]) detalles.value[id] = (await api.get(`/productos/${id}`)).data
}
function agregarItem() { form.value.items.push({ producto_id: null, variante_id: null, unidad: 'UNIDAD', cantidad: 1, costo_unitario_usd: 0 }) }
async function cambiarProducto(it) {
  it.variante_id = null; it.unidad = 'UNIDAD'
  await cargarDetalle(it.producto_id)
  const d = detalles.value[it.producto_id]
  it.costo_unitario_usd = d && !d.es_matricial ? d.costo_base_usd : 0
}
function cambiarVariante(it) {
  const v = detalles.value[it.producto_id]?.variantes.find((x) => x.id === it.variante_id)
  if (v) it.costo_unitario_usd = v.costo_usd
}
const tasaProv = computed(() => {
  const p = proveedores.value.find((x) => x.id === form.value?.proveedor_id)
  const t = p?.tipo_cambio_preferido
  return Number(form.value?.tasa_cambio_aplicada) || (t === 'PARALELO' ? tasas.value.paralelo : t === 'BCB' ? tasas.value.bcb : tasas.value.sistema)
})
const totalUsd = computed(() => (form.value?.items || []).reduce((s, i) => s + i.cantidad * i.costo_unitario_usd, 0))

async function guardar() {
  const items = form.value.items.filter((i) => i.producto_id)
  if (!items.length) return error('Agregue productos')
  try {
    const { data } = await api.post('/compras', { ...form.value, items, tasa_cambio_aplicada: form.value.tasa_cambio_aplicada || undefined })
    avisar(`Compra ${data.numero_compra} registrada`)
    form.value = null
    cargar()
  } catch (e) { error(e) }
}
async function ver(id) { try { det.value = (await api.get(`/compras/${id}`)).data; motivo.value = '' } catch (e) { error(e) } }
async function anular() {
  if (!motivo.value.trim()) return error('Indique el motivo')
  if (!confirm('¿Anular la compra? Se descontará el stock ingresado.')) return
  try { await api.post(`/compras/${det.value.id}/anular`, { motivo: motivo.value }); avisar('Compra anulada'); det.value = null; cargar() } catch (e) { error(e) }
}
</script>
<template>
  <div>
    <div class="flex items-center justify-between mb-4">
      <h1 class="titulo mb-0">Compras</h1>
      <button v-if="auth.puede('proveedor.crear')" class="btn-primario" @click="nueva">+ Nueva compra</button>
    </div>
    <div class="card overflow-x-auto">
      <table class="tabla">
        <thead><tr><th>N°</th><th>Fecha</th><th>Proveedor</th><th>Documento</th><th class="text-right">USD</th><th class="text-right">Tasa</th><th class="text-right">Total Bs</th><th>Estado</th></tr></thead>
        <tbody><tr v-for="c in filas" :key="c.id" class="cursor-pointer" @click="ver(c.id)">
          <td class="font-medium text-primario-600 dark:text-primario-100">{{ c.numero_compra }}</td><td>{{ c.fecha_compra }}</td><td>{{ c.proveedor }}</td>
          <td>{{ c.tipo_documento }} {{ c.numero_documento }}</td><td class="text-right">{{ c.subtotal_usd.toFixed(2) }}</td><td class="text-right">{{ c.tasa_cambio_aplicada }}</td>
          <td class="text-right">{{ bs(c.total_bob) }}</td>
          <td><span class="badge" :class="c.estado === 'ANULADA' ? 'bg-red-100 text-red-700' : 'bg-green-100 text-green-700'">{{ c.estado }}</span></td>
        </tr></tbody>
      </table>
      <p v-if="!filas.length" class="text-sm text-slate-500 text-center py-6">Sin compras</p>
    </div>

    <Modal v-if="form" titulo="Nueva compra" ancho="max-w-4xl" @cerrar="form = null">
      <form class="space-y-3" @submit.prevent="guardar">
        <p v-if="!proveedores.length" class="text-sm text-red-600">Primero registre un proveedor.</p>
        <div class="grid sm:grid-cols-4 gap-2">
          <div class="sm:col-span-2"><label class="label">Proveedor</label><select v-model="form.proveedor_id" class="input" required><option v-for="p in proveedores" :key="p.id" :value="p.id">{{ p.nombre }}</option></select></div>
          <div><label class="label">Documento</label><select v-model="form.tipo_documento" class="input"><option>FACTURA</option><option>RECIBO</option><option>NOTA</option></select></div>
          <div><label class="label">N° documento</label><input v-model="form.numero_documento" class="input" /></div>
          <div><label class="label">Tasa (vacío = activa: {{ tasaProv }})</label><input v-model="form.tasa_cambio_aplicada" type="number" step="0.0001" min="0" class="input" /></div>
          <div class="sm:col-span-3"><label class="label">Observaciones</label><input v-model="form.observaciones" class="input" /></div>
        </div>
        <table class="tabla">
          <thead><tr><th>Producto</th><th>Variante</th><th>Unidad</th><th>Cantidad</th><th>Costo USD</th><th class="text-right">Subtotal</th><th></th></tr></thead>
          <tbody><tr v-for="(it, k) in form.items" :key="k">
            <td><select v-model="it.producto_id" class="input !py-1" @change="cambiarProducto(it)"><option :value="null">—</option><option v-for="p in productos" :key="p.id" :value="p.id">{{ p.codigo }} · {{ p.nombre }}</option></select></td>
            <td><select v-if="detalles[it.producto_id]?.es_matricial" v-model="it.variante_id" class="input !py-1" required @change="cambiarVariante(it)"><option v-for="v in detalles[it.producto_id].variantes" :key="v.id" :value="v.id">{{ v.eje_x_valor }}×{{ v.eje_y_valor }}</option></select></td>
            <td><select v-model="it.unidad" class="input !py-1"><option>UNIDAD</option><option v-for="u in detalles[it.producto_id]?.unidades || []" :key="u.id" :value="u.nombre_unidad">{{ u.nombre_unidad }} (x{{ u.factor_conversion }})</option></select></td>
            <td><input v-model.number="it.cantidad" type="number" min="0.01" step="0.01" class="input !py-1 w-24" /></td>
            <td><input v-model.number="it.costo_unitario_usd" type="number" min="0" step="0.0001" class="input !py-1 w-28" /></td>
            <td class="text-right">{{ (it.cantidad * it.costo_unitario_usd).toFixed(4) }}</td>
            <td><button type="button" class="text-red-500" @click="form.items.splice(k, 1)">✕</button></td>
          </tr></tbody>
        </table>
        <button type="button" class="btn-sec" @click="agregarItem">+ Producto</button>
        <div class="flex flex-wrap justify-end gap-6 text-lg border-t dark:border-slate-800 pt-3">
          <span>USD <b>{{ totalUsd.toFixed(2) }}</b></span><span>Total <b>{{ bs(totalUsd * tasaProv) }}</b></span>
        </div>
        <button class="btn-primario w-full" :disabled="!proveedores.length">Registrar compra (pago en efectivo)</button>
      </form>
    </Modal>

    <Modal v-if="det" :titulo="`Compra ${det.numero_compra}`" ancho="max-w-3xl" @cerrar="det = null">
      <div class="grid sm:grid-cols-3 gap-2 text-sm mb-3">
        <div><span class="label">Proveedor</span>{{ det.proveedor }}</div><div><span class="label">Fecha</span>{{ det.fecha_compra }}</div>
        <div><span class="label">Registró</span>{{ det.username }}</div><div><span class="label">Estado</span>{{ det.estado }}</div>
        <div><span class="label">Tasa</span>{{ det.tasa_cambio_aplicada }}</div><div><span class="label">Obs.</span>{{ det.observaciones || '—' }}</div>
      </div>
      <table class="tabla mb-3"><thead><tr><th>Producto</th><th>Cant.</th><th>Unidad</th><th class="text-right">Costo USD</th><th class="text-right">Subtotal USD</th></tr></thead>
        <tbody><tr v-for="d in det.detalle" :key="d.id"><td>{{ d.nombre }} <span class="text-xs">{{ d.codigo_variante }}</span></td><td>{{ d.cantidad }}</td><td>{{ d.unidad }}</td><td class="text-right">{{ d.costo_unitario_usd }}</td><td class="text-right">{{ d.subtotal_usd }}</td></tr></tbody>
        <tfoot><tr><td colspan="4" class="text-right font-bold">Total</td><td class="text-right font-bold">{{ bs(det.total_bob) }}</td></tr></tfoot></table>
      <div v-if="det.estado !== 'ANULADA' && auth.puede('proveedor.anular')" class="flex gap-2 border-t dark:border-slate-800 pt-3">
        <input v-model="motivo" class="input" placeholder="Motivo de anulación" /><button class="btn-peligro whitespace-nowrap" @click="anular">Anular compra</button>
      </div>
    </Modal>
  </div>
</template>
