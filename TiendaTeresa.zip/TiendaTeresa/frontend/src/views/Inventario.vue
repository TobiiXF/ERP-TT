<script setup>
import { ref, onMounted } from 'vue'
import { useRoute, useRouter } from 'vue-router'
import api, { bs } from '../api'
import { useAuth } from '../stores/auth'
import { avisar, error } from '../stores/toast'
import Modal from '../components/Modal.vue'
import Icono from '../components/Icono.vue'

const auth = useAuth()
const route = useRoute()
const router = useRouter()
const productos = ref([])
const categorias = ref([])
const q = ref('')
const categoria = ref('')
const soloBajo = ref(route.query.bajo === '1')
const form = ref(null)
const nuevaCat = ref(null)
const vacio = () => ({ codigo: '', nombre: '', descripcion: '', categoria_id: categorias.value[0]?.id, es_matricial: false, unidad_base: 'UNIDAD',
  costo_base_usd: 0, margen_ganancia: 30, tipo_cambio_preferido: 'DEFECTO_SISTEMA', stock_minimo: 0, stock_inicial: 0, ubicacion_almacen: '' })

async function cargar() {
  try {
    productos.value = (await api.get('/productos', { params: { q: q.value, categoria_id: categoria.value || undefined } })).data
      .filter((p) => !soloBajo.value || p.stock_actual <= p.stock_minimo)
  } catch (e) { error(e) }
}
onMounted(async () => {
  try { categorias.value = (await api.get('/productos/categorias')).data } catch (e) { error(e) }
  cargar()
})
async function guardar() {
  try {
    const { data } = await api.post('/productos', form.value)
    avisar('Producto creado')
    form.value = null
    router.push(`/inventario/${data.id}`)
  } catch (e) { error(e) }
}
async function guardarCat() {
  try {
    await api.post('/productos/categorias', nuevaCat.value)
    categorias.value = (await api.get('/productos/categorias')).data
    if (form.value) form.value.categoria_id = categorias.value.at(-1)?.id
    nuevaCat.value = null
  } catch (e) { error(e) }
}
</script>
<template>
  <div>
    <div class="flex flex-wrap items-center justify-between gap-2 mb-4">
      <h1 class="titulo mb-0">Inventario</h1>
      <div class="flex gap-2">
        <button v-if="auth.puede('inventario.crear')" class="btn-sec" @click="nuevaCat = { nombre: '' }">+ Categoría</button>
        <button v-if="auth.puede('inventario.crear')" class="btn-primario" @click="form = vacio()">+ Nuevo producto</button>
      </div>
    </div>
    <div class="card mb-4 flex flex-wrap gap-2 items-center">
      <input v-model="q" class="input flex-1 min-w-[200px]" placeholder="Buscar por nombre o código" @input="cargar" />
      <select v-model="categoria" class="input max-w-[200px]" @change="cargar"><option value="">Todas las categorías</option><option v-for="c in categorias" :key="c.id" :value="c.id">{{ c.nombre }}</option></select>
      <label class="flex items-center gap-2 text-sm"><input v-model="soloBajo" type="checkbox" @change="cargar" /> Solo stock bajo</label>
    </div>
    <div class="card overflow-x-auto">
      <table class="tabla">
        <thead><tr><th></th><th>Código</th><th>Nombre</th><th>Categoría</th><th>Tipo</th><th class="text-right">Costo USD</th><th v-if="auth.puede('inventario.ver_margenes')" class="text-right">Margen</th><th class="text-right">Precio</th><th class="text-right">Stock</th></tr></thead>
        <tbody>
          <tr v-for="p in productos" :key="p.id" class="cursor-pointer" @click="router.push(`/inventario/${p.id}`)">
            <td class="w-10"><img v-if="p.imagen_url" :src="p.imagen_url" class="w-8 h-8 rounded object-cover" /><Icono v-else n="perno" c="w-6 h-6 text-slate-400" /></td>
            <td class="font-mono text-xs">{{ p.codigo }}</td><td class="font-medium">{{ p.nombre }}</td><td>{{ p.categoria }}</td>
            <td><span v-if="p.es_matricial" class="badge bg-acento-400/20 text-acento-600">Matricial ({{ p.num_variantes }})</span><span v-else class="badge bg-slate-100 dark:bg-slate-800">Simple</span></td>
            <td class="text-right">{{ p.es_matricial ? '—' : p.costo_base_usd.toFixed(4) }}</td>
            <td v-if="auth.puede('inventario.ver_margenes')" class="text-right">{{ p.margen_ganancia }}%</td>
            <td class="text-right">{{ p.es_matricial ? 'Por variante' : bs(p.precio_venta_bob) }}</td>
            <td class="text-right"><span :class="p.stock_actual <= p.stock_minimo ? 'text-red-600 font-bold' : ''">{{ p.stock_actual }}</span> <span class="text-xs text-slate-500">{{ p.unidad_base }}</span></td>
          </tr>
        </tbody>
      </table>
      <p v-if="!productos.length" class="text-sm text-slate-500 text-center py-6">Sin productos</p>
    </div>

    <Modal v-if="form" titulo="Nuevo producto" ancho="max-w-2xl" @cerrar="form = null">
      <form class="grid sm:grid-cols-2 gap-3" @submit.prevent="guardar">
        <div><label class="label">Código *</label><input v-model="form.codigo" class="input" required /></div>
        <div><label class="label">Nombre *</label><input v-model="form.nombre" class="input" required /></div>
        <div><label class="label">Categoría *</label><select v-model="form.categoria_id" class="input" required><option v-for="c in categorias" :key="c.id" :value="c.id">{{ c.nombre }}</option></select></div>
        <div><label class="label">Unidad base</label><input v-model="form.unidad_base" class="input" /></div>
        <label class="sm:col-span-2 flex items-center gap-2 text-sm"><input v-model="form.es_matricial" type="checkbox" /> Producto matricial (tiene variantes: medida × largo, etc.)</label>
        <template v-if="!form.es_matricial">
          <div><label class="label">Costo base USD</label><input v-model.number="form.costo_base_usd" type="number" step="0.0001" min="0" class="input" /></div>
          <div><label class="label">Stock inicial</label><input v-model.number="form.stock_inicial" type="number" step="0.01" min="0" class="input" /></div>
        </template>
        <div v-if="auth.puede('inventario.ver_margenes')"><label class="label">Margen de ganancia %</label><input v-model.number="form.margen_ganancia" type="number" step="0.01" min="0" class="input" /></div>
        <div><label class="label">Tipo de cambio</label><select v-model="form.tipo_cambio_preferido" class="input"><option>DEFECTO_SISTEMA</option><option>BCB</option><option>PARALELO</option></select></div>
        <div><label class="label">Stock mínimo</label><input v-model.number="form.stock_minimo" type="number" min="0" class="input" /></div>
        <div><label class="label">Ubicación en almacén</label><input v-model="form.ubicacion_almacen" class="input" /></div>
        <div class="sm:col-span-2"><label class="label">Descripción</label><textarea v-model="form.descripcion" class="input" rows="2" /></div>
        <button class="btn-primario sm:col-span-2">Crear producto</button>
      </form>
    </Modal>
    <Modal v-if="nuevaCat" titulo="Nueva categoría" @cerrar="nuevaCat = null">
      <form class="space-y-3" @submit.prevent="guardarCat"><input v-model="nuevaCat.nombre" class="input" placeholder="Nombre" required /><button class="btn-primario w-full">Guardar</button></form>
    </Modal>
  </div>
</template>
