<script setup>
import { ref, computed, onMounted, onUnmounted } from 'vue'
import api, { bs } from '../api'
import { error } from '../stores/toast'

const d = ref(null)
const desde = ref('')
const hasta = ref('')
const esOscuro = () => document.documentElement.classList.contains('dark')
const modo = ref(esOscuro())
const obs = new MutationObserver(() => { modo.value = esOscuro() })
onMounted(() => obs.observe(document.documentElement, { attributes: true, attributeFilter: ['class'] }))
onUnmounted(() => obs.disconnect())
const oscuro = () => modo.value

async function cargar() {
  try {
    d.value = (await api.get('/reportes/dashboard', { params: { desde: desde.value || undefined, hasta: hasta.value || undefined } })).data
  } catch (e) { error(e) }
}
onMounted(cargar)

const base = () => ({
  chart: { toolbar: { show: false }, background: 'transparent', fontFamily: 'inherit' },
  theme: { mode: oscuro() ? 'dark' : 'light' },
  dataLabels: { enabled: false },
  grid: { borderColor: oscuro() ? '#1e293b' : '#e2e8f0' },
})
const barras = (lista, color) => ({
  series: [{ name: 'Cantidad', data: lista.map((p) => p.cantidad) }],
  options: { ...base(), colors: [color], plotOptions: { bar: { horizontal: true, borderRadius: 4 } },
    xaxis: { categories: lista.map((p) => p.nombre) } },
})
const mas = computed(() => barras(d.value?.mas_vendidos || [], '#2f6db5'))
const menos = computed(() => barras(d.value?.menos_vendidos || [], '#f59e0b'))
const linea = computed(() => ({
  series: [{ name: 'Ventas Bs', data: (d.value?.ventas_por_dia || []).map((x) => x.total) }],
  options: { ...base(), colors: ['#2f6db5'], stroke: { curve: 'smooth', width: 3 },
    xaxis: { categories: (d.value?.ventas_por_dia || []).map((x) => x.dia.slice(5)) },
    yaxis: { min: 0, forceNiceScale: true, labels: { formatter: (v) => (v >= 100 ? v.toFixed(0) : v.toFixed(1)) } } },
}))
</script>
<template>
  <div>
    <div class="flex flex-wrap items-end justify-between gap-3 mb-4">
      <h1 class="titulo mb-0">Dashboard</h1>
      <div class="flex flex-wrap items-end gap-2 w-full sm:w-auto">
        <div class="flex-1 min-w-[8rem]"><label class="label">Desde</label><input v-model="desde" type="date" class="input" /></div>
        <div class="flex-1 min-w-[8rem]"><label class="label">Hasta</label><input v-model="hasta" type="date" class="input" /></div>
        <button class="btn-primario" @click="cargar">Filtrar</button>
      </div>
    </div>
    <div v-if="d" class="space-y-4">
      <div class="grid grid-cols-2 lg:grid-cols-5 gap-4">
        <div class="card"><div class="label">Ventas hoy</div><div class="text-2xl font-bold">{{ bs(d.kpi.ventas_hoy) }}</div><div class="text-xs text-slate-500">{{ d.kpi.num_ventas_hoy }} ventas</div></div>
        <div class="card"><div class="label">Ventas del mes</div><div class="text-2xl font-bold">{{ bs(d.kpi.ventas_mes) }}</div></div>
        <div class="card"><div class="label">Productos</div><div class="text-2xl font-bold">{{ d.kpi.productos }}</div></div>
        <router-link to="/inventario?bajo=1" class="card hover:ring-2 ring-acento-500"><div class="label">Stock bajo</div><div class="text-2xl font-bold text-acento-600">{{ d.kpi.stock_bajo }}</div></router-link>
        <div class="card"><div class="label">Tasa sistema</div><div class="text-2xl font-bold">{{ d.kpi.tasa }}</div></div>
      </div>
      <div class="card min-w-0"><h2 class="font-semibold mb-2">Ventas últimos 14 días</h2>
        <apexchart :key="modo" type="area" height="260" :options="linea.options" :series="linea.series" /></div>
      <div class="grid grid-cols-1 lg:grid-cols-2 gap-4">
        <div class="card min-w-0"><h2 class="font-semibold mb-2">Top 10 más vendidos</h2>
          <p v-if="!d.mas_vendidos.length" class="text-sm text-slate-500 py-8 text-center">Sin ventas en el periodo</p>
          <apexchart :key="modo" v-else type="bar" height="320" :options="mas.options" :series="mas.series" /></div>
        <div class="card min-w-0"><h2 class="font-semibold mb-2">Top 10 menos vendidos</h2>
          <apexchart :key="modo" type="bar" height="320" :options="menos.options" :series="menos.series" /></div>
      </div>
    </div>
  </div>
</template>
