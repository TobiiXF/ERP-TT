<template>
  <div>
    <h1 class="titulo">Activos Fijos</h1>
    <div class="card max-w-2xl">
      <p class="font-semibold">Módulo en construcción (fase 2)</p>
      <p class="text-sm text-slate-500 mt-2">Aquí se registrarán los bienes de la tienda que no son mercadería (estantes, computadoras, vehículos...)
        y se calculará su depreciación con su asiento contable. La tabla <code>activos_fijos</code> ya existe en la base de datos.</p>
    </div>
  </div>
</template>
