<script setup>
import { ref, onMounted } from 'vue'
import api, { fecha } from '../api'
import { error } from '../stores/toast'

const filas = ref([])
const tabla = ref('')
const accion = ref('')
const abierto = ref(null)
async function cargar() {
  try { filas.value = (await api.get('/reportes/bitacora', { params: { tabla: tabla.value || undefined, accion: accion.value || undefined } })).data } catch (e) { error(e) }
}
onMounted(cargar)
</script>
<template>
  <div>
    <h1 class="titulo">Bitácora de auditoría</h1>
    <div class="card mb-4 flex flex-wrap gap-2 items-end">
      <div><label class="label">Tabla</label>
        <select v-model="tabla" class="input"><option value="">Todas</option>
          <option v-for="t in ['usuarios','productos','variantes_productos','ventas','compras','proveedores','tasas_de_cambio','configuracion_sistema','clientes']" :key="t">{{ t }}</option></select></div>
      <div><label class="label">Acción</label>
        <select v-model="accion" class="input"><option value="">Todas</option>
          <option v-for="a in ['CREAR','EDITAR','ANULAR','LOGIN','LOGIN_FALLIDO','LOGOUT','RESET_PASSWORD']" :key="a">{{ a }}</option></select></div>
      <button class="btn-primario" @click="cargar">Filtrar</button>
    </div>
    <div class="card overflow-x-auto">
      <table class="tabla">
        <thead><tr><th>Fecha</th><th>Usuario</th><th>Acción</th><th>Tabla</th><th>ID</th><th>IP</th><th></th></tr></thead>
        <tbody>
          <template v-for="b in filas" :key="b.id">
            <tr><td>{{ fecha(b.fecha_hora) }}</td><td>{{ b.username || '—' }}</td><td><span class="badge bg-primario-100 text-primario-700">{{ b.accion }}</span></td>
              <td>{{ b.tabla_afectada }}</td><td>{{ b.registro_id }}</td><td>{{ b.ip_origen }}</td>
              <td><button v-if="b.datos_anteriores || b.datos_nuevos" class="text-primario-600 text-xs" @click="abierto = abierto === b.id ? null : b.id">detalle</button></td></tr>
            <tr v-if="abierto === b.id"><td colspan="7"><div class="grid md:grid-cols-2 gap-2 text-xs">
              <pre class="bg-slate-100 dark:bg-slate-800 p-2 rounded overflow-auto">Antes: {{ JSON.stringify(b.datos_anteriores, null, 2) }}</pre>
              <pre class="bg-slate-100 dark:bg-slate-800 p-2 rounded overflow-auto">Después: {{ JSON.stringify(b.datos_nuevos, null, 2) }}</pre></div></td></tr>
          </template>
        </tbody>
      </table>
    </div>
  </div>
</template>
