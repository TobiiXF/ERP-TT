<script setup>
import { ref } from 'vue'
import { useRouter } from 'vue-router'
import api from '../api'
import { useAuth } from '../stores/auth'
import { primeraRuta } from '../router'
import { avisar } from '../stores/toast'

const auth = useAuth()
const router = useRouter()
const f = ref({ actual: '', nueva: '', repetir: '' })
const error = ref('')

async function guardar() {
  error.value = ''
  if (f.value.nueva !== f.value.repetir) return (error.value = 'Las contraseñas no coinciden')
  try {
    const { data } = await api.post('/auth/cambiar-password', { actual: f.value.actual, nueva: f.value.nueva })
    auth.user = data.user
    avisar('Contraseña actualizada')
    router.push(primeraRuta(auth))
  } catch (e) {
    error.value = e.mensaje
  }
}
</script>
<template>
  <div class="min-h-screen flex items-center justify-center p-4">
    <form class="card w-full max-w-sm space-y-4" @submit.prevent="guardar">
      <h1 class="text-xl font-bold">Cambiar contraseña</h1>
      <p v-if="auth.user?.debe_cambiar_password" class="text-sm rounded bg-acento-400/20 p-2">Su contraseña es temporal. Debe cambiarla para continuar.</p>
      <div><label class="label">Contraseña actual</label><input v-model="f.actual" type="password" class="input" required /></div>
      <div><label class="label">Nueva contraseña</label><input v-model="f.nueva" type="password" class="input" required minlength="4" /></div>
      <div><label class="label">Repetir nueva contraseña</label><input v-model="f.repetir" type="password" class="input" required /></div>
      <p v-if="error" class="text-sm text-red-600">{{ error }}</p>
      <div class="flex gap-2">
        <button class="btn-primario flex-1">Guardar</button>
        <button v-if="!auth.user?.debe_cambiar_password" type="button" class="btn-sec" @click="router.back()">Volver</button>
        <button v-else type="button" class="btn-sec" @click="auth.logout().then(() => router.push('/login'))">Salir</button>
      </div>
    </form>
  </div>
</template>
