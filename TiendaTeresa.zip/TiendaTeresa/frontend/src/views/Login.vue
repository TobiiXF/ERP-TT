<script setup>
import { ref } from 'vue'
import { useRouter } from 'vue-router'
import { useAuth } from '../stores/auth'
import { primeraRuta } from '../router'
import Icono from '../components/Icono.vue'

const auth = useAuth()
const router = useRouter()
const username = ref('')
const password = ref('')
const error = ref('')
const cargando = ref(false)

async function entrar() {
  error.value = ''
  cargando.value = true
  try {
    const u = await auth.login(username.value.trim(), password.value)
    router.push(u.debe_cambiar_password ? '/cambiar-password' : primeraRuta(auth))
  } catch (e) {
    error.value = e.mensaje
  } finally {
    cargando.value = false
  }
}
</script>
<template>
  <div class="min-h-screen flex items-center justify-center bg-primario-900 p-4">
    <form class="card w-full max-w-sm space-y-4" @submit.prevent="entrar">
      <div class="text-center">
        <Icono n="perno" c="w-12 h-12 mx-auto text-primario-600" />
        <h1 class="text-2xl font-bold">Tienda<span class="text-acento-500">Teresa</span></h1>
        <p class="text-sm text-slate-500">Ingrese sus credenciales</p>
      </div>
      <div><label class="label">Usuario</label><input v-model="username" class="input" autofocus required autocomplete="username" /></div>
      <div><label class="label">Contraseña</label><input v-model="password" type="password" class="input" required autocomplete="current-password" /></div>
      <p v-if="error" class="text-sm text-red-600 dark:text-red-400">{{ error }}</p>
      <button class="btn-primario w-full" :disabled="cargando">{{ cargando ? 'Ingresando…' : 'Ingresar' }}</button>
    </form>
  </div>
</template>
