<script setup>
import { ref, onMounted } from 'vue'
import { useRoute } from 'vue-router'
import api, { bs, fecha } from '../api'
import { error } from '../stores/toast'

const propio = useRoute().path === '/mi-arqueo'
const dia = ref(new Date().toLocaleDateString('en-CA'))
const d = ref({ resumen: [], movimientos: [] })
async function cargar() {
  try { d.value = (await api.get('/reportes/arqueo', { params: { fecha: dia.value } })).data } catch (e) { error(e) }
}
onMounted(cargar)
</script>
<template>
  <div>
    <div class="flex flex-wrap items-end justify-between gap-3 mb-4">
      <h1 class="titulo mb-0">{{ propio ? 'Arqueo de mi turno' : 'Caja' }}</h1>
      <div class="flex items-end gap-2"><div><label class="label">Fecha</label><input v-model="dia" type="date" class="input" @change="cargar" /></div></div>
    </div>
    <div class="grid md:grid-cols-3 gap-4 mb-4">
      <div v-for="r in d.resumen" :key="r.usuario_id" class="card">
        <div class="font-semibold">{{ r.username }}</div>
        <div class="text-sm mt-2 space-y-1">
          <div class="flex justify-between"><span>Entradas</span><span class="text-green-600">{{ bs(r.entradas_bob) }}</span></div>
          <div class="flex justify-between"><span>Salidas</span><span class="text-red-600">{{ bs(r.salidas_bob) }}</span></div>
          <div class="flex justify-between"><span>Ajustes</span><span>{{ bs(r.ajustes_bob) }}</span></div>
          <div class="flex justify-between font-bold border-t pt-1 dark:border-slate-700"><span>Saldo</span><span>{{ bs(r.saldo_bob) }}</span></div>
        </div>
      </div>
      <p v-if="!d.resumen.length" class="text-sm text-slate-500">Sin movimientos en la fecha.</p>
    </div>
    <div class="card overflow-x-auto">
      <table class="tabla">
        <thead><tr><th>Hora</th><th>Tipo</th><th>Documento</th><th>Descripción</th><th>Usuario</th><th class="text-right">Monto</th></tr></thead>
        <tbody><tr v-for="m in d.movimientos" :key="m.id">
          <td>{{ fecha(m.fecha_hora).slice(11) }}</td><td>{{ m.tipo_movimiento }}</td><td>{{ m.documento_referencia }}</td>
          <td>{{ m.descripcion }}</td><td>{{ m.username }}</td><td class="text-right">{{ bs(m.monto_bob) }}</td>
        </tr></tbody>
      </table>
    </div>
  </div>
</template>
