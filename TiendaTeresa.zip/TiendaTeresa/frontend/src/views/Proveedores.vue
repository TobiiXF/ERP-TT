<script setup>
import { ref, onMounted } from 'vue'
import api from '../api'
import { useAuth } from '../stores/auth'
import { avisar, error } from '../stores/toast'
import Modal from '../components/Modal.vue'

const auth = useAuth()
const filas = ref([])
const form = ref(null)
async function cargar() { try { filas.value = (await api.get('/proveedores')).data } catch (e) { error(e) } }
onMounted(cargar)
async function guardar() {
  try {
    if (form.value.id) await api.put(`/proveedores/${form.value.id}`, form.value)
    else await api.post('/proveedores', form.value)
    avisar('Proveedor guardado'); form.value = null; cargar()
  } catch (e) { error(e) }
}
async function eliminar(p) {
  if (!confirm(`¿Dar de baja a ${p.nombre}?`)) return
  try { await api.delete(`/proveedores/${p.id}`); cargar() } catch (e) { error(e) }
}
</script>
<template>
  <div>
    <div class="flex items-center justify-between mb-4">
      <h1 class="titulo mb-0">Proveedores</h1>
      <button v-if="auth.puede('proveedor.crear')" class="btn-primario" @click="form = { nombre: '', nit: '', contacto: '', telefono: '', email: '', direccion: '', tipo_cambio_preferido: 'DEFECTO_SISTEMA', condiciones_pago: '' }">+ Nuevo proveedor</button>
    </div>
    <div class="card overflow-x-auto">
      <table class="tabla">
        <thead><tr><th>Nombre</th><th>NIT</th><th>Contacto</th><th>Teléfono</th><th>Tasa</th><th>Estado</th><th></th></tr></thead>
        <tbody><tr v-for="p in filas" :key="p.id">
          <td class="font-medium">{{ p.nombre }}</td><td>{{ p.nit }}</td><td>{{ p.contacto }}</td><td>{{ p.telefono }}</td><td>{{ p.tipo_cambio_preferido }}</td>
          <td><span class="badge" :class="p.estado === 'ACTIVO' ? 'bg-green-100 text-green-700' : 'bg-slate-200 text-slate-600'">{{ p.estado }}</span></td>
          <td class="text-right whitespace-nowrap">
            <button v-if="auth.puede('proveedor.editar')" class="text-primario-600 text-xs mr-3" @click="form = { ...p }">editar</button>
            <button v-if="auth.puede('proveedor.anular')" class="text-red-600 text-xs" @click="eliminar(p)">baja</button>
          </td>
        </tr></tbody>
      </table>
      <p v-if="!filas.length" class="text-sm text-slate-500 text-center py-6">Sin proveedores</p>
    </div>
    <Modal v-if="form" :titulo="form.id ? 'Editar proveedor' : 'Nuevo proveedor'" ancho="max-w-2xl" @cerrar="form = null">
      <form class="grid sm:grid-cols-2 gap-3" @submit.prevent="guardar">
        <div><label class="label">Nombre *</label><input v-model="form.nombre" class="input" required /></div>
        <div><label class="label">NIT</label><input v-model="form.nit" class="input" /></div>
        <div><label class="label">Contacto</label><input v-model="form.contacto" class="input" /></div>
        <div><label class="label">Teléfono</label><input v-model="form.telefono" class="input" /></div>
        <div><label class="label">Email</label><input v-model="form.email" type="email" class="input" /></div>
        <div><label class="label">Tipo de cambio</label><select v-model="form.tipo_cambio_preferido" class="input"><option>DEFECTO_SISTEMA</option><option>BCB</option><option>PARALELO</option></select></div>
        <div class="sm:col-span-2"><label class="label">Dirección</label><input v-model="form.direccion" class="input" /></div>
        <div><label class="label">Condiciones de pago</label><input v-model="form.condiciones_pago" class="input" /></div>
        <div v-if="form.id"><label class="label">Estado</label><select v-model="form.estado" class="input"><option>ACTIVO</option><option>INACTIVO</option></select></div>
        <button class="btn-primario sm:col-span-2">Guardar</button>
      </form>
    </Modal>
  </div>
</template>
