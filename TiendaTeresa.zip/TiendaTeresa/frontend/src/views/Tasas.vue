<script setup>
import { ref, onMounted } from 'vue'
import api, { fecha } from '../api'
import { useAuth } from '../stores/auth'
import { avisar, error } from '../stores/toast'

const auth = useAuth()
const activas = ref({})
const historial = ref([])
const config = ref([])
const nueva = ref({ tipo: 'BCB', valor: '' })
async function cargar() {
  try {
    const [a, h, c] = await Promise.all([api.get('/tasas/activas'), api.get('/tasas'), api.get('/tasas/config')])
    activas.value = a.data; historial.value = h.data; config.value = c.data
  } catch (e) { error(e) }
}
onMounted(cargar)
async function registrar() {
  try { await api.post('/tasas', nueva.value); avisar('Tasa registrada'); nueva.value.valor = ''; cargar() } catch (e) { error(e) }
}
async function recalcular() {
  if (!confirm('¿Recalcular los precios de todos los productos con las tasas activas?')) return
  try { const { data } = await api.post('/tasas/recalcular-precios'); avisar(`${data.actualizados} precio(s) actualizado(s)`) } catch (e) { error(e) }
}
async function guardarConfig(c) {
  try { await api.put(`/tasas/config/${c.clave}`, { valor: c.valor }); avisar('Configuración guardada') } catch (e) { error(e); cargar() }
}
const opciones = { redondeo_precios: ['NINGUNO', 'MEDIO_BOLIVIANO', 'ENTERO_SUPERIOR'], tipo_tasa_sistema: ['BCB', 'PARALELO'] }
</script>
<template>
  <div>
    <h1 class="titulo">Tasas de cambio y precios</h1>
    <div class="grid sm:grid-cols-3 gap-4 mb-4">
      <div class="card"><div class="label">BCB</div><div class="text-3xl font-bold">{{ activas.bcb }}</div></div>
      <div class="card"><div class="label">Paralelo</div><div class="text-3xl font-bold">{{ activas.paralelo }}</div></div>
      <div class="card"><div class="label">Sistema (por defecto)</div><div class="text-3xl font-bold text-primario-600">{{ activas.sistema }}</div></div>
    </div>
    <div class="grid lg:grid-cols-2 gap-4">
      <div class="space-y-4">
        <form v-if="auth.puede('administrador.tasas_cambio')" class="card flex flex-wrap gap-2 items-end" @submit.prevent="registrar">
          <div><label class="label">Tipo</label><select v-model="nueva.tipo" class="input"><option>BCB</option><option>PARALELO</option></select></div>
          <div class="flex-1"><label class="label">Valor (Bs por 1 USD)</label><input v-model="nueva.valor" type="number" step="0.0001" min="0.0001" class="input" required /></div>
          <button class="btn-primario">Registrar tasa</button>
        </form>
        <div v-if="auth.puede('inventario.recalcular_precios')" class="card">
          <h2 class="font-semibold mb-1">Recálculo masivo de precios</h2>
          <p class="text-sm text-slate-500 mb-3">Precio = (Costo USD × Tasa activa) × (1 + Margen), con la regla de redondeo configurada. Queda registrado en la bitácora.</p>
          <button class="btn-acento" @click="recalcular">Recalcular todos los precios</button>
        </div>
        <div v-if="auth.puede('administrador.editar')" class="card space-y-3">
          <h2 class="font-semibold">Configuración</h2>
          <div v-for="c in config" :key="c.clave" class="grid grid-cols-[1fr_auto] gap-2 items-end">
            <div><label class="label">{{ c.descripcion }}</label>
              <select v-if="opciones[c.clave]" v-model="c.valor" class="input"><option v-for="o in opciones[c.clave]" :key="o">{{ o }}</option></select>
              <input v-else v-model="c.valor" class="input" /></div>
            <button class="btn-sec" @click="guardarConfig(c)">Guardar</button>
          </div>
        </div>
      </div>
      <div class="card overflow-x-auto">
        <h2 class="font-semibold mb-2">Historial</h2>
        <table class="tabla"><thead><tr><th>Fecha</th><th>Hora</th><th>Tipo</th><th class="text-right">Valor</th><th>Fuente</th><th>Usuario</th></tr></thead>
          <tbody><tr v-for="t in historial" :key="t.id"><td>{{ fecha(t.fecha) }}</td><td>{{ t.hora }}</td><td>{{ t.tipo }}</td><td class="text-right">{{ t.valor }}</td><td>{{ t.fuente }}</td><td>{{ t.username }}</td></tr></tbody></table>
      </div>
    </div>
  </div>
</template>
