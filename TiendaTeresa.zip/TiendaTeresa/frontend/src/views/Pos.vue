<script setup>
import { ref, computed, onMounted } from 'vue'
import api, { bs } from '../api'
import { avisar, error } from '../stores/toast'
import Modal from '../components/Modal.vue'
import Icono from '../components/Icono.vue'

const q = ref('')
const categoria = ref('')
const categorias = ref([])
const productos = ref([])
const carrito = ref([])
const clientes = ref([])
const clienteId = ref(null)
const tipoDoc = ref('NOTA_VENTA')
const recibido = ref('')
const elegir = ref(null) // producto matricial / con unidades abierto
const ticket = ref(null)
const nuevoCliente = ref(null)
const cobrando = ref(false)

async function buscar() {
  try { productos.value = (await api.get('/ventas/pos/productos', { params: { q: q.value, categoria_id: categoria.value || undefined } })).data } catch (e) { error(e) }
}
async function cargarClientes() {
  clientes.value = (await api.get('/ventas/clientes')).data
  if (!clienteId.value) clienteId.value = clientes.value.find((c) => c.es_generico)?.id
}
onMounted(async () => {
  try {
    categorias.value = (await api.get('/productos/categorias')).data
    await Promise.all([buscar(), cargarClientes()])
  } catch (e) { error(e) }
})

async function seleccionar(p) {
  try {
    const det = (await api.get(`/ventas/pos/productos/${p.id}`)).data
    if (!det.es_matricial && !det.unidades.length) return agregar(det, null, 'UNIDAD', det.precio_venta_bob, 1, det.stock_actual)
    elegir.value = det
  } catch (e) { error(e) }
}
function agregar(p, v, unidad, precio, factor, stock) {
  const clave = `${p.id}-${v?.id || 0}-${unidad}`
  const ex = carrito.value.find((i) => i.clave === clave)
  const enCarrito = carrito.value.filter((i) => i.producto_id === p.id && (i.variante_id || 0) === (v?.id || 0)).reduce((s, i) => s + i.cantidad * i.factor, 0)
  if (enCarrito + factor > stock) return error('Stock insuficiente')
  if (ex) ex.cantidad++
  else carrito.value.push({ clave, producto_id: p.id, variante_id: v?.id || null, nombre: p.nombre, detalle: v ? `${v.eje_x_valor} × ${v.eje_y_valor}` : '', unidad, factor, precio, cantidad: 1, descuento_bob: 0, stock })
  elegir.value = null
}
const total = computed(() => carrito.value.reduce((s, i) => s + i.precio * i.cantidad - Number(i.descuento_bob || 0), 0))
const cambio = computed(() => Math.max(0, Number(recibido.value || 0) - total.value))

async function cobrar() {
  if (!carrito.value.length) return
  const monto = recibido.value === '' ? total.value : Number(recibido.value)
  if (monto < total.value) return error('Monto recibido insuficiente')
  cobrando.value = true
  try {
    const { data } = await api.post('/ventas', {
      cliente_id: clienteId.value, tipo_documento: tipoDoc.value, monto_recibido: monto,
      items: carrito.value.map((i) => ({ producto_id: i.producto_id, variante_id: i.variante_id, unidad: i.unidad, cantidad: i.cantidad, descuento_bob: Number(i.descuento_bob || 0) })),
    })
    ticket.value = { ...data, items: [...carrito.value], cliente: clientes.value.find((c) => c.id === clienteId.value)?.nombre }
    carrito.value = []
    recibido.value = ''
    avisar(`Venta ${data.numero_venta} registrada`)
    buscar()
  } catch (e) { error(e) } finally { cobrando.value = false }
}
async function guardarCliente() {
  try {
    const { data } = await api.post('/ventas/clientes', nuevoCliente.value)
    await cargarClientes()
    clienteId.value = data.id
    nuevoCliente.value = null
  } catch (e) { error(e) }
}
</script>
<template>
  <div class="grid lg:grid-cols-[1fr_380px] gap-4">
    <div>
      <div class="flex gap-2 mb-3">
        <input v-model="q" class="input" placeholder="Buscar por nombre o código…" @input="buscar" autofocus />
        <select v-model="categoria" class="input max-w-[180px]" @change="buscar"><option value="">Todas</option><option v-for="c in categorias" :key="c.id" :value="c.id">{{ c.nombre }}</option></select>
      </div>
      <div class="grid grid-cols-2 sm:grid-cols-3 xl:grid-cols-4 gap-3">
        <button v-for="p in productos" :key="p.id" class="card !p-3 text-left hover:ring-2 ring-primario-500 disabled:opacity-40" :disabled="p.stock_actual <= 0" @click="seleccionar(p)">
          <div class="aspect-video rounded bg-slate-100 dark:bg-slate-800 mb-2 flex items-center justify-center overflow-hidden">
            <img v-if="p.imagen_url" :src="p.imagen_url" class="object-cover w-full h-full" /><Icono v-else n="perno" c="w-10 h-10 text-slate-400" />
          </div>
          <div class="text-xs text-slate-500">{{ p.codigo }}</div>
          <div class="font-medium text-sm leading-tight">{{ p.nombre }}</div>
          <div class="flex justify-between items-center mt-1">
            <span class="font-bold text-primario-600 dark:text-primario-100">{{ p.es_matricial ? 'Variantes' : bs(p.precio_venta_bob) }}</span>
            <span class="badge" :class="p.stock_actual > 0 ? 'bg-slate-100 dark:bg-slate-800' : 'bg-red-100 text-red-700'">{{ p.stock_actual }}</span>
          </div>
        </button>
      </div>
      <p v-if="!productos.length" class="text-sm text-slate-500 mt-6 text-center">Sin productos</p>
    </div>

    <div class="card flex flex-col lg:sticky lg:top-4 lg:max-h-[calc(100vh-2rem)]">
      <h2 class="font-bold mb-2">Venta actual</h2>
      <div class="flex gap-2 mb-2">
        <select v-model="clienteId" class="input"><option v-for="c in clientes" :key="c.id" :value="c.id">{{ c.nombre }}{{ c.nit && c.nit !== '0' ? ` (${c.nit})` : '' }}</option></select>
        <button class="btn-sec" title="Nuevo cliente" @click="nuevoCliente = { nombre: '', nit: '' }">+</button>
      </div>
      <div class="flex-1 overflow-y-auto divide-y dark:divide-slate-800 min-h-[120px]">
        <div v-for="(i, k) in carrito" :key="i.clave" class="py-2 text-sm">
          <div class="flex justify-between"><span class="font-medium">{{ i.nombre }}</span><button class="text-red-500" @click="carrito.splice(k, 1)">✕</button></div>
          <div class="text-xs text-slate-500">{{ i.detalle }} {{ i.unidad !== 'UNIDAD' ? `· ${i.unidad} (x${i.factor})` : '' }} · {{ bs(i.precio) }}</div>
          <div class="flex items-center gap-2 mt-1">
            <input v-model.number="i.cantidad" type="number" min="1" :max="Math.floor(i.stock / i.factor)" class="input !py-1 w-20" />
            <input v-model.number="i.descuento_bob" type="number" min="0" step="0.5" class="input !py-1 w-24" placeholder="Desc." title="Descuento Bs" />
            <span class="ml-auto font-semibold">{{ bs(i.precio * i.cantidad - (i.descuento_bob || 0)) }}</span>
          </div>
        </div>
        <p v-if="!carrito.length" class="text-sm text-slate-500 py-6 text-center">Agregue productos</p>
      </div>
      <div class="border-t dark:border-slate-800 pt-3 space-y-2">
        <select v-model="tipoDoc" class="input"><option value="NOTA_VENTA">Nota de venta</option><option value="TICKET">Ticket</option><option value="FACTURA_PENDIENTE">Factura (pendiente)</option></select>
        <div class="flex justify-between text-2xl font-bold"><span>Total</span><span>{{ bs(total) }}</span></div>
        <div class="flex items-center gap-2"><label class="text-sm w-24">Recibido</label><input v-model="recibido" type="number" min="0" step="0.5" class="input" :placeholder="total.toFixed(2)" /></div>
        <div class="flex justify-between text-sm"><span>Cambio</span><span class="font-semibold">{{ bs(cambio) }}</span></div>
        <button class="btn-acento w-full !py-3 text-base" :disabled="!carrito.length || cobrando" @click="cobrar">{{ cobrando ? 'Procesando…' : 'Cobrar (efectivo)' }}</button>
      </div>
    </div>

    <Modal v-if="elegir" :titulo="elegir.nombre" ancho="max-w-2xl" @cerrar="elegir = null">
      <template v-if="elegir.es_matricial">
        <p class="text-sm text-slate-500 mb-2">Seleccione la variante</p>
        <div class="grid grid-cols-2 sm:grid-cols-3 gap-2">
          <button v-for="v in elegir.variantes" :key="v.id" class="btn-sec flex-col !items-start" :disabled="v.stock_actual <= 0" @click="agregar(elegir, v, 'UNIDAD', v.precio_venta_bob, 1, v.stock_actual)">
            <span class="font-semibold">{{ v.eje_x_valor }} × {{ v.eje_y_valor }}</span>
            <span class="text-xs">{{ bs(v.precio_venta_bob) }} · stock {{ v.stock_actual }}</span>
          </button>
        </div>
      </template>
      <template v-else>
        <div class="grid grid-cols-2 gap-2">
          <button class="btn-sec flex-col" @click="agregar(elegir, null, 'UNIDAD', elegir.precio_venta_bob, 1, elegir.stock_actual)"><span class="font-semibold">{{ elegir.unidad_base }}</span><span class="text-xs">{{ bs(elegir.precio_venta_bob) }}</span></button>
          <button v-for="u in elegir.unidades" :key="u.nombre_unidad" class="btn-sec flex-col" :disabled="elegir.stock_actual < u.factor_conversion"
            @click="agregar(elegir, null, u.nombre_unidad, u.precio_venta_bob > 0 ? u.precio_venta_bob : +(elegir.precio_venta_bob * u.factor_conversion).toFixed(2), u.factor_conversion, elegir.stock_actual)">
            <span class="font-semibold">{{ u.nombre_unidad }} (x{{ u.factor_conversion }})</span>
            <span class="text-xs">{{ bs(u.precio_venta_bob > 0 ? u.precio_venta_bob : elegir.precio_venta_bob * u.factor_conversion) }}</span>
          </button>
        </div>
      </template>
    </Modal>

    <Modal v-if="nuevoCliente" titulo="Nuevo cliente" @cerrar="nuevoCliente = null">
      <form class="space-y-3" @submit.prevent="guardarCliente">
        <div><label class="label">Nombre / Razón social</label><input v-model="nuevoCliente.nombre" class="input" required /></div>
        <div><label class="label">NIT / CI</label><input v-model="nuevoCliente.nit" class="input" /></div>
        <div><label class="label">Teléfono</label><input v-model="nuevoCliente.telefono" class="input" /></div>
        <button class="btn-primario w-full">Guardar</button>
      </form>
    </Modal>

    <Modal v-if="ticket" :titulo="`Venta ${ticket.numero_venta}`" @cerrar="ticket = null">
      <div id="ticket" class="font-mono text-sm space-y-1">
        <div>Cliente: {{ ticket.cliente }}</div>
        <div v-for="i in ticket.items" :key="i.clave" class="flex justify-between"><span>{{ i.cantidad }} {{ i.unidad }} {{ i.nombre }} {{ i.detalle }}</span><span>{{ (i.precio * i.cantidad - (i.descuento_bob || 0)).toFixed(2) }}</span></div>
        <div class="border-t pt-1 flex justify-between font-bold"><span>TOTAL</span><span>{{ bs(ticket.total_bob) }}</span></div>
        <div class="flex justify-between"><span>Recibido</span><span>{{ bs(ticket.monto_recibido) }}</span></div>
        <div class="flex justify-between"><span>Cambio</span><span>{{ bs(ticket.cambio_devuelto) }}</span></div>
      </div>
      <div class="flex gap-2 mt-4"><button class="btn-sec flex-1" onclick="window.print()">Imprimir</button><button class="btn-primario flex-1" @click="ticket = null">Nueva venta</button></div>
    </Modal>
  </div>
</template>
