<script setup>
import { ref, computed, onMounted } from 'vue'
import { useRoute, useRouter } from 'vue-router'
import api, { bs, fecha } from '../api'
import { useAuth } from '../stores/auth'
import { avisar, error } from '../stores/toast'
import Modal from '../components/Modal.vue'
import Icono from '../components/Icono.vue'

const auth = useAuth()
const route = useRoute()
const router = useRouter()
const p = ref(null)
const edit = ref(null)
const categorias = ref([])
const nuevaVar = ref(null)
const editVar = ref(null)
const ajuste = ref(null)
const unidad = ref(null)
const tab = ref('matriz')

async function cargar() {
  try {
    p.value = (await api.get(`/productos/${route.params.id}`)).data
    edit.value = { ...p.value }
  } catch (e) { error(e); router.push('/inventario') }
}
onMounted(async () => {
  categorias.value = (await api.get('/productos/categorias')).data
  cargar()
})

// Vista matricial: filas = eje X (medida), columnas = eje Y (largo)
const ejesX = computed(() => [...new Set((p.value?.variantes || []).map((v) => v.eje_x_valor))])
const ejesY = computed(() => [...new Set((p.value?.variantes || []).map((v) => v.eje_y_valor))])
const celda = (x, y) => p.value.variantes.find((v) => v.eje_x_valor === x && v.eje_y_valor === y)

async function guardar() {
  try {
    await api.put(`/productos/${p.value.id}`, edit.value)
    avisar('Producto actualizado'); cargar()
  } catch (e) { error(e) }
}
async function eliminar() {
  if (!confirm('¿Dar de baja este producto? (borrado lógico)')) return
  try { await api.delete(`/productos/${p.value.id}`); avisar('Producto dado de baja'); router.push('/inventario') } catch (e) { error(e) }
}
async function subirImagen(ev) {
  const f = ev.target.files[0]
  if (!f) return
  const fd = new FormData()
  fd.append('imagen', f)
  try { await api.post(`/productos/${p.value.id}/imagen`, fd); avisar('Imagen actualizada'); cargar() } catch (e) { error(e) }
}
async function crearVariantes() {
  // Permite crear varias a la vez: ejes separados por coma -> producto cartesiano
  const xs = nuevaVar.value.x.split(',').map((s) => s.trim()).filter(Boolean)
  const ys = nuevaVar.value.y.split(',').map((s) => s.trim()).filter(Boolean)
  const lista = xs.flatMap((x) => ys.map((y) => ({ eje_x_valor: x, eje_y_valor: y, costo_usd: nuevaVar.value.costo_usd, stock_inicial: nuevaVar.value.stock_inicial })))
  try { await api.post(`/productos/${p.value.id}/variantes`, lista); avisar(`${lista.length} variante(s) creada(s)`); nuevaVar.value = null; cargar() } catch (e) { error(e) }
}
async function guardarVar() {
  try {
    await api.put(`/productos/${p.value.id}/variantes/${editVar.value.id}`, { costo_usd: editVar.value.costo_usd, eje_x_valor: editVar.value.eje_x_valor, eje_y_valor: editVar.value.eje_y_valor })
    avisar('Variante actualizada'); editVar.value = null; cargar()
  } catch (e) { error(e) }
}
async function eliminarVar() {
  if (!confirm('¿Dar de baja esta variante?')) return
  try { await api.delete(`/productos/${p.value.id}/variantes/${editVar.value.id}`); editVar.value = null; cargar() } catch (e) { error(e) }
}
async function guardarAjuste() {
  try { await api.post(`/productos/${p.value.id}/ajuste`, ajuste.value); avisar('Stock ajustado'); ajuste.value = null; cargar() } catch (e) { error(e) }
}
async function guardarUnidad() {
  try {
    if (unidad.value.id) await api.put(`/productos/${p.value.id}/unidades/${unidad.value.id}`, unidad.value)
    else await api.post(`/productos/${p.value.id}/unidades`, unidad.value)
    avisar('Unidad guardada'); unidad.value = null; cargar()
  } catch (e) { error(e) }
}
</script>
<template>
  <div v-if="p">
    <div class="flex flex-wrap items-center justify-between gap-2 mb-4">
      <div>
        <router-link to="/inventario" class="text-sm text-primario-600">← Inventario</router-link>
        <h1 class="titulo mb-0">{{ p.nombre }} <span class="text-sm font-mono text-slate-500">{{ p.codigo }}</span></h1>
      </div>
      <div class="flex gap-2">
        <button v-if="auth.puede('inventario.editar')" class="btn-sec" @click="ajuste = { tipo: 'AJUSTE', cantidad: 0, motivo: '', variante_id: p.es_matricial ? p.variantes[0]?.id : null }">Ajustar stock</button>
        <button v-if="auth.puede('inventario.anular')" class="btn-peligro" @click="eliminar">Dar de baja</button>
      </div>
    </div>

    <div class="grid lg:grid-cols-[280px_1fr] gap-4 mb-4">
      <div class="card">
        <div class="aspect-square rounded-lg bg-slate-100 dark:bg-slate-800 flex items-center justify-center overflow-hidden mb-3">
          <img v-if="p.imagen_url" :src="p.imagen_url" class="object-cover w-full h-full" /><Icono v-else n="perno" c="w-24 h-24 text-slate-400" />
        </div>
        <label v-if="auth.puede('inventario.editar')" class="btn-sec w-full cursor-pointer">Subir imagen<input type="file" accept="image/*" class="hidden" @change="subirImagen" /></label>
        <div class="mt-3 text-sm space-y-1">
          <div class="flex justify-between"><span>Stock total</span><b>{{ p.stock_actual }} {{ p.unidad_base }}</b></div>
          <div class="flex justify-between"><span>Stock mínimo</span><span>{{ p.stock_minimo }}</span></div>
          <div v-if="!p.es_matricial" class="flex justify-between"><span>Precio venta</span><b>{{ bs(p.precio_venta_bob) }}</b></div>
        </div>
      </div>
      <form class="card grid sm:grid-cols-3 gap-3 content-start" @submit.prevent="guardar">
        <div><label class="label">Código</label><input v-model="edit.codigo" class="input" :disabled="!auth.puede('inventario.editar')" /></div>
        <div class="sm:col-span-2"><label class="label">Nombre</label><input v-model="edit.nombre" class="input" :disabled="!auth.puede('inventario.editar')" /></div>
        <div><label class="label">Categoría</label><select v-model="edit.categoria_id" class="input" :disabled="!auth.puede('inventario.editar')"><option v-for="c in categorias" :key="c.id" :value="c.id">{{ c.nombre }}</option></select></div>
        <div><label class="label">Unidad base</label><input v-model="edit.unidad_base" class="input" :disabled="!auth.puede('inventario.editar')" /></div>
        <div><label class="label">Tipo de cambio</label><select v-model="edit.tipo_cambio_preferido" class="input" :disabled="!auth.puede('inventario.editar')"><option>DEFECTO_SISTEMA</option><option>BCB</option><option>PARALELO</option></select></div>
        <div v-if="!p.es_matricial"><label class="label">Costo base USD</label><input v-model.number="edit.costo_base_usd" type="number" step="0.0001" min="0" class="input" :disabled="!auth.puede('inventario.editar')" /></div>
        <div v-if="auth.puede('inventario.ver_margenes')"><label class="label">Margen %</label><input v-model.number="edit.margen_ganancia" type="number" step="0.01" min="0" class="input" :disabled="!auth.puede('inventario.editar')" /></div>
        <div><label class="label">Stock mínimo</label><input v-model.number="edit.stock_minimo" type="number" min="0" class="input" :disabled="!auth.puede('inventario.editar')" /></div>
        <div><label class="label">Ubicación</label><input v-model="edit.ubicacion_almacen" class="input" :disabled="!auth.puede('inventario.editar')" /></div>
        <div class="sm:col-span-3"><label class="label">Descripción</label><textarea v-model="edit.descripcion" rows="2" class="input" :disabled="!auth.puede('inventario.editar')" /></div>
        <div v-if="auth.puede('inventario.editar')" class="sm:col-span-3"><button class="btn-primario">Guardar cambios</button> <span class="text-xs text-slate-500 ml-2">El precio se recalcula con la fórmula Costo × Tasa × (1 + Margen)</span></div>
      </form>
    </div>

    <div class="card">
      <div class="flex gap-4 border-b dark:border-slate-800 mb-3 text-sm">
        <button v-if="p.es_matricial" class="pb-2" :class="tab === 'matriz' ? 'border-b-2 border-acento-500 font-semibold' : ''" @click="tab = 'matriz'">Variantes (matriz)</button>
        <button v-if="!p.es_matricial" class="pb-2" :class="tab === 'matriz' ? 'border-b-2 border-acento-500 font-semibold' : ''" @click="tab = 'matriz'">Unidades de venta</button>
        <button class="pb-2" :class="tab === 'kardex' ? 'border-b-2 border-acento-500 font-semibold' : ''" @click="tab = 'kardex'">Kardex</button>
      </div>

      <div v-if="tab === 'matriz' && p.es_matricial">
        <button v-if="auth.puede('inventario.crear')" class="btn-primario mb-3" @click="nuevaVar = { x: '', y: '', costo_usd: 0, stock_inicial: 0 }">+ Variantes</button>
        <div class="overflow-x-auto">
          <table v-if="p.variantes.length" class="text-sm border-collapse">
            <thead><tr><th class="p-2 text-xs text-slate-500">Medida \ Largo</th><th v-for="y in ejesY" :key="y" class="p-2 font-semibold">{{ y }}</th></tr></thead>
            <tbody><tr v-for="x in ejesX" :key="x">
              <th class="p-2 font-semibold text-left">{{ x }}</th>
              <td v-for="y in ejesY" :key="y" class="p-1">
                <button v-if="celda(x, y)" class="w-28 rounded-lg border dark:border-slate-700 p-2 text-left hover:ring-2 ring-primario-500" @click="editVar = { ...celda(x, y) }">
                  <div class="font-bold" :class="celda(x, y).stock_actual <= 0 ? 'text-red-600' : ''">{{ celda(x, y).stock_actual }} u</div>
                  <div class="text-xs">{{ bs(celda(x, y).precio_venta_bob) }}</div>
                </button>
                <div v-else class="w-28 h-14 rounded-lg border border-dashed dark:border-slate-700" />
              </td>
            </tr></tbody>
          </table>
          <p v-else class="text-sm text-slate-500">Sin variantes. Cree las combinaciones de medida × largo.</p>
        </div>
      </div>

      <div v-if="tab === 'matriz' && !p.es_matricial">
        <button v-if="auth.puede('inventario.crear')" class="btn-primario mb-3" @click="unidad = { nombre_unidad: '', factor_conversion: 1, precio_venta_bob: 0 }">+ Unidad</button>
        <table class="tabla"><thead><tr><th>Unidad</th><th>Equivale a</th><th class="text-right">Precio</th><th></th></tr></thead>
          <tbody><tr><td>{{ p.unidad_base }}</td><td>1 {{ p.unidad_base }}</td><td class="text-right">{{ bs(p.precio_venta_bob) }}</td><td></td></tr>
            <tr v-for="u in p.unidades" :key="u.id"><td>{{ u.nombre_unidad }}</td><td>{{ u.factor_conversion }} {{ p.unidad_base }}</td>
              <td class="text-right">{{ u.precio_venta_bob > 0 ? bs(u.precio_venta_bob) : bs(p.precio_venta_bob * u.factor_conversion) + ' (auto)' }}</td>
              <td><button v-if="auth.puede('inventario.editar')" class="text-primario-600 text-xs" @click="unidad = { ...u }">editar</button></td></tr></tbody></table>
      </div>

      <div v-if="tab === 'kardex'" class="overflow-x-auto">
        <table class="tabla"><thead><tr><th>Fecha</th><th>Tipo</th><th>Variante</th><th class="text-right">Cantidad</th><th class="text-right">Anterior</th><th class="text-right">Nuevo</th><th>Documento</th><th>Usuario</th></tr></thead>
          <tbody><tr v-for="k in p.kardex" :key="k.id"><td>{{ fecha(k.fecha_hora) }}</td><td>{{ k.tipo_movimiento }}</td><td>{{ k.codigo_variante }}</td>
            <td class="text-right" :class="k.cantidad < 0 ? 'text-red-600' : 'text-green-600'">{{ k.cantidad }}</td><td class="text-right">{{ k.stock_anterior }}</td><td class="text-right">{{ k.stock_nuevo }}</td>
            <td>{{ k.documento_referencia }}</td><td>{{ k.username }}</td></tr></tbody></table>
      </div>
    </div>

    <Modal v-if="nuevaVar" titulo="Nuevas variantes" @cerrar="nuevaVar = null">
      <form class="space-y-3" @submit.prevent="crearVariantes">
        <p class="text-xs text-slate-500">Separe varios valores con coma para crear todas las combinaciones (ej: 8MM, 10MM × 5CM, 8CM).</p>
        <div><label class="label">Eje X (medida)</label><input v-model="nuevaVar.x" class="input" required placeholder="10MM, 12MM" /></div>
        <div><label class="label">Eje Y (largo)</label><input v-model="nuevaVar.y" class="input" required placeholder="5CM, 8CM" /></div>
        <div><label class="label">Costo USD (c/u)</label><input v-model.number="nuevaVar.costo_usd" type="number" step="0.0001" min="0" class="input" /></div>
        <div><label class="label">Stock inicial (c/u)</label><input v-model.number="nuevaVar.stock_inicial" type="number" min="0" class="input" /></div>
        <button class="btn-primario w-full">Crear</button>
      </form>
    </Modal>
    <Modal v-if="editVar" :titulo="editVar.codigo_variante" @cerrar="editVar = null">
      <form class="space-y-3" @submit.prevent="guardarVar">
        <div class="grid grid-cols-2 gap-2"><div><label class="label">Eje X</label><input v-model="editVar.eje_x_valor" class="input" /></div><div><label class="label">Eje Y</label><input v-model="editVar.eje_y_valor" class="input" /></div></div>
        <div><label class="label">Costo USD</label><input v-model.number="editVar.costo_usd" type="number" step="0.0001" min="0" class="input" /></div>
        <div class="text-sm">Stock: <b>{{ editVar.stock_actual }}</b> · Precio: <b>{{ bs(editVar.precio_venta_bob) }}</b></div>
        <div class="flex gap-2"><button class="btn-primario flex-1" :disabled="!auth.puede('inventario.editar')">Guardar</button>
          <button type="button" class="btn-sec" @click="ajuste = { tipo: 'AJUSTE', cantidad: 0, motivo: '', variante_id: editVar.id }; editVar = null">Ajustar stock</button>
          <button v-if="auth.puede('inventario.anular')" type="button" class="btn-peligro" @click="eliminarVar">Baja</button></div>
      </form>
    </Modal>
    <Modal v-if="ajuste" titulo="Ajuste de stock" @cerrar="ajuste = null">
      <form class="space-y-3" @submit.prevent="guardarAjuste">
        <div v-if="p.es_matricial"><label class="label">Variante</label><select v-model="ajuste.variante_id" class="input"><option v-for="v in p.variantes" :key="v.id" :value="v.id">{{ v.codigo_variante }} (stock {{ v.stock_actual }})</option></select></div>
        <div><label class="label">Tipo</label><select v-model="ajuste.tipo" class="input"><option value="AJUSTE">Ajuste (+ entrada / − salida)</option><option value="MERMA">Merma (salida)</option></select></div>
        <div><label class="label">Cantidad</label><input v-model.number="ajuste.cantidad" type="number" step="0.01" class="input" required /></div>
        <div><label class="label">Motivo</label><input v-model="ajuste.motivo" class="input" required /></div>
        <button class="btn-primario w-full">Aplicar</button>
      </form>
    </Modal>
    <Modal v-if="unidad" titulo="Unidad de venta" @cerrar="unidad = null">
      <form class="space-y-3" @submit.prevent="guardarUnidad">
        <div><label class="label">Nombre (CAJA, PAQUETE, KILO…)</label><input v-model="unidad.nombre_unidad" class="input" required :disabled="!!unidad.id" /></div>
        <div><label class="label">Equivale a cuántas {{ p.unidad_base }}</label><input v-model.number="unidad.factor_conversion" type="number" step="0.0001" min="0.0001" class="input" required /></div>
        <div><label class="label">Precio Bs (0 = automático)</label><input v-model.number="unidad.precio_venta_bob" type="number" step="0.01" min="0" class="input" /></div>
        <button class="btn-primario w-full">Guardar</button>
      </form>
    </Modal>
  </div>
</template>
