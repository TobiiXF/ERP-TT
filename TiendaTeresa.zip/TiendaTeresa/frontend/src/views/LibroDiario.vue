<script setup>
import { ref, computed, onMounted } from 'vue'
import api, { bs } from '../api'
import { error } from '../stores/toast'

const hoy = new Date().toLocaleDateString('en-CA')
const desde = ref(hoy.slice(0, 8) + '01')
const hasta = ref(hoy)
const asientos = ref([])
const totales = computed(() => asientos.value.filter((a) => a.estado !== 'ANULADO')
  .reduce((t, a) => ({ debe: t.debe + Number(a.total_debe), haber: t.haber + Number(a.total_haber) }), { debe: 0, haber: 0 }))
async function cargar() {
  try { asientos.value = (await api.get('/reportes/libro-diario', { params: { desde: desde.value, hasta: hasta.value } })).data } catch (e) { error(e) }
}
onMounted(cargar)
</script>
<template>
  <div>
    <div class="flex flex-wrap items-end justify-between gap-3 mb-4">
      <h1 class="titulo mb-0">Libro diario</h1>
      <div class="flex flex-wrap items-end gap-2">
        <div><label class="label">Desde</label><input v-model="desde" type="date" class="input" /></div>
        <div><label class="label">Hasta</label><input v-model="hasta" type="date" class="input" /></div>
        <button class="btn-primario" @click="cargar">Filtrar</button>
      </div>
    </div>
    <div class="card mb-4 flex flex-wrap gap-6 text-sm">
      <div><span class="text-slate-500">Asientos:</span> <b>{{ asientos.length }}</b></div>
      <div><span class="text-slate-500">Total debe:</span> <b>{{ bs(totales.debe) }}</b></div>
      <div><span class="text-slate-500">Total haber:</span> <b>{{ bs(totales.haber) }}</b></div>
      <div class="text-slate-500">Los asientos de compras y ventas se generan solos. Los anulados no suman.</div>
    </div>
    <p v-if="!asientos.length" class="text-sm text-slate-500">Sin asientos en el periodo.</p>
    <div v-for="a in asientos" :key="a.id" class="card mb-3 overflow-x-auto" :class="a.estado === 'ANULADO' ? 'opacity-60' : ''">
      <div class="flex flex-wrap items-center gap-3 text-sm mb-2">
        <b>#{{ a.id }}</b><span>{{ a.fecha }}</span><span class="font-medium">{{ a.documento_origen }}</span>
        <span class="text-slate-500">{{ a.descripcion }}</span>
        <span class="badge" :class="a.estado === 'ANULADO' ? 'bg-red-100 text-red-700' : 'bg-green-100 text-green-700'">{{ a.estado }}</span>
        <span class="ml-auto text-slate-500">{{ a.username }}</span>
      </div>
      <table class="tabla table-fixed min-w-[32rem]">
        <thead><tr><th class="w-28">Código</th><th>Cuenta</th><th class="text-right w-36">Debe</th><th class="text-right w-36">Haber</th></tr></thead>
        <tbody><tr v-for="(l, i) in a.lineas" :key="i">
          <td>{{ l.codigo }}</td><td :class="Number(l.haber) > 0 ? 'pl-8' : ''">{{ l.cuenta }}</td>
          <td class="text-right">{{ Number(l.debe) ? bs(l.debe) : '' }}</td><td class="text-right">{{ Number(l.haber) ? bs(l.haber) : '' }}</td>
        </tr></tbody>
      </table>
    </div>
  </div>
</template>
