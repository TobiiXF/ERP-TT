<script setup>
import { ref, computed } from 'vue'
import { useRouter } from 'vue-router'
import { useAuth } from '../stores/auth'
import { menu, modulosDefecto, visible } from '../router'
import Icono from './Icono.vue'

const auth = useAuth()
const router = useRouter()
const oscuro = ref(document.documentElement.classList.contains('dark'))
const abierto = ref(false)
const grupos = computed(() =>
  (auth.user?.modulos?.length ? auth.user.modulos : modulosDefecto)
    .map((g) => ({ ...g, items: menu.filter((m) => m.modulo === g.codigo && visible(auth, m)) }))
    .filter((g) => g.items.length))

function tema() {
  oscuro.value = !oscuro.value
  document.documentElement.classList.toggle('dark', oscuro.value)
  localStorage.tema = oscuro.value ? 'oscuro' : 'claro'
}
async function salir() {
  await auth.logout()
  router.push('/login')
}
</script>
<template>
  <div class="min-h-screen flex">
    <aside class="fixed inset-y-0 left-0 z-30 w-60 bg-primario-900 text-slate-100 flex flex-col transition-transform md:translate-x-0"
      :class="abierto ? 'translate-x-0' : '-translate-x-full'">
      <div class="px-5 py-4 border-b border-white/10">
        <div class="text-lg font-bold">Tienda<span class="text-acento-400">Teresa</span></div>
        <div class="text-xs text-slate-300">{{ auth.user?.nombre_completo }} · {{ auth.user?.rol }}</div>
      </div>
      <nav class="flex-1 overflow-y-auto py-2">
        <div v-for="g in grupos" :key="g.codigo" class="mb-1">
          <div class="px-5 pt-3 pb-1 text-xs font-semibold tracking-wide text-acento-400/90">{{ g.nombre }}</div>
          <router-link v-for="m in g.items" :key="m.path" :to="m.path" @click="abierto = false"
            class="flex items-center gap-3 pl-7 pr-5 py-2 text-sm hover:bg-white/10" active-class="bg-white/10 border-l-4 border-acento-400 font-semibold">
            <Icono :n="m.icono" />{{ m.nombre }}
          </router-link>
        </div>
      </nav>
      <div class="p-3 border-t border-white/10 space-y-2">
        <button class="w-full flex items-center gap-2 text-sm px-2 py-1.5 rounded hover:bg-white/10" @click="tema"><Icono :n="oscuro ? 'sol' : 'luna'" c="w-4 h-4" />{{ oscuro ? 'Modo claro' : 'Modo nocturno' }}</button>
        <router-link to="/cambiar-password" class="flex items-center gap-2 text-sm px-2 py-1.5 rounded hover:bg-white/10"><Icono n="llave" c="w-4 h-4" />Cambiar contraseña</router-link>
        <button class="w-full flex items-center gap-2 text-sm px-2 py-1.5 rounded hover:bg-white/10 text-acento-400" @click="salir"><Icono n="salir" c="w-4 h-4" />Cerrar sesión</button>
      </div>
    </aside>
    <div v-if="abierto" class="fixed inset-0 z-20 bg-black/40 md:hidden" @click="abierto = false" />
    <main class="flex-1 md:ml-60 min-w-0">
      <header class="md:hidden flex items-center gap-3 px-4 py-3 bg-primario-900 text-white">
        <button @click="abierto = true"><Icono n="menu" c="w-6 h-6" /></button><span class="font-bold">Tienda<span class="text-acento-500">Teresa</span></span>
      </header>
      <div class="p-4 md:p-6"><router-view /></div>
    </main>
  </div>
</template>
