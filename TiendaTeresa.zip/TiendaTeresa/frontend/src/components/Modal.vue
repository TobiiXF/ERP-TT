<script setup>
defineProps({ titulo: String, ancho: { type: String, default: 'max-w-lg' } })
defineEmits(['cerrar'])
</script>
<template>
  <div class="fixed inset-0 z-40 flex items-center justify-center bg-black/50 p-4" @mousedown.self="$emit('cerrar')">
    <div class="card w-full max-h-[90vh] overflow-y-auto" :class="ancho">
      <div class="flex items-center justify-between mb-3">
        <h3 class="font-bold text-lg">{{ titulo }}</h3>
        <button class="text-slate-400 hover:text-slate-600 text-xl leading-none" @click="$emit('cerrar')">&times;</button>
      </div>
      <slot />
    </div>
  </div>
</template>
