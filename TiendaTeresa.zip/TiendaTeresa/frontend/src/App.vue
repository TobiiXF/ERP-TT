<script setup>
import { toasts } from './stores/toast'
</script>
<template>
  <router-view />
  <div class="fixed bottom-4 right-4 z-50 space-y-2">
    <div v-for="t in toasts" :key="t.id" class="rounded-lg px-4 py-3 text-sm shadow-lg max-w-sm"
      :class="t.tipo === 'error' ? 'bg-red-600 text-white' : 'bg-primario-700 text-white'">{{ t.texto }}</div>
  </div>
</template>
