import axios from 'axios'

const api = axios.create({ baseURL: '/api' })

api.interceptors.request.use((cfg) => {
  const t = localStorage.getItem('token')
  if (t) cfg.headers.Authorization = `Bearer ${t}`
  return cfg
})

api.interceptors.response.use(
  (r) => r,
  (e) => {
    const status = e.response?.status
    if (status === 401 && !e.config.url.includes('/auth/login')) {
      localStorage.removeItem('token')
      if (location.pathname !== '/login') location.href = '/login'
    }
    e.mensaje = e.response?.data?.error || 'No se pudo conectar con el servidor'
    return Promise.reject(e)
  }
)

export const bs = (n) => 'Bs ' + Number(n || 0).toLocaleString('es-BO', { minimumFractionDigits: 2, maximumFractionDigits: 2 })
export const fecha = (s) => (s ? String(s).replace('T', ' ').slice(0, 16) : '')
export default api
