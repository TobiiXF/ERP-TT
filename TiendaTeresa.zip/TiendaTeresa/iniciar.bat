@echo off
chcp 65001 >nul
title TiendaTeresa - NO CIERRES ESTA VENTANA
cd /d "%~dp0backend"
if not exist ".env" (
  echo Primero ejecuta instalar.bat
  pause
  exit /b 1
)
echo.
echo TiendaTeresa se esta iniciando en http://localhost:3000
echo Mientras uses el sistema, deja esta ventana abierta. Para apagarlo, cierrala.
echo.
start "" cmd /c "timeout /t 3 >nul & start http://localhost:3000"
node src\index.js
pause
