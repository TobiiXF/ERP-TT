-- =====================================================================
-- TiendaTeresa (Ferretería / Pernería) - Esquema PostgreSQL
-- Generado a partir de "notas, avance.docx" (sección 8: Modelo de datos)
-- =====================================================================
BEGIN;

CREATE EXTENSION IF NOT EXISTS pgcrypto;

-- Zona horaria de Bolivia (CURRENT_DATE / NOW() correctos para tasas y caja del día)
DO $$ BEGIN
  EXECUTE format('ALTER DATABASE %I SET timezone TO %L', current_database(), 'America/La_Paz');
END $$;
SET timezone TO 'America/La_Paz';

-- ---------------------------------------------------------------------
-- ENUMS
-- ---------------------------------------------------------------------
CREATE TYPE estado_usuario        AS ENUM ('ACTIVO','INACTIVO','BLOQUEADO');
CREATE TYPE estado_sucursal       AS ENUM ('ACTIVA','INACTIVA');
CREATE TYPE accion_auditoria      AS ENUM ('CREAR','EDITAR','ANULAR','ELIMINAR','LOGIN','LOGOUT','LOGIN_FALLIDO','RESET_PASSWORD');
CREATE TYPE tipo_tasa             AS ENUM ('BCB','PARALELO');
CREATE TYPE fuente_tasa           AS ENUM ('API','MANUAL');
CREATE TYPE tipo_cambio_pref      AS ENUM ('BCB','PARALELO','DEFECTO_SISTEMA');
CREATE TYPE estado_activo_fijo    AS ENUM ('ACTIVO','DADO_BAJA','EN_REPARACION');
CREATE TYPE tipo_cuenta           AS ENUM ('ACTIVO','PASIVO','PATRIMONIO','INGRESO','GASTO');
CREATE TYPE estado_asiento        AS ENUM ('REGISTRADO','ANULADO');
CREATE TYPE tipo_mov_caja         AS ENUM ('ENTRADA_VENTA','SALIDA_COMPRA','AJUSTE');
CREATE TYPE tipo_mov_kardex       AS ENUM ('ENTRADA_COMPRA','SALIDA_VENTA','AJUSTE','MERMA','DEVOLUCION');
CREATE TYPE estado_proveedor      AS ENUM ('ACTIVO','INACTIVO');
CREATE TYPE tipo_doc_compra       AS ENUM ('FACTURA','RECIBO','NOTA');
CREATE TYPE metodo_pago_compra    AS ENUM ('EFECTIVO','TRANSFERENCIA');
CREATE TYPE estado_compra         AS ENUM ('PENDIENTE','PAGADA','ANULADA');
CREATE TYPE tipo_doc_venta        AS ENUM ('NOTA_VENTA','FACTURA_PENDIENTE','TICKET');
CREATE TYPE metodo_pago_venta     AS ENUM ('EFECTIVO');
CREATE TYPE estado_venta          AS ENUM ('COMPLETADA','ANULADA');

-- ---------------------------------------------------------------------
-- 2.1 MÓDULO ADMINISTRADOR
-- ---------------------------------------------------------------------
CREATE TABLE sucursales (
    id              SERIAL PRIMARY KEY,
    nombre          VARCHAR(150) NOT NULL,
    direccion       TEXT,
    telefono        VARCHAR(30),
    nit             VARCHAR(30),
    estado          estado_sucursal NOT NULL DEFAULT 'ACTIVA',
    creado_por      INT NOT NULL,
    creado_en       TIMESTAMP NOT NULL DEFAULT NOW(),
    actualizado_por INT NULL,
    actualizado_en  TIMESTAMP NULL
);

CREATE TABLE roles (
    id              SERIAL PRIMARY KEY,
    nombre          VARCHAR(80) NOT NULL UNIQUE,
    descripcion     TEXT,
    es_sistema      BOOLEAN NOT NULL DEFAULT FALSE,   -- TRUE = rol intocable
    creado_por      INT NOT NULL,
    creado_en       TIMESTAMP NOT NULL DEFAULT NOW(),
    actualizado_por INT NULL,
    actualizado_en  TIMESTAMP NULL,
    eliminado_en    TIMESTAMP NULL,
    eliminado_por   INT NULL
);

CREATE TABLE usuarios (
    id                    SERIAL PRIMARY KEY,
    username              VARCHAR(50) NOT NULL UNIQUE,
    nombre_completo       VARCHAR(150) NOT NULL,
    password_hash         VARCHAR(255) NOT NULL,          -- bcrypt
    email                 VARCHAR(150) NULL,              -- [V2]
    rol_id                INT NOT NULL REFERENCES roles(id),
    sucursal_id           INT NOT NULL REFERENCES sucursales(id),
    estado                estado_usuario NOT NULL DEFAULT 'ACTIVO',
    ultimo_acceso         TIMESTAMP NULL,
    debe_cambiar_password BOOLEAN NOT NULL DEFAULT TRUE,
    intentos_fallidos     INTEGER NOT NULL DEFAULT 0,
    fecha_bloqueo         TIMESTAMP NULL,
    foto_url              VARCHAR(255) NULL,              -- [V2]
    telefono              VARCHAR(30) NULL,               -- [V2]
    creado_por            INT NOT NULL,
    creado_en             TIMESTAMP NOT NULL DEFAULT NOW(),
    actualizado_por       INT NULL,
    actualizado_en        TIMESTAMP NULL,
    eliminado_en          TIMESTAMP NULL,
    eliminado_por         INT NULL
);

-- Catálogo de los 8 módulos del sistema (nombre visible y orden del menú)
CREATE TABLE modulos (
    id              SERIAL PRIMARY KEY,
    codigo          VARCHAR(50) NOT NULL UNIQUE,   -- clave usada en permisos.modulo
    nombre          VARCHAR(60) NOT NULL,          -- nombre visible en el ERP
    orden           SMALLINT NOT NULL UNIQUE,
    descripcion     TEXT,
    creado_por      INT NOT NULL,
    creado_en       TIMESTAMP NOT NULL DEFAULT NOW(),
    actualizado_por INT NULL,
    actualizado_en  TIMESTAMP NULL,
    eliminado_en    TIMESTAMP NULL,
    eliminado_por   INT NULL
);

CREATE TABLE permisos (
    id              SERIAL PRIMARY KEY,
    rol_id          INT NOT NULL REFERENCES roles(id),
    modulo          VARCHAR(50) NOT NULL REFERENCES modulos(codigo) ON UPDATE CASCADE,
    accion          VARCHAR(50) NOT NULL,   -- 'ver','crear','editar','anular',...
    creado_por      INT NOT NULL,
    creado_en       TIMESTAMP NOT NULL DEFAULT NOW(),
    actualizado_por INT NULL,
    actualizado_en  TIMESTAMP NULL,
    eliminado_en    TIMESTAMP NULL,
    eliminado_por   INT NULL,
    UNIQUE (rol_id, modulo, accion)
);

CREATE TABLE bitacora_auditoria (
    id                SERIAL PRIMARY KEY,
    usuario_id        INT NULL REFERENCES usuarios(id),   -- NULL si login fallido con usuario inexistente
    tabla_afectada    VARCHAR(80),
    registro_id       INTEGER,
    accion            accion_auditoria NOT NULL,
    datos_anteriores  JSONB,
    datos_nuevos      JSONB,
    fecha_hora        TIMESTAMP NOT NULL DEFAULT NOW(),
    ip_origen         VARCHAR(45)
);

CREATE TABLE tasas_de_cambio (
    id              SERIAL PRIMARY KEY,
    fecha           DATE NOT NULL DEFAULT CURRENT_DATE,
    hora            TIME NOT NULL DEFAULT LOCALTIME,
    tipo            tipo_tasa NOT NULL,
    valor           DECIMAL(10,4) NOT NULL CHECK (valor > 0),
    fuente          fuente_tasa NOT NULL,
    usuario_id      INT NULL REFERENCES usuarios(id),  -- NULL si fue API
    creado_por      INT NOT NULL,
    creado_en       TIMESTAMP NOT NULL DEFAULT NOW(),
    actualizado_por INT NULL,
    actualizado_en  TIMESTAMP NULL
);

CREATE TABLE configuracion_sistema (
    id              SERIAL PRIMARY KEY,
    clave           VARCHAR(80) NOT NULL UNIQUE,
    valor           TEXT,
    descripcion     TEXT,
    creado_por      INT NOT NULL,
    creado_en       TIMESTAMP NOT NULL DEFAULT NOW(),
    actualizado_por INT NULL,
    actualizado_en  TIMESTAMP NULL
);

-- ---------------------------------------------------------------------
-- 2.5 MÓDULO PROVEEDOR (antes que activos_fijos por la FK)
-- ---------------------------------------------------------------------
CREATE TABLE proveedores (
    id                    SERIAL PRIMARY KEY,
    nombre                VARCHAR(150) NOT NULL,
    nit                   VARCHAR(30) NULL,
    contacto              VARCHAR(150),
    telefono              VARCHAR(30),
    email                 VARCHAR(150),
    direccion             TEXT,
    tipo_cambio_preferido tipo_cambio_pref NOT NULL DEFAULT 'DEFECTO_SISTEMA',
    condiciones_pago      TEXT,
    tiempo_entrega_dias   INT NULL,                                    -- [V2]
    calificacion          INT NULL CHECK (calificacion BETWEEN 1 AND 5), -- [V2]
    estado                estado_proveedor NOT NULL DEFAULT 'ACTIVO',
    creado_por            INT NOT NULL,
    creado_en             TIMESTAMP NOT NULL DEFAULT NOW(),
    actualizado_por       INT NULL,
    actualizado_en        TIMESTAMP NULL,
    eliminado_en          TIMESTAMP NULL,
    eliminado_por         INT NULL
);

-- ---------------------------------------------------------------------
-- 2.2 MÓDULO ACTIVOS FIJOS
-- ---------------------------------------------------------------------
CREATE TABLE activos_fijos (
    id                     SERIAL PRIMARY KEY,
    codigo                 VARCHAR(50) NOT NULL UNIQUE,
    descripcion            VARCHAR(255) NOT NULL,
    categoria              VARCHAR(80),             -- 'Computadora','Mobiliario','Vehículo'
    fecha_adquisicion      DATE NOT NULL,
    costo_adquisicion_bob  DECIMAL(10,2) NOT NULL CHECK (costo_adquisicion_bob >= 0),
    vida_util_anios        INTEGER NOT NULL CHECK (vida_util_anios > 0),
    depreciacion_anual_bob DECIMAL(10,2) GENERATED ALWAYS AS (ROUND(costo_adquisicion_bob / vida_util_anios, 2)) STORED,
    ubicacion              VARCHAR(150),
    numero_serie           VARCHAR(100) NULL,                     -- [V2]
    proveedor_id           INT NULL REFERENCES proveedores(id),   -- [V2]
    estado                 estado_activo_fijo NOT NULL DEFAULT 'ACTIVO',
    sucursal_id            INT NOT NULL REFERENCES sucursales(id),
    creado_por             INT NOT NULL,
    creado_en              TIMESTAMP NOT NULL DEFAULT NOW(),
    actualizado_por        INT NULL,
    actualizado_en         TIMESTAMP NULL,
    eliminado_en           TIMESTAMP NULL,
    eliminado_por          INT NULL
);

-- ---------------------------------------------------------------------
-- 2.4 MÓDULO INVENTARIO
-- ---------------------------------------------------------------------
CREATE TABLE categorias (
    id                 SERIAL PRIMARY KEY,
    nombre             VARCHAR(120) NOT NULL,
    descripcion        TEXT,
    categoria_padre_id INT NULL REFERENCES categorias(id),
    creado_por         INT NOT NULL,
    creado_en          TIMESTAMP NOT NULL DEFAULT NOW(),
    actualizado_por    INT NULL,
    actualizado_en     TIMESTAMP NULL,
    eliminado_en       TIMESTAMP NULL,
    eliminado_por      INT NULL
);

CREATE TABLE productos (
    id                    SERIAL PRIMARY KEY,
    codigo                VARCHAR(50) NOT NULL UNIQUE,
    nombre                VARCHAR(200) NOT NULL,
    descripcion           TEXT,
    categoria_id          INT NOT NULL REFERENCES categorias(id),
    es_matricial          BOOLEAN NOT NULL DEFAULT FALSE,
    unidad_base           VARCHAR(30) NOT NULL DEFAULT 'UNIDAD',
    costo_base_usd        DECIMAL(12,4) NOT NULL DEFAULT 0 CHECK (costo_base_usd >= 0),
    margen_ganancia       DECIMAL(5,2) NOT NULL DEFAULT 0,    -- porcentaje, ej 30.00 = 30%
    tipo_cambio_preferido tipo_cambio_pref NOT NULL DEFAULT 'DEFECTO_SISTEMA',
    precio_venta_bob      DECIMAL(10,2) NOT NULL DEFAULT 0,   -- calculado por motor de precios
    stock_actual          DECIMAL(10,2) NOT NULL DEFAULT 0,   -- solo lectura si es_matricial
    stock_minimo          DECIMAL(10,2) NOT NULL DEFAULT 0,
    imagen_url            VARCHAR(255) NULL,                  -- [V2] ruta relativa /uploads/productos/...
    peso_kg               DECIMAL(10,3) NULL,                 -- [V2]
    ubicacion_almacen     VARCHAR(100) NULL,                  -- [V2]
    sucursal_id           INT NOT NULL REFERENCES sucursales(id),
    creado_por            INT NOT NULL,
    creado_en             TIMESTAMP NOT NULL DEFAULT NOW(),
    actualizado_por       INT NULL,
    actualizado_en        TIMESTAMP NULL,
    eliminado_en          TIMESTAMP NULL,
    eliminado_por         INT NULL,
    CONSTRAINT chk_productos_stock_no_negativo CHECK (stock_actual >= 0)
);

CREATE TABLE variantes_productos (
    id               SERIAL PRIMARY KEY,
    producto_id      INT NOT NULL REFERENCES productos(id),
    codigo_variante  VARCHAR(60) NOT NULL UNIQUE,
    eje_x_valor      VARCHAR(50) NOT NULL,   -- ej: Diámetro
    eje_y_valor      VARCHAR(50) NOT NULL,   -- ej: Largo
    costo_usd        DECIMAL(12,4) NOT NULL DEFAULT 0 CHECK (costo_usd >= 0),
    precio_venta_bob DECIMAL(10,2) NOT NULL DEFAULT 0,
    stock_actual     DECIMAL(10,2) NOT NULL DEFAULT 0,
    creado_por       INT NOT NULL,
    creado_en        TIMESTAMP NOT NULL DEFAULT NOW(),
    actualizado_por  INT NULL,
    actualizado_en   TIMESTAMP NULL,
    eliminado_en     TIMESTAMP NULL,
    eliminado_por    INT NULL,
    CONSTRAINT chk_variantes_stock_no_negativo CHECK (stock_actual >= 0),
    UNIQUE (producto_id, eje_x_valor, eje_y_valor)
);

CREATE TABLE unidades_conversion (
    id                SERIAL PRIMARY KEY,
    producto_id       INT NOT NULL REFERENCES productos(id),
    nombre_unidad     VARCHAR(30) NOT NULL,   -- CAJA, PAQUETE, KILO, UNIDAD
    factor_conversion DECIMAL(10,2) NOT NULL CHECK (factor_conversion > 0),
    precio_venta_bob  DECIMAL(10,2) NOT NULL DEFAULT 0,
    creado_por        INT NOT NULL,
    creado_en         TIMESTAMP NOT NULL DEFAULT NOW(),
    actualizado_por   INT NULL,
    actualizado_en    TIMESTAMP NULL,
    UNIQUE (producto_id, nombre_unidad)
);

-- ---------------------------------------------------------------------
-- 2.5 MÓDULO PROVEEDOR - Compras
-- ---------------------------------------------------------------------
CREATE TABLE compras (
    id                   SERIAL PRIMARY KEY,
    numero_compra        VARCHAR(30) NOT NULL UNIQUE,
    proveedor_id         INT NOT NULL REFERENCES proveedores(id),
    fecha_compra         DATE NOT NULL DEFAULT CURRENT_DATE,
    tipo_documento       tipo_doc_compra NOT NULL,
    numero_documento     VARCHAR(50),
    nit_proveedor        VARCHAR(30) NULL,
    subtotal_usd         DECIMAL(12,4) NOT NULL DEFAULT 0 CHECK (subtotal_usd >= 0),
    tasa_cambio_aplicada DECIMAL(10,4) NOT NULL CHECK (tasa_cambio_aplicada > 0),
    total_bob            DECIMAL(10,2) NOT NULL DEFAULT 0 CHECK (total_bob >= 0),
    metodo_pago          metodo_pago_compra NOT NULL DEFAULT 'EFECTIVO',
    flete_bob            DECIMAL(10,2) NULL,   -- [V2]
    impuestos_bob        DECIMAL(10,2) NULL,   -- [V2]
    estado               estado_compra NOT NULL DEFAULT 'PENDIENTE',
    observaciones        TEXT,
    usuario_id           INT NOT NULL REFERENCES usuarios(id),
    sucursal_id          INT NOT NULL REFERENCES sucursales(id),
    creado_por           INT NOT NULL,
    creado_en            TIMESTAMP NOT NULL DEFAULT NOW(),
    actualizado_por      INT NULL,
    actualizado_en       TIMESTAMP NULL,
    eliminado_en         TIMESTAMP NULL,
    eliminado_por        INT NULL
);

CREATE TABLE detalle_compras (
    id                 SERIAL PRIMARY KEY,
    compra_id          INT NOT NULL REFERENCES compras(id),
    producto_id        INT NOT NULL REFERENCES productos(id),
    variante_id        INT NULL REFERENCES variantes_productos(id),
    cantidad           DECIMAL(10,2) NOT NULL CHECK (cantidad > 0),
    unidad             VARCHAR(30) NOT NULL DEFAULT 'UNIDAD',
    costo_unitario_usd DECIMAL(12,4) NOT NULL CHECK (costo_unitario_usd >= 0),
    subtotal_usd       DECIMAL(12,4) NOT NULL CHECK (subtotal_usd >= 0),
    creado_por         INT NOT NULL,
    creado_en          TIMESTAMP NOT NULL DEFAULT NOW(),
    actualizado_por    INT NULL,
    actualizado_en     TIMESTAMP NULL
);

-- ---------------------------------------------------------------------
-- 2.6 / 2.7 MÓDULO VENTA / venta
-- ---------------------------------------------------------------------
CREATE TABLE clientes (
    id                 SERIAL PRIMARY KEY,
    nombre             VARCHAR(150) NOT NULL,
    nit                VARCHAR(30) NULL,
    telefono           VARCHAR(30),
    email              VARCHAR(150),
    direccion          TEXT,
    es_generico        BOOLEAN NOT NULL DEFAULT FALSE,
    limite_credito_bob DECIMAL(10,2) NULL,   -- [V2]
    saldo_actual_bob   DECIMAL(10,2) NULL,   -- [V2]
    creado_por         INT NOT NULL,
    creado_en          TIMESTAMP NOT NULL DEFAULT NOW(),
    actualizado_por    INT NULL,
    actualizado_en     TIMESTAMP NULL,
    eliminado_en       TIMESTAMP NULL,
    eliminado_por      INT NULL
);

CREATE TABLE ventas (
    id                     SERIAL PRIMARY KEY,
    numero_venta           VARCHAR(30) NOT NULL UNIQUE,
    cliente_id             INT NOT NULL REFERENCES clientes(id),
    fecha_venta            TIMESTAMP NOT NULL DEFAULT NOW(),
    tipo_documento         tipo_doc_venta NOT NULL DEFAULT 'NOTA_VENTA',
    datos_facturacion      JSONB NULL,
    numero_factura_fiscal  VARCHAR(50) NULL,    -- [V2]
    codigo_control_fiscal  VARCHAR(100) NULL,   -- [V2]
    subtotal_bob           DECIMAL(10,2) NOT NULL DEFAULT 0,
    descuento_bob          DECIMAL(10,2) NOT NULL DEFAULT 0,
    total_bob              DECIMAL(10,2) NOT NULL DEFAULT 0,
    metodo_pago            metodo_pago_venta NOT NULL DEFAULT 'EFECTIVO',
    monto_recibido         DECIMAL(10,2) NOT NULL DEFAULT 0,
    cambio_devuelto        DECIMAL(10,2) NOT NULL DEFAULT 0,
    estado                 estado_venta NOT NULL DEFAULT 'COMPLETADA',
    observaciones          TEXT,
    cajero_id              INT NOT NULL REFERENCES usuarios(id),
    sucursal_id            INT NOT NULL REFERENCES sucursales(id),
    creado_por             INT NOT NULL,
    creado_en              TIMESTAMP NOT NULL DEFAULT NOW(),
    actualizado_por        INT NULL,
    actualizado_en         TIMESTAMP NULL,
    eliminado_en           TIMESTAMP NULL,
    eliminado_por          INT NULL,
    CONSTRAINT chk_ventas_montos CHECK (subtotal_bob >= 0 AND descuento_bob >= 0 AND total_bob >= 0
                                        AND monto_recibido >= 0 AND cambio_devuelto >= 0)
);

CREATE TABLE detalle_ventas (
    id                  SERIAL PRIMARY KEY,
    venta_id            INT NOT NULL REFERENCES ventas(id),
    producto_id         INT NOT NULL REFERENCES productos(id),
    variante_id         INT NULL REFERENCES variantes_productos(id),
    cantidad            DECIMAL(10,2) NOT NULL CHECK (cantidad > 0),
    unidad              VARCHAR(30) NOT NULL DEFAULT 'UNIDAD',
    precio_unitario_bob DECIMAL(10,2) NOT NULL CHECK (precio_unitario_bob >= 0),
    descuento_bob       DECIMAL(10,2) NOT NULL DEFAULT 0 CHECK (descuento_bob >= 0),
    subtotal_bob        DECIMAL(10,2) NOT NULL CHECK (subtotal_bob >= 0),
    creado_por          INT NOT NULL,
    creado_en           TIMESTAMP NOT NULL DEFAULT NOW(),
    actualizado_por     INT NULL,
    actualizado_en      TIMESTAMP NULL
);

-- ---------------------------------------------------------------------
-- 2.3 MÓDULO CONTABILIDAD (+ CAJA)
-- ---------------------------------------------------------------------
CREATE TABLE plan_cuentas (
    id              SERIAL PRIMARY KEY,
    codigo          VARCHAR(30) NOT NULL UNIQUE,
    nombre          VARCHAR(150) NOT NULL,
    tipo            tipo_cuenta NOT NULL,
    cuenta_padre_id INT NULL REFERENCES plan_cuentas(id),
    creado_por      INT NOT NULL,
    creado_en       TIMESTAMP NOT NULL DEFAULT NOW(),
    actualizado_por INT NULL,
    actualizado_en  TIMESTAMP NULL,
    eliminado_en    TIMESTAMP NULL,
    eliminado_por   INT NULL
);

CREATE TABLE asientos_contables (
    id               SERIAL PRIMARY KEY,
    fecha            DATE NOT NULL DEFAULT CURRENT_DATE,
    descripcion      TEXT,
    documento_origen VARCHAR(50),                           -- 'VENTA-123','COMPRA-456'
    venta_id         INT NULL REFERENCES ventas(id),        -- [V2]
    compra_id        INT NULL REFERENCES compras(id),       -- [V2]
    activo_fijo_id   INT NULL REFERENCES activos_fijos(id), -- [V2]
    total_debe       DECIMAL(10,2) NOT NULL DEFAULT 0,
    total_haber      DECIMAL(10,2) NOT NULL DEFAULT 0,
    estado           estado_asiento NOT NULL DEFAULT 'REGISTRADO',
    usuario_id       INT NOT NULL REFERENCES usuarios(id),
    creado_por       INT NOT NULL,
    creado_en        TIMESTAMP NOT NULL DEFAULT NOW(),
    actualizado_por  INT NULL,
    actualizado_en   TIMESTAMP NULL,
    eliminado_en     TIMESTAMP NULL,
    eliminado_por    INT NULL
);

CREATE TABLE detalle_asientos (
    id              SERIAL PRIMARY KEY,
    asiento_id      INT NOT NULL REFERENCES asientos_contables(id),
    cuenta_id       INT NOT NULL REFERENCES plan_cuentas(id),
    debe            DECIMAL(10,2) NOT NULL DEFAULT 0 CHECK (debe >= 0),
    haber           DECIMAL(10,2) NOT NULL DEFAULT 0 CHECK (haber >= 0),
    descripcion     TEXT,
    creado_por      INT NOT NULL,
    creado_en       TIMESTAMP NOT NULL DEFAULT NOW(),
    actualizado_por INT NULL,
    actualizado_en  TIMESTAMP NULL,
    eliminado_en    TIMESTAMP NULL,
    eliminado_por   INT NULL
);

CREATE TABLE caja (
    id                   SERIAL PRIMARY KEY,
    tipo_movimiento      tipo_mov_caja NOT NULL,
    monto_bob            DECIMAL(10,2) NOT NULL,
    descripcion          TEXT,
    documento_referencia VARCHAR(50),
    venta_id             INT NULL REFERENCES ventas(id),
    compra_id            INT NULL REFERENCES compras(id),
    saldo_anterior_bob   DECIMAL(10,2) NULL,   -- [V2]
    saldo_actual_bob     DECIMAL(10,2) NULL,   -- [V2]
    usuario_id           INT NOT NULL REFERENCES usuarios(id),
    sucursal_id          INT NOT NULL REFERENCES sucursales(id),
    fecha_hora           TIMESTAMP NOT NULL DEFAULT NOW(),
    creado_por           INT NOT NULL,
    creado_en            TIMESTAMP NOT NULL DEFAULT NOW(),
    actualizado_por      INT NULL,
    actualizado_en       TIMESTAMP NULL
);

CREATE TABLE kardex_inventario (
    id                   SERIAL PRIMARY KEY,
    producto_id          INT NOT NULL REFERENCES productos(id),
    variante_id          INT NULL REFERENCES variantes_productos(id),
    tipo_movimiento      tipo_mov_kardex NOT NULL,
    cantidad             DECIMAL(10,2) NOT NULL,
    stock_anterior       DECIMAL(10,2) NOT NULL,
    stock_nuevo          DECIMAL(10,2) NOT NULL CHECK (stock_nuevo >= 0),
    costo_unitario_usd   DECIMAL(12,4),
    documento_referencia VARCHAR(50),
    venta_id             INT NULL REFERENCES ventas(id),
    compra_id            INT NULL REFERENCES compras(id),
    caja_id              INT NULL REFERENCES caja(id),   -- [V2]
    usuario_id           INT NOT NULL REFERENCES usuarios(id),
    sucursal_id          INT NOT NULL REFERENCES sucursales(id),
    fecha_hora           TIMESTAMP NOT NULL DEFAULT NOW(),
    creado_por           INT NOT NULL,
    creado_en            TIMESTAMP NOT NULL DEFAULT NOW(),
    actualizado_por      INT NULL,
    actualizado_en       TIMESTAMP NULL,
    eliminado_en         TIMESTAMP NULL,
    eliminado_por        INT NULL
);

-- ---------------------------------------------------------------------
-- FKs de auditoría (creado_por / actualizado_por / eliminado_por -> usuarios)
-- DEFERRABLE para poder sembrar el primer usuario dentro de una transacción.
-- ---------------------------------------------------------------------
DO $$
DECLARE t TEXT; c TEXT;
BEGIN
  FOR t, c IN
    SELECT table_name, column_name FROM information_schema.columns
    WHERE table_schema = 'public'
      AND column_name IN ('creado_por','actualizado_por','eliminado_por')
  LOOP
    EXECUTE format(
      'ALTER TABLE %I ADD CONSTRAINT %I FOREIGN KEY (%I) REFERENCES usuarios(id) DEFERRABLE INITIALLY DEFERRED',
      t, 'fk_' || t || '_' || c, c);
  END LOOP;
END $$;

-- ---------------------------------------------------------------------
-- ÍNDICES
-- ---------------------------------------------------------------------
CREATE INDEX idx_usuarios_rol            ON usuarios(rol_id);
CREATE INDEX idx_permisos_rol            ON permisos(rol_id);
CREATE INDEX idx_bitacora_tabla_registro ON bitacora_auditoria(tabla_afectada, registro_id);
CREATE INDEX idx_bitacora_usuario_fecha  ON bitacora_auditoria(usuario_id, fecha_hora);
CREATE INDEX idx_tasas_tipo_fecha        ON tasas_de_cambio(tipo, fecha DESC, hora DESC);
CREATE INDEX idx_productos_categoria     ON productos(categoria_id);
CREATE INDEX idx_productos_nombre        ON productos(nombre);
CREATE INDEX idx_variantes_producto      ON variantes_productos(producto_id);
CREATE INDEX idx_unidades_producto       ON unidades_conversion(producto_id);
CREATE INDEX idx_kardex_producto_fecha   ON kardex_inventario(producto_id, fecha_hora);
CREATE INDEX idx_compras_proveedor       ON compras(proveedor_id);
CREATE INDEX idx_detalle_compras_compra  ON detalle_compras(compra_id);
CREATE INDEX idx_ventas_cliente          ON ventas(cliente_id);
CREATE INDEX idx_ventas_cajero_fecha     ON ventas(cajero_id, fecha_venta);
CREATE INDEX idx_detalle_ventas_venta    ON detalle_ventas(venta_id);
CREATE INDEX idx_detalle_ventas_producto ON detalle_ventas(producto_id);
CREATE INDEX idx_caja_fecha              ON caja(sucursal_id, fecha_hora);
CREATE INDEX idx_detalle_asientos_asiento ON detalle_asientos(asiento_id);

COMMIT;
-- =====================================================================
-- Reglas de oro: triggers, funciones y vistas de reportes
-- =====================================================================
BEGIN;

-- ---------------------------------------------------------------------
-- 3.1 Soft delete obligatorio: se prohíbe el DELETE físico en todas las tablas
-- ---------------------------------------------------------------------
CREATE OR REPLACE FUNCTION fn_prohibir_delete() RETURNS trigger AS $$
BEGIN
  RAISE EXCEPTION 'DELETE físico prohibido en "%". Use soft delete (eliminado_en / estado).', TG_TABLE_NAME;
END $$ LANGUAGE plpgsql;

DO $$
DECLARE t TEXT;
BEGIN
  FOR t IN SELECT tablename FROM pg_tables WHERE schemaname = 'public' LOOP
    EXECUTE format('CREATE TRIGGER trg_%s_no_delete BEFORE DELETE ON %I FOR EACH ROW EXECUTE FUNCTION fn_prohibir_delete()', t, t);
  END LOOP;
END $$;

-- La bitácora es inmutable
CREATE OR REPLACE FUNCTION fn_bitacora_inmutable() RETURNS trigger AS $$
BEGIN
  RAISE EXCEPTION 'bitacora_auditoria es inmutable';
END $$ LANGUAGE plpgsql;
CREATE TRIGGER trg_bitacora_no_update BEFORE UPDATE ON bitacora_auditoria
  FOR EACH ROW EXECUTE FUNCTION fn_bitacora_inmutable();

-- ---------------------------------------------------------------------
-- 3.2 Auditoría: actualizado_en automático
-- ---------------------------------------------------------------------
CREATE OR REPLACE FUNCTION fn_set_actualizado_en() RETURNS trigger AS $$
BEGIN
  NEW.actualizado_en := NOW();
  RETURN NEW;
END $$ LANGUAGE plpgsql;

DO $$
DECLARE t TEXT;
BEGIN
  FOR t IN SELECT table_name FROM information_schema.columns
           WHERE table_schema = 'public' AND column_name = 'actualizado_en' LOOP
    EXECUTE format('CREATE TRIGGER trg_%s_actualizado_en BEFORE UPDATE ON %I FOR EACH ROW EXECUTE FUNCTION fn_set_actualizado_en()', t, t);
  END LOOP;
END $$;

-- ---------------------------------------------------------------------
-- 11. Superusuario intocable (roles con es_sistema = TRUE y sus usuarios)
-- ---------------------------------------------------------------------
CREATE OR REPLACE FUNCTION fn_proteger_rol_sistema() RETURNS trigger AS $$
BEGIN
  IF OLD.es_sistema THEN
    RAISE EXCEPTION 'El rol "%" es de sistema y no se puede modificar', OLD.nombre;
  END IF;
  RETURN NEW;
END $$ LANGUAGE plpgsql;
CREATE TRIGGER trg_roles_proteger BEFORE UPDATE ON roles
  FOR EACH ROW EXECUTE FUNCTION fn_proteger_rol_sistema();

CREATE OR REPLACE FUNCTION fn_proteger_usuario_sistema() RETURNS trigger AS $$
BEGIN
  IF EXISTS (SELECT 1 FROM roles r WHERE r.id = OLD.rol_id AND r.es_sistema)
     -- solo se permite registrar login (ultimo_acceso / intentos)
     AND (NEW.username, NEW.password_hash, NEW.rol_id, NEW.estado, NEW.eliminado_en)
         IS DISTINCT FROM (OLD.username, OLD.password_hash, OLD.rol_id, OLD.estado, OLD.eliminado_en) THEN
    RAISE EXCEPTION 'El usuario "%" es de sistema y no se puede modificar', OLD.username;
  END IF;
  IF NEW.rol_id <> OLD.rol_id AND EXISTS (SELECT 1 FROM roles r WHERE r.id = NEW.rol_id AND r.es_sistema) THEN
    RAISE EXCEPTION 'No se puede asignar un rol de sistema';
  END IF;
  RETURN NEW;
END $$ LANGUAGE plpgsql;
CREATE TRIGGER trg_usuarios_proteger BEFORE UPDATE ON usuarios
  FOR EACH ROW EXECUTE FUNCTION fn_proteger_usuario_sistema();

CREATE OR REPLACE FUNCTION fn_proteger_permisos_sistema() RETURNS trigger AS $$
BEGIN
  IF EXISTS (SELECT 1 FROM roles r WHERE r.id = COALESCE(NEW.rol_id, OLD.rol_id) AND r.es_sistema)
     AND current_setting('erp.seed', true) IS DISTINCT FROM 'on' THEN
    RAISE EXCEPTION 'Los permisos de un rol de sistema no se pueden modificar';
  END IF;
  RETURN NEW;
END $$ LANGUAGE plpgsql;
CREATE TRIGGER trg_permisos_proteger BEFORE INSERT OR UPDATE ON permisos
  FOR EACH ROW EXECUTE FUNCTION fn_proteger_permisos_sistema();

-- ---------------------------------------------------------------------
-- 3.5 Stock unificado: productos matriciales = suma de variantes activas
-- ---------------------------------------------------------------------
CREATE OR REPLACE FUNCTION fn_sync_stock_matricial() RETURNS trigger AS $$
BEGIN
  UPDATE productos p
     SET stock_actual = COALESCE((SELECT SUM(v.stock_actual) FROM variantes_productos v
                                   WHERE v.producto_id = p.id AND v.eliminado_en IS NULL), 0)
   WHERE p.id = NEW.producto_id AND p.es_matricial;
  IF TG_OP = 'UPDATE' AND OLD.producto_id <> NEW.producto_id THEN
    UPDATE productos p
       SET stock_actual = COALESCE((SELECT SUM(v.stock_actual) FROM variantes_productos v
                                     WHERE v.producto_id = p.id AND v.eliminado_en IS NULL), 0)
     WHERE p.id = OLD.producto_id AND p.es_matricial;
  END IF;
  RETURN NULL;
END $$ LANGUAGE plpgsql;
CREATE TRIGGER trg_variantes_sync_stock AFTER INSERT OR UPDATE ON variantes_productos
  FOR EACH ROW EXECUTE FUNCTION fn_sync_stock_matricial();

-- productos.stock_actual es solo lectura cuando es_matricial = TRUE
CREATE OR REPLACE FUNCTION fn_stock_matricial_solo_lectura() RETURNS trigger AS $$
BEGIN
  IF NEW.es_matricial THEN
    IF TG_OP = 'INSERT' THEN
      NEW.stock_actual := 0;
    ELSIF NOT OLD.es_matricial THEN
      NEW.stock_actual := COALESCE((SELECT SUM(stock_actual) FROM variantes_productos
                                     WHERE producto_id = NEW.id AND eliminado_en IS NULL), 0);
    ELSIF NEW.stock_actual IS DISTINCT FROM OLD.stock_actual AND pg_trigger_depth() <= 1 THEN
      RAISE EXCEPTION 'El stock del producto matricial "%" es la suma de sus variantes; modifique variantes_productos', NEW.codigo;
    END IF;
  END IF;
  RETURN NEW;
END $$ LANGUAGE plpgsql;
CREATE TRIGGER trg_productos_stock_matricial BEFORE INSERT OR UPDATE ON productos
  FOR EACH ROW EXECUTE FUNCTION fn_stock_matricial_solo_lectura();

-- Variantes solo para productos matriciales
CREATE OR REPLACE FUNCTION fn_variante_requiere_matricial() RETURNS trigger AS $$
BEGIN
  IF NOT EXISTS (SELECT 1 FROM productos WHERE id = NEW.producto_id AND es_matricial) THEN
    RAISE EXCEPTION 'El producto % no es matricial (es_matricial = FALSE); no admite variantes', NEW.producto_id;
  END IF;
  RETURN NEW;
END $$ LANGUAGE plpgsql;
CREATE TRIGGER trg_variantes_requiere_matricial BEFORE INSERT ON variantes_productos
  FOR EACH ROW EXECUTE FUNCTION fn_variante_requiere_matricial();

-- ---------------------------------------------------------------------
-- Partida doble: cada asiento REGISTRADO debe cuadrar (debe = haber = totales).
-- Se valida al hacer COMMIT, así se puede insertar cabecera y detalle en la misma transacción.
-- ---------------------------------------------------------------------
CREATE OR REPLACE FUNCTION fn_validar_asiento() RETURNS trigger AS $$
DECLARE
  v_id INT;
  a RECORD; v_debe DECIMAL; v_haber DECIMAL;
BEGIN
  IF TG_TABLE_NAME = 'asientos_contables' THEN
    v_id := NEW.id;
  ELSE
    v_id := NEW.asiento_id;
  END IF;
  SELECT * INTO a FROM asientos_contables WHERE id = v_id;
  IF a.estado <> 'REGISTRADO' OR a.eliminado_en IS NOT NULL THEN RETURN NULL; END IF;
  SELECT COALESCE(SUM(debe),0), COALESCE(SUM(haber),0) INTO v_debe, v_haber
    FROM detalle_asientos WHERE asiento_id = v_id AND eliminado_en IS NULL;
  IF v_debe <> v_haber OR v_debe <> a.total_debe OR v_haber <> a.total_haber THEN
    RAISE EXCEPTION 'Asiento % descuadrado: detalle debe=% haber=%, cabecera debe=% haber=%',
      v_id, v_debe, v_haber, a.total_debe, a.total_haber;
  END IF;
  RETURN NULL;
END $$ LANGUAGE plpgsql;
CREATE CONSTRAINT TRIGGER trg_asientos_cuadre AFTER INSERT OR UPDATE ON asientos_contables
  DEFERRABLE INITIALLY DEFERRED FOR EACH ROW EXECUTE FUNCTION fn_validar_asiento();
CREATE CONSTRAINT TRIGGER trg_detalle_asientos_cuadre AFTER INSERT OR UPDATE ON detalle_asientos
  DEFERRABLE INITIALLY DEFERRED FOR EACH ROW EXECUTE FUNCTION fn_validar_asiento();

-- ---------------------------------------------------------------------
-- 5.1 Motor de precios: tasa activa
-- Última tasa del día -> última disponible -> configuracion 'tasa_defecto'
-- ---------------------------------------------------------------------
CREATE OR REPLACE FUNCTION fn_tasa_activa(p_tipo tipo_cambio_pref DEFAULT 'DEFECTO_SISTEMA')
RETURNS DECIMAL(10,4) AS $$
DECLARE
  v_tipo  tipo_tasa;
  v_valor DECIMAL(10,4);
BEGIN
  -- 3.6 Tasa de cambio obligatoria
  IF NOT EXISTS (SELECT 1 FROM tasas_de_cambio) THEN
    RAISE EXCEPTION 'No hay tasas de cambio registradas. Registre al menos una antes de calcular precios.';
  END IF;

  IF p_tipo = 'DEFECTO_SISTEMA' THEN
    SELECT valor::tipo_tasa INTO v_tipo FROM configuracion_sistema WHERE clave = 'tipo_tasa_sistema';
    v_tipo := COALESCE(v_tipo, 'BCB');
  ELSE
    v_tipo := p_tipo::text::tipo_tasa;
  END IF;

  SELECT valor INTO v_valor FROM tasas_de_cambio
   WHERE tipo = v_tipo AND fecha = CURRENT_DATE
   ORDER BY hora DESC, id DESC LIMIT 1;

  IF v_valor IS NULL THEN
    SELECT valor INTO v_valor FROM tasas_de_cambio
     WHERE tipo = v_tipo ORDER BY fecha DESC, hora DESC, id DESC LIMIT 1;
  END IF;

  IF v_valor IS NULL THEN
    SELECT valor::DECIMAL(10,4) INTO v_valor FROM configuracion_sistema WHERE clave = 'tasa_defecto';
  END IF;

  RETURN v_valor;
END $$ LANGUAGE plpgsql STABLE;

-- 5.4 Redondeo configurable: NINGUNO | MEDIO_BOLIVIANO | ENTERO_SUPERIOR
CREATE OR REPLACE FUNCTION fn_redondear_precio(p_monto DECIMAL) RETURNS DECIMAL(10,2) AS $$
DECLARE v_regla TEXT;
BEGIN
  SELECT valor INTO v_regla FROM configuracion_sistema WHERE clave = 'redondeo_precios';
  RETURN CASE COALESCE(v_regla, 'NINGUNO')
    WHEN 'MEDIO_BOLIVIANO' THEN ROUND(CEIL(p_monto * 2) / 2, 2)
    WHEN 'ENTERO_SUPERIOR' THEN ROUND(CEIL(p_monto), 2)
    ELSE ROUND(p_monto, 2)
  END;
END $$ LANGUAGE plpgsql STABLE;

-- 5.2 Precio Venta (BOB) = (Costo Base USD × Tasa Activa) × (1 + % Margen)
CREATE OR REPLACE FUNCTION fn_calcular_precio(p_costo_usd DECIMAL, p_margen DECIMAL, p_tipo tipo_cambio_pref)
RETURNS DECIMAL(10,2) AS $$
BEGIN
  RETURN fn_redondear_precio(p_costo_usd * fn_tasa_activa(p_tipo) * (1 + p_margen / 100));
END $$ LANGUAGE plpgsql STABLE;

-- 5.3 Recálculo masivo (con auditoría). Devuelve cantidad de registros actualizados.
CREATE OR REPLACE FUNCTION fn_recalcular_precios(p_usuario_id INT, p_ip VARCHAR DEFAULT NULL)
RETURNS INT AS $$
DECLARE
  r RECORD;
  v_nuevo DECIMAL(10,2);
  v_total INT := 0;
BEGIN
  FOR r IN SELECT id, costo_base_usd, margen_ganancia, tipo_cambio_preferido, precio_venta_bob
             FROM productos WHERE eliminado_en IS NULL AND NOT es_matricial LOOP
    v_nuevo := fn_calcular_precio(r.costo_base_usd, r.margen_ganancia, r.tipo_cambio_preferido);
    IF v_nuevo IS DISTINCT FROM r.precio_venta_bob THEN
      UPDATE productos SET precio_venta_bob = v_nuevo, actualizado_por = p_usuario_id WHERE id = r.id;
      INSERT INTO bitacora_auditoria (usuario_id, tabla_afectada, registro_id, accion, datos_anteriores, datos_nuevos, ip_origen)
      VALUES (p_usuario_id, 'productos', r.id, 'EDITAR',
              jsonb_build_object('precio_venta_bob', r.precio_venta_bob),
              jsonb_build_object('precio_venta_bob', v_nuevo, 'motivo', 'RECALCULO_MASIVO'), p_ip);
      v_total := v_total + 1;
    END IF;
  END LOOP;

  FOR r IN SELECT v.id, v.costo_usd, v.precio_venta_bob, p.margen_ganancia, p.tipo_cambio_preferido
             FROM variantes_productos v JOIN productos p ON p.id = v.producto_id
            WHERE v.eliminado_en IS NULL AND p.eliminado_en IS NULL LOOP
    v_nuevo := fn_calcular_precio(r.costo_usd, r.margen_ganancia, r.tipo_cambio_preferido);
    IF v_nuevo IS DISTINCT FROM r.precio_venta_bob THEN
      UPDATE variantes_productos SET precio_venta_bob = v_nuevo, actualizado_por = p_usuario_id WHERE id = r.id;
      INSERT INTO bitacora_auditoria (usuario_id, tabla_afectada, registro_id, accion, datos_anteriores, datos_nuevos, ip_origen)
      VALUES (p_usuario_id, 'variantes_productos', r.id, 'EDITAR',
              jsonb_build_object('precio_venta_bob', r.precio_venta_bob),
              jsonb_build_object('precio_venta_bob', v_nuevo, 'motivo', 'RECALCULO_MASIVO'), p_ip);
      v_total := v_total + 1;
    END IF;
  END LOOP;

  RETURN v_total;
END $$ LANGUAGE plpgsql;

-- ---------------------------------------------------------------------
-- 2.8 MÓDULO REPORTES (solo vistas, sin tablas propias)
-- ---------------------------------------------------------------------
CREATE OR REPLACE VIEW v_stock_actual AS
SELECT p.id AS producto_id, NULL::INT AS variante_id, p.codigo, p.nombre,
       c.nombre AS categoria, p.stock_actual, p.stock_minimo,
       p.costo_base_usd AS costo_usd, p.precio_venta_bob, p.sucursal_id
  FROM productos p JOIN categorias c ON c.id = p.categoria_id
 WHERE p.eliminado_en IS NULL AND NOT p.es_matricial
UNION ALL
SELECT p.id, v.id, v.codigo_variante, p.nombre || ' ' || v.eje_x_valor || ' x ' || v.eje_y_valor,
       c.nombre, v.stock_actual, p.stock_minimo, v.costo_usd, v.precio_venta_bob, p.sucursal_id
  FROM variantes_productos v
  JOIN productos p  ON p.id = v.producto_id
  JOIN categorias c ON c.id = p.categoria_id
 WHERE v.eliminado_en IS NULL AND p.eliminado_en IS NULL;

CREATE OR REPLACE VIEW v_stock_bajo AS
SELECT * FROM v_stock_actual WHERE stock_actual <= stock_minimo;

CREATE OR REPLACE VIEW v_valorizacion_inventario AS
SELECT categoria,
       SUM(stock_actual)                     AS unidades,
       ROUND(SUM(stock_actual * costo_usd), 2) AS valor_costo_usd,
       SUM(stock_actual * precio_venta_bob)  AS valor_venta_bob
  FROM v_stock_actual
 GROUP BY categoria;

CREATE OR REPLACE VIEW v_productos_vendidos AS
SELECT dv.producto_id, dv.variante_id, p.codigo, p.nombre,
       SUM(dv.cantidad) AS cantidad_vendida, SUM(dv.subtotal_bob) AS total_bob
  FROM detalle_ventas dv
  JOIN ventas v    ON v.id = dv.venta_id AND v.estado = 'COMPLETADA' AND v.eliminado_en IS NULL
  JOIN productos p ON p.id = dv.producto_id
 GROUP BY dv.producto_id, dv.variante_id, p.codigo, p.nombre;

CREATE OR REPLACE VIEW v_arqueo_caja AS
SELECT c.sucursal_id, c.usuario_id, u.username, c.fecha_hora::date AS fecha,
       SUM(CASE WHEN c.tipo_movimiento = 'ENTRADA_VENTA' THEN c.monto_bob ELSE 0 END) AS entradas_bob,
       SUM(CASE WHEN c.tipo_movimiento = 'SALIDA_COMPRA' THEN c.monto_bob ELSE 0 END) AS salidas_bob,
       SUM(CASE WHEN c.tipo_movimiento = 'AJUSTE'        THEN c.monto_bob ELSE 0 END) AS ajustes_bob,
       SUM(CASE WHEN c.tipo_movimiento = 'SALIDA_COMPRA' THEN -c.monto_bob ELSE c.monto_bob END) AS saldo_bob
  FROM caja c JOIN usuarios u ON u.id = c.usuario_id
 GROUP BY c.sucursal_id, c.usuario_id, u.username, c.fecha_hora::date;

CREATE OR REPLACE VIEW v_permisos_usuario AS
SELECT u.id AS usuario_id, u.username, r.nombre AS rol, p.modulo, p.accion,
       m.nombre AS modulo_nombre, m.orden AS modulo_orden
  FROM usuarios u
  JOIN roles r    ON r.id = u.rol_id AND r.eliminado_en IS NULL
  JOIN permisos p ON p.rol_id = r.id AND p.eliminado_en IS NULL
  JOIN modulos m  ON m.codigo = p.modulo
 WHERE u.eliminado_en IS NULL AND u.estado = 'ACTIVO';

COMMIT;
-- =====================================================================
-- Datos semilla: sucursal, roles, permisos, usuario admin, configuración
-- Usuario inicial:  admin / 1234   (rol Administrador)
-- =====================================================================
BEGIN;
SET LOCAL erp.seed = 'on';

-- Sucursal principal (creado_por = 1 -> admin; FK diferida hasta COMMIT)
INSERT INTO sucursales (id, nombre, direccion, estado, creado_por)
VALUES (1, 'Casa Matriz', 'Por definir', 'ACTIVA', 1);

-- 4.1 Roles preconfigurados
INSERT INTO roles (id, nombre, descripcion, es_sistema, creado_por) VALUES
 (1, 'Superusuario',    'Rol técnico (El Ing.). Intocable. Sin acceso a datos financieros sensibles.', TRUE,  1),
 (2, 'Administrador',   'Dueño. Control total del sistema.',                                            FALSE, 1),
 (3, 'Jefe de Almacén', 'Inventario y Proveedores. No ve márgenes ni Contabilidad.',                     FALSE, 1),
 (4, 'Contador',        'Contabilidad y Activos Fijos. Solo consulta Inventario y Proveedores.',         FALSE, 1),
 (5, 'Cajero',          'Acceso exclusivo al módulo VENTA (POS) y reporte de su caja.',                  FALSE, 1);

-- Usuario admin / 1234 (hash bcrypt compatible con bcrypt/bcryptjs de Node)
INSERT INTO usuarios (id, username, nombre_completo, password_hash, rol_id, sucursal_id,
                      estado, debe_cambiar_password, creado_por)
VALUES (1, 'admin', 'Administrador', crypt('1234', gen_salt('bf', 10)), 2, 1,
        'ACTIVO', FALSE, 1);

-- 4.3 Permisos granulares (modulo + accion)
-- Los 8 módulos, en el orden del documento
INSERT INTO modulos (codigo, nombre, orden, descripcion, creado_por) VALUES
 ('administrador', 'Administrador', 1, 'Seguridad y configuración: usuarios, roles, tasas, bitácora', 1),
 ('activos_fijos', 'Activos Fijos', 2, 'Registro y depreciación de bienes de la empresa', 1),
 ('contabilidad',  'Contabilidad',  3, 'Plan de cuentas, asientos, estados financieros y submódulo Caja', 1),
 ('inventario',    'Inventario',    4, 'Productos, variantes, stock, kardex y precios', 1),
 ('proveedor',     'Proveedor',     5, 'Proveedores y compras', 1),
 ('venta',         'Venta',         6, 'Administración y auditoría de ventas (consultar, editar, anular)', 1),
 ('VENTA',         'VENTA',         7, 'Punto de venta (POS) del cajero', 1),
 ('reportes',      'Reportes',      8, 'Reportes filtrados por rol', 1);

INSERT INTO permisos (rol_id, modulo, accion, creado_por)
SELECT rol_id, modulo, accion, 1 FROM (VALUES
  -- Superusuario: técnico (usuarios/roles/config), sin datos financieros
  (1,'administrador','ver'),(1,'administrador','crear'),(1,'administrador','editar'),
  (1,'administrador','resetear_password'),(1,'administrador','ver_auditoria'),
  -- Cajero
  (5,'VENTA','cobrar'),(5,'VENTA','consultar_propias'),(5,'reportes','arqueo_propio'),
  -- Jefe de Almacén
  (3,'inventario','ver'),(3,'inventario','crear'),(3,'inventario','editar'),(3,'inventario','anular'),
  (3,'proveedor','ver'),(3,'proveedor','crear'),(3,'proveedor','editar'),(3,'proveedor','anular'),
  (3,'reportes','stock'),(3,'reportes','valorizacion'),(3,'reportes','compras'),(3,'reportes','stock_bajo'),
  -- Contador
  (4,'contabilidad','ver'),(4,'contabilidad','crear'),(4,'contabilidad','editar'),(4,'contabilidad','anular'),
  (4,'contabilidad','caja_ver'),(4,'activos_fijos','ver'),(4,'activos_fijos','crear'),(4,'activos_fijos','editar'),
  (4,'activos_fijos','anular'),(4,'inventario','ver'),(4,'proveedor','ver'),
  (4,'reportes','financieros'),(4,'reportes','activos_fijos'),(4,'reportes','flujo_caja')
) AS t(rol_id, modulo, accion);

-- Administrador: 100% de los módulos
INSERT INTO permisos (rol_id, modulo, accion, creado_por)
SELECT 2, m, a, 1
  FROM unnest(ARRAY['administrador','activos_fijos','contabilidad','inventario','proveedor','venta','VENTA','reportes']) m
 CROSS JOIN unnest(ARRAY['ver','crear','editar','anular']) a
UNION ALL SELECT 2, x.m, x.a, 1 FROM (VALUES
  ('administrador','resetear_password'),('administrador','ver_auditoria'),('administrador','tasas_cambio'),
  ('contabilidad','caja_ver'),('contabilidad','caja_crear'),('contabilidad','caja_editar'),('contabilidad','caja_anular'),
  ('inventario','ver_margenes'),('inventario','recalcular_precios'),
  ('VENTA','cobrar'),('VENTA','consultar_propias'),
  ('venta','consultar'),('venta','ver_auditoria'),
  ('reportes','globales'),('reportes','bitacora')
) AS x(m, a)
ON CONFLICT DO NOTHING;

-- 2.1 Configuración del sistema
INSERT INTO configuracion_sistema (clave, valor, descripcion, creado_por) VALUES
 ('moneda_base',        'BOB',     'Moneda base del sistema', 1),
 ('tasa_defecto',       '6.96',    'Tasa por defecto (USD->BOB) si no hay tasas registradas del tipo solicitado', 1),
 ('tipo_tasa_sistema',  'BCB',     'Tipo de tasa usado cuando un producto/proveedor tiene DEFECTO_SISTEMA (BCB | PARALELO)', 1),
 ('redondeo_precios',   'MEDIO_BOLIVIANO', 'Regla de redondeo: NINGUNO | MEDIO_BOLIVIANO | ENTERO_SUPERIOR', 1),
 ('max_intentos_login', '5',       'Intentos fallidos antes de BLOQUEAR al usuario', 1),
 ('nombre_empresa',     'TiendaTeresa', 'Nombre comercial', 1);

-- 3.6 Al menos una tasa registrada
INSERT INTO tasas_de_cambio (tipo, valor, fuente, usuario_id, creado_por)
VALUES ('BCB', 6.9600, 'MANUAL', 1, 1);

-- 7.2 Cliente genérico
INSERT INTO clientes (nombre, nit, es_generico, creado_por)
VALUES ('Público General', '0', TRUE, 1);

-- Categoría inicial
INSERT INTO categorias (nombre, descripcion, creado_por)
VALUES ('General', 'Categoría por defecto', 1);

-- Plan de cuentas básico (para asientos automáticos de compra/venta)
INSERT INTO plan_cuentas (id, codigo, nombre, tipo, cuenta_padre_id, creado_por) VALUES
 (1,  '1',       'ACTIVO',                 'ACTIVO',     NULL, 1),
 (2,  '1.1',     'Activo Corriente',       'ACTIVO',     1,    1),
 (3,  '1.1.01',  'Caja',                   'ACTIVO',     2,    1),
 (4,  '1.1.02',  'Inventario de Mercadería','ACTIVO',    2,    1),
 (5,  '1.2',     'Activo No Corriente',    'ACTIVO',     1,    1),
 (6,  '1.2.01',  'Activos Fijos',          'ACTIVO',     5,    1),
 (7,  '1.2.02',  'Depreciación Acumulada', 'ACTIVO',     5,    1),
 (8,  '2',       'PASIVO',                 'PASIVO',     NULL, 1),
 (9,  '2.1.01',  'Cuentas por Pagar',      'PASIVO',     8,    1),
 (10, '3',       'PATRIMONIO',             'PATRIMONIO', NULL, 1),
 (11, '3.1.01',  'Capital',                'PATRIMONIO', 10,   1),
 (12, '4',       'INGRESOS',               'INGRESO',    NULL, 1),
 (13, '4.1.01',  'Ventas',                 'INGRESO',    12,   1),
 (14, '5',       'GASTOS',                 'GASTO',      NULL, 1),
 (15, '5.1.01',  'Costo de Ventas',        'GASTO',      14,   1),
 (16, '5.1.02',  'Gasto por Depreciación', 'GASTO',      14,   1);

-- Ajustar secuencias tras inserts con id explícito
SELECT setval('sucursales_id_seq',   (SELECT MAX(id) FROM sucursales));
SELECT setval('roles_id_seq',        (SELECT MAX(id) FROM roles));
SELECT setval('usuarios_id_seq',     (SELECT MAX(id) FROM usuarios));
SELECT setval('plan_cuentas_id_seq', (SELECT MAX(id) FROM plan_cuentas));

COMMIT;
