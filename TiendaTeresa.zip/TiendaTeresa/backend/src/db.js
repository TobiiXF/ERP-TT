import pg from 'pg';

pg.types.setTypeParser(1700, (v) => (v === null ? null : parseFloat(v))); // NUMERIC -> number
pg.types.setTypeParser(20, (v) => parseInt(v, 10)); // BIGINT (count) -> number
pg.types.setTypeParser(1082, (v) => v); // DATE -> 'YYYY-MM-DD' (sin corrimiento de zona horaria)
pg.types.setTypeParser(1114, (v) => (v === null ? null : v.replace(' ', 'T'))); // TIMESTAMP -> hora local de Bolivia tal cual

export const pool = new pg.Pool({
  host: process.env.DB_HOST,
  port: Number(process.env.DB_PORT || 5432),
  database: process.env.DB_NAME,
  user: process.env.DB_USER,
  password: process.env.DB_PASSWORD,
});

export const query = (text, params) => pool.query(text, params);

// Ejecuta fn dentro de una transacción atómica: si algo falla se revierte todo.
export async function tx(fn) {
  const client = await pool.connect();
  try {
    await client.query('BEGIN');
    const result = await fn(client);
    await client.query('COMMIT');
    return result;
  } catch (err) {
    await client.query('ROLLBACK');
    throw err;
  } finally {
    client.release();
  }
}
