import { query } from '../db.js';
import { ip } from './http.js';

// Registra en bitacora_auditoria. db puede ser un client de transacción o el pool.
export async function audit(db, req, { tabla, registroId = null, accion, antes = null, despues = null, usuarioId }) {
  const run = db?.query ? db.query.bind(db) : query;
  await run(
    `INSERT INTO bitacora_auditoria (usuario_id, tabla_afectada, registro_id, accion, datos_anteriores, datos_nuevos, ip_origen)
     VALUES ($1,$2,$3,$4,$5,$6,$7)`,
    [usuarioId ?? req.user?.id ?? null, tabla, registroId, accion,
     antes ? JSON.stringify(antes) : null, despues ? JSON.stringify(despues) : null, ip(req)]
  );
}
