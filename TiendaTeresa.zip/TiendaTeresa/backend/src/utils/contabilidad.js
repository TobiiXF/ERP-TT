import { HttpError } from './http.js';

// Genera asiento contable de partida doble + movimiento de caja (dentro de la transacción c).
export async function asientoSimple(c, req, { descripcion, documento, ventaId = null, compraId = null, debeCodigo, haberCodigo, monto }) {
  const { rows: cuentas } = await c.query(`SELECT id, codigo FROM plan_cuentas WHERE codigo = ANY($1) AND eliminado_en IS NULL`, [[debeCodigo, haberCodigo]]);
  const debe = cuentas.find((x) => x.codigo === debeCodigo);
  const haber = cuentas.find((x) => x.codigo === haberCodigo);
  if (!debe || !haber) throw new HttpError(500, `Faltan cuentas ${debeCodigo}/${haberCodigo} en plan_cuentas`);
  const { rows } = await c.query(
    `INSERT INTO asientos_contables (descripcion, documento_origen, venta_id, compra_id, total_debe, total_haber, usuario_id, creado_por)
     VALUES ($1,$2,$3,$4,$5,$5,$6,$6) RETURNING id`, [descripcion, documento, ventaId, compraId, monto, req.user.id]);
  await c.query(
    `INSERT INTO detalle_asientos (asiento_id, cuenta_id, debe, haber, creado_por) VALUES ($1,$2,$4,0,$5), ($1,$3,0,$4,$5)`,
    [rows[0].id, debe.id, haber.id, monto, req.user.id]);
  return rows[0].id;
}

export const CUENTAS = { CAJA: '1.1.01', INVENTARIO: '1.1.02', VENTAS: '4.1.01' };

// Número correlativo por año: V-2026-000001 / C-2026-000001
export async function siguienteNumero(c, tabla, campo, prefijo) {
  await c.query(`SELECT pg_advisory_xact_lock(hashtext($1))`, [tabla]);
  const anio = new Date().getFullYear();
  const pref = `${prefijo}-${anio}-`;
  const { rows } = await c.query(
    `SELECT COALESCE(MAX(SUBSTRING(${campo} FROM ${pref.length + 1})::int), 0) + 1 AS n FROM ${tabla} WHERE ${campo} LIKE $1 || '%'`, [pref]);
  return pref + String(rows[0].n).padStart(6, '0');
}
