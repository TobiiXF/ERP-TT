export class HttpError extends Error {
  constructor(status, message) {
    super(message);
    this.status = status;
  }
}

export const asyncH = (fn) => (req, res, next) => Promise.resolve(fn(req, res, next)).catch(next);

export function errorHandler(err, req, res, _next) {
  if (err.status) return res.status(err.status).json({ error: err.message });
  if (err.code === '23505') return res.status(409).json({ error: 'Ya existe un registro con ese valor único (código/nombre duplicado)' });
  if (err.code === '23514') return res.status(400).json({ error: 'Valor no permitido: ' + (err.constraint?.includes('stock') ? 'stock insuficiente' : err.message) });
  if (err.code === '23503') return res.status(400).json({ error: 'Referencia inválida (registro relacionado no existe)' });
  if (err.code === 'P0001') return res.status(400).json({ error: err.message });
  console.error(err);
  res.status(500).json({ error: 'Error interno del servidor' });
}

export const ip = (req) => (req.headers['x-forwarded-for'] || req.socket.remoteAddress || '').toString().slice(0, 45);
