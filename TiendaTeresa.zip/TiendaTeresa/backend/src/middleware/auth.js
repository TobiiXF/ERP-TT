import jwt from 'jsonwebtoken';
import { query } from '../db.js';
import { HttpError } from '../utils/http.js';

export async function cargarUsuario(id) {
  const { rows } = await query(
    `SELECT u.id, u.username, u.nombre_completo, u.rol_id, r.nombre AS rol, r.es_sistema,
            u.sucursal_id, u.estado, u.debe_cambiar_password
       FROM usuarios u JOIN roles r ON r.id = u.rol_id
      WHERE u.id = $1 AND u.eliminado_en IS NULL`, [id]);
  if (!rows[0]) return null;
  const perms = await query(
    `SELECT modulo, accion FROM permisos WHERE rol_id = $1 AND eliminado_en IS NULL`, [rows[0].rol_id]);
  const modulos = await query(
    `SELECT codigo, nombre, orden FROM modulos WHERE eliminado_en IS NULL ORDER BY orden`);
  return { ...rows[0], permisos: perms.rows.map((p) => `${p.modulo}.${p.accion}`), modulos: modulos.rows };
}

export async function auth(req, _res, next) {
  try {
    const h = req.headers.authorization || '';
    const token = h.startsWith('Bearer ') ? h.slice(7) : null;
    if (!token) throw new HttpError(401, 'No autenticado');
    let payload;
    try {
      payload = jwt.verify(token, process.env.JWT_SECRET);
    } catch {
      throw new HttpError(401, 'Sesión expirada, inicie sesión nuevamente');
    }
    const user = await cargarUsuario(payload.id);
    if (!user || user.estado !== 'ACTIVO') throw new HttpError(401, 'Usuario inactivo o bloqueado');
    req.user = user;
    // Hasta cambiar la contraseña temporal solo puede usar /auth
    if (user.debe_cambiar_password && !req.originalUrl.startsWith('/api/auth')) {
      throw new HttpError(403, 'Debe cambiar su contraseña antes de continuar');
    }
    next();
  } catch (e) {
    next(e);
  }
}

export const tiene = (user, ...perms) => perms.some((p) => user.permisos.includes(p));

// Uso: requiere('inventario.ver') o requiere('venta.consultar', 'VENTA.consultar_propias') (cualquiera)
export const requiere = (...perms) => (req, _res, next) =>
  tiene(req.user, ...perms) ? next() : next(new HttpError(403, 'No tiene permiso para esta acción'));
