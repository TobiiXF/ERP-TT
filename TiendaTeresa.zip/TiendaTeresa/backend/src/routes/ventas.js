import { Router } from 'express';
import { query, tx } from '../db.js';
import { asyncH, HttpError } from '../utils/http.js';
import { audit } from '../utils/audit.js';
import { requiere, tiene } from '../middleware/auth.js';
import { moverStock } from './productos.js';
import { asientoSimple, CUENTAS, siguienteNumero } from '../utils/contabilidad.js';

const r = Router();
const r2 = (n) => Math.round(n * 100) / 100;

// ---------------- POS (módulo VENTA) ----------------
r.get('/pos/productos', requiere('VENTA.cobrar'), asyncH(async (req, res) => {
  const q = `%${(req.query.q || '').trim()}%`;
  const { rows } = await query(
    `SELECT p.id, p.codigo, p.nombre, p.es_matricial, p.unidad_base, p.precio_venta_bob, p.stock_actual, p.imagen_url,
            p.categoria_id, c.nombre AS categoria
       FROM productos p JOIN categorias c ON c.id = p.categoria_id
      WHERE p.eliminado_en IS NULL AND (p.nombre ILIKE $1 OR p.codigo ILIKE $1
            OR EXISTS (SELECT 1 FROM variantes_productos v WHERE v.producto_id = p.id AND v.eliminado_en IS NULL AND v.codigo_variante ILIKE $1))
        AND ($2::int IS NULL OR p.categoria_id = $2)
      ORDER BY p.nombre LIMIT 200`, [q, req.query.categoria_id || null]);
  res.json(rows);
}));

r.get('/pos/productos/:id', requiere('VENTA.cobrar'), asyncH(async (req, res) => {
  const id = Number(req.params.id);
  const { rows } = await query(
    `SELECT id, codigo, nombre, es_matricial, unidad_base, precio_venta_bob, stock_actual, imagen_url FROM productos
      WHERE id = $1 AND eliminado_en IS NULL`, [id]);
  if (!rows[0]) throw new HttpError(404, 'Producto no encontrado');
  const v = await query(
    `SELECT id, codigo_variante, eje_x_valor, eje_y_valor, precio_venta_bob, stock_actual FROM variantes_productos
      WHERE producto_id = $1 AND eliminado_en IS NULL ORDER BY eje_x_valor, eje_y_valor`, [id]);
  const u = await query(`SELECT nombre_unidad, factor_conversion, precio_venta_bob FROM unidades_conversion WHERE producto_id = $1 ORDER BY factor_conversion`, [id]);
  res.json({ ...rows[0], variantes: v.rows, unidades: u.rows });
}));

r.get('/clientes', requiere('VENTA.cobrar', 'venta.consultar'), asyncH(async (req, res) => {
  const q = `%${(req.query.q || '').trim()}%`;
  const { rows } = await query(
    `SELECT id, nombre, nit, telefono, es_generico FROM clientes WHERE eliminado_en IS NULL AND (nombre ILIKE $1 OR nit ILIKE $1)
      ORDER BY es_generico DESC, nombre LIMIT 50`, [q]);
  res.json(rows);
}));

r.post('/clientes', requiere('VENTA.cobrar', 'venta.crear'), asyncH(async (req, res) => {
  const { nombre, nit, telefono, email, direccion } = req.body || {};
  if (!nombre) throw new HttpError(400, 'El nombre es obligatorio');
  const row = await tx(async (c) => {
    const { rows } = await c.query(
      `INSERT INTO clientes (nombre, nit, telefono, email, direccion, creado_por) VALUES ($1,$2,$3,$4,$5,$6) RETURNING *`,
      [nombre.trim(), nit || null, telefono, email, direccion, req.user.id]);
    await audit(c, req, { tabla: 'clientes', registroId: rows[0].id, accion: 'CREAR', despues: rows[0] });
    return rows[0];
  });
  res.status(201).json(row);
}));

// 7.2 Cobrar una venta: atómico (venta + detalle + stock + kardex + caja + asiento)
r.post('/', requiere('VENTA.cobrar'), asyncH(async (req, res) => {
  const b = req.body || {};
  if (!Array.isArray(b.items) || !b.items.length) throw new HttpError(400, 'El carrito está vacío');
  const venta = await tx(async (c) => {
    let clienteId = b.cliente_id;
    if (!clienteId) clienteId = (await c.query(`SELECT id FROM clientes WHERE es_generico AND eliminado_en IS NULL ORDER BY id LIMIT 1`)).rows[0]?.id;
    if (!clienteId) throw new HttpError(400, 'No existe cliente "Público General"');

    const items = [];
    for (const it of b.items) {
      const cantidad = Number(it.cantidad);
      if (!(cantidad > 0)) throw new HttpError(400, 'Cantidad inválida');
      const { rows: p } = await c.query(`SELECT id, nombre, es_matricial, precio_venta_bob, unidad_base FROM productos WHERE id = $1 AND eliminado_en IS NULL`, [it.producto_id]);
      if (!p[0]) throw new HttpError(400, 'Producto inválido');
      let precio = p[0].precio_venta_bob;
      if (p[0].es_matricial) {
        if (!it.variante_id) throw new HttpError(400, `Seleccione la variante de "${p[0].nombre}"`);
        const { rows: v } = await c.query(`SELECT precio_venta_bob FROM variantes_productos WHERE id = $1 AND producto_id = $2 AND eliminado_en IS NULL`, [it.variante_id, it.producto_id]);
        if (!v[0]) throw new HttpError(400, 'Variante inválida');
        precio = v[0].precio_venta_bob;
      }
      let factor = 1;
      const unidad = it.unidad || 'UNIDAD';
      if (unidad !== 'UNIDAD' && unidad !== p[0].unidad_base) {
        const { rows: u } = await c.query(`SELECT factor_conversion, precio_venta_bob FROM unidades_conversion WHERE producto_id = $1 AND nombre_unidad = $2`, [it.producto_id, unidad]);
        if (!u[0]) throw new HttpError(400, `Unidad ${unidad} no configurada`);
        factor = u[0].factor_conversion;
        precio = u[0].precio_venta_bob > 0 ? u[0].precio_venta_bob : r2(precio * factor);
      }
      // El cajero no puede alterar el precio: se toma siempre de la BD
      const descuento = r2(Number(it.descuento_bob || 0));
      const bruto = r2(precio * cantidad);
      if (descuento < 0 || descuento > bruto) throw new HttpError(400, 'Descuento inválido');
      items.push({ producto_id: it.producto_id, variante_id: it.variante_id || null, cantidad, unidad, factor, precio, descuento, subtotal: r2(bruto - descuento) });
    }
    const subtotal = r2(items.reduce((s, i) => s + i.precio * i.cantidad, 0));
    const descuento = r2(items.reduce((s, i) => s + i.descuento, 0));
    const total = r2(subtotal - descuento);
    const recibido = r2(Number(b.monto_recibido ?? total));
    if (recibido < total) throw new HttpError(400, `Monto recibido insuficiente (total: Bs ${total.toFixed(2)})`);
    const numero = await siguienteNumero(c, 'ventas', 'numero_venta', 'V');

    const { rows } = await c.query(
      `INSERT INTO ventas (numero_venta, cliente_id, tipo_documento, datos_facturacion, subtotal_bob, descuento_bob, total_bob,
                           metodo_pago, monto_recibido, cambio_devuelto, estado, observaciones, cajero_id, sucursal_id, creado_por)
       VALUES ($1,$2,$3,$4,$5,$6,$7,'EFECTIVO',$8,$9,'COMPLETADA',$10,$11,$12,$11) RETURNING *`,
      [numero, clienteId, b.tipo_documento || 'NOTA_VENTA', b.datos_facturacion ? JSON.stringify(b.datos_facturacion) : null,
       subtotal, descuento, total, recibido, r2(recibido - total), b.observaciones || null, req.user.id, req.user.sucursal_id]);
    const v = rows[0];
    for (const i of items) {
      await c.query(
        `INSERT INTO detalle_ventas (venta_id, producto_id, variante_id, cantidad, unidad, precio_unitario_bob, descuento_bob, subtotal_bob, creado_por)
         VALUES ($1,$2,$3,$4,$5,$6,$7,$8,$9)`,
        [v.id, i.producto_id, i.variante_id, i.cantidad, i.unidad, i.precio, i.descuento, i.subtotal, req.user.id]);
      await moverStock(c, req, { productoId: i.producto_id, varianteId: i.variante_id, delta: -(i.cantidad * i.factor),
        tipo: 'SALIDA_VENTA', documento: numero, ventaId: v.id });
    }
    await c.query(
      `INSERT INTO caja (tipo_movimiento, monto_bob, descripcion, documento_referencia, venta_id, usuario_id, sucursal_id, creado_por)
       VALUES ('ENTRADA_VENTA',$1,'Venta al contado',$2,$3,$4,$5,$4)`, [total, numero, v.id, req.user.id, req.user.sucursal_id]);
    if (total > 0) {
      await asientoSimple(c, req, { descripcion: `Venta ${numero}`, documento: numero, ventaId: v.id,
        debeCodigo: CUENTAS.CAJA, haberCodigo: CUENTAS.VENTAS, monto: total });
    }
    await audit(c, req, { tabla: 'ventas', registroId: v.id, accion: 'CREAR', despues: { ...v, items } });
    return v;
  });
  res.status(201).json(venta);
}));

// ---------------- Administración (módulo venta) ----------------
r.get('/', requiere('venta.consultar', 'VENTA.consultar_propias'), asyncH(async (req, res) => {
  const soloPropias = !tiene(req.user, 'venta.consultar');
  const { rows } = await query(
    `SELECT v.id, v.numero_venta, v.fecha_venta, v.tipo_documento, v.subtotal_bob, v.descuento_bob, v.total_bob, v.estado,
            cl.nombre AS cliente, u.username AS cajero
       FROM ventas v JOIN clientes cl ON cl.id = v.cliente_id JOIN usuarios u ON u.id = v.cajero_id
      WHERE v.eliminado_en IS NULL
        AND ($1::int IS NULL OR v.cajero_id = $1)
        AND ($2::date IS NULL OR v.fecha_venta::date >= $2) AND ($3::date IS NULL OR v.fecha_venta::date <= $3)
        AND ($4::text IS NULL OR v.estado::text = $4)
        AND ($5::text IS NULL OR v.numero_venta ILIKE '%' || $5 || '%' OR cl.nombre ILIKE '%' || $5 || '%')
      ORDER BY v.id DESC LIMIT 500`,
    [soloPropias ? req.user.id : (req.query.cajero_id || null), req.query.desde || null, req.query.hasta || null,
     req.query.estado || null, req.query.q || null]);
  res.json(rows);
}));

r.get('/:id', requiere('venta.consultar', 'VENTA.consultar_propias'), asyncH(async (req, res) => {
  const id = Number(req.params.id);
  const { rows } = await query(
    `SELECT v.*, cl.nombre AS cliente, cl.nit AS cliente_nit, u.username AS cajero
       FROM ventas v JOIN clientes cl ON cl.id = v.cliente_id JOIN usuarios u ON u.id = v.cajero_id WHERE v.id = $1`, [id]);
  const v = rows[0];
  if (!v) throw new HttpError(404, 'Venta no encontrada');
  if (!tiene(req.user, 'venta.consultar') && v.cajero_id !== req.user.id) throw new HttpError(403, 'Solo puede ver sus propias ventas');
  const det = await query(
    `SELECT d.*, p.codigo, p.nombre, pv.codigo_variante, pv.eje_x_valor, pv.eje_y_valor
       FROM detalle_ventas d JOIN productos p ON p.id = d.producto_id LEFT JOIN variantes_productos pv ON pv.id = d.variante_id
      WHERE d.venta_id = $1 ORDER BY d.id`, [id]);
  let auditoria = [];
  if (tiene(req.user, 'venta.ver_auditoria')) {
    auditoria = (await query(
      `SELECT b.fecha_hora, b.accion, b.datos_anteriores, b.datos_nuevos, u.username FROM bitacora_auditoria b
         LEFT JOIN usuarios u ON u.id = b.usuario_id WHERE b.tabla_afectada = 'ventas' AND b.registro_id = $1 ORDER BY b.id`, [id])).rows;
  }
  res.json({ ...v, detalle: det.rows, auditoria });
}));

// Edición limitada (sin tocar montos): observaciones, tipo de documento y datos de facturación
r.put('/:id', requiere('venta.editar'), asyncH(async (req, res) => {
  const id = Number(req.params.id);
  const out = await tx(async (c) => {
    const { rows: prev } = await c.query(`SELECT * FROM ventas WHERE id = $1 AND eliminado_en IS NULL FOR UPDATE`, [id]);
    if (!prev[0]) throw new HttpError(404, 'Venta no encontrada');
    if (prev[0].estado === 'ANULADA') throw new HttpError(400, 'No se puede editar una venta anulada');
    const { observaciones, tipo_documento, datos_facturacion, cliente_id } = req.body || {};
    const { rows } = await c.query(
      `UPDATE ventas SET observaciones = COALESCE($2, observaciones), tipo_documento = COALESCE($3::tipo_doc_venta, tipo_documento),
              datos_facturacion = COALESCE($4::jsonb, datos_facturacion), cliente_id = COALESCE($5, cliente_id), actualizado_por = $6
        WHERE id = $1 RETURNING *`,
      [id, observaciones ?? null, tipo_documento || null, datos_facturacion ? JSON.stringify(datos_facturacion) : null, cliente_id || null, req.user.id]);
    const campos = ['observaciones', 'tipo_documento', 'datos_facturacion', 'cliente_id'];
    const pick = (o) => Object.fromEntries(campos.map((k) => [k, o[k]]));
    await audit(c, req, { tabla: 'ventas', registroId: id, accion: 'EDITAR', antes: pick(prev[0]), despues: pick(rows[0]) });
    return rows[0];
  });
  res.json(out);
}));

// Anulación (REGLA DE ORO: nunca hard delete) -> devuelve stock, revierte caja y asiento
r.post('/:id/anular', requiere('venta.anular'), asyncH(async (req, res) => {
  const id = Number(req.params.id);
  const motivo = (req.body?.motivo || '').trim();
  if (!motivo) throw new HttpError(400, 'Indique el motivo de anulación');
  await tx(async (c) => {
    const { rows } = await c.query(`SELECT * FROM ventas WHERE id = $1 AND eliminado_en IS NULL FOR UPDATE`, [id]);
    const v = rows[0];
    if (!v) throw new HttpError(404, 'Venta no encontrada');
    if (v.estado === 'ANULADA') throw new HttpError(400, 'La venta ya está anulada');
    const det = await c.query(`SELECT * FROM detalle_ventas WHERE venta_id = $1`, [id]);
    for (const d of det.rows) {
      let factor = 1;
      if (d.unidad !== 'UNIDAD') {
        const u = await c.query(`SELECT factor_conversion FROM unidades_conversion WHERE producto_id = $1 AND nombre_unidad = $2`, [d.producto_id, d.unidad]);
        factor = u.rows[0]?.factor_conversion || 1;
      }
      await moverStock(c, req, { productoId: d.producto_id, varianteId: d.variante_id, delta: d.cantidad * factor,
        tipo: 'DEVOLUCION', documento: `ANULA-${v.numero_venta}`, ventaId: id });
    }
    await c.query(`UPDATE ventas SET estado = 'ANULADA', observaciones = COALESCE(observaciones || ' | ', '') || $2, actualizado_por = $3 WHERE id = $1`,
      [id, `ANULADA: ${motivo}`, req.user.id]);
    await c.query(`UPDATE asientos_contables SET estado = 'ANULADO', actualizado_por = $2 WHERE venta_id = $1`, [id, req.user.id]);
    await c.query(
      `INSERT INTO caja (tipo_movimiento, monto_bob, descripcion, documento_referencia, venta_id, usuario_id, sucursal_id, creado_por)
       VALUES ('AJUSTE',$1,$2,$3,$4,$5,$6,$5)`,
      [-v.total_bob, `Devolución por anulación: ${motivo}`, `ANULA-${v.numero_venta}`, id, req.user.id, req.user.sucursal_id]);
    await audit(c, req, { tabla: 'ventas', registroId: id, accion: 'ANULAR', antes: { estado: v.estado }, despues: { estado: 'ANULADA', motivo } });
  });
  res.json({ ok: true });
}));

export default r;
