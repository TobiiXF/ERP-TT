import { Router } from 'express';
import { query, tx } from '../db.js';
import { asyncH, HttpError } from '../utils/http.js';
import { audit } from '../utils/audit.js';
import { requiere } from '../middleware/auth.js';

const r = Router();
const CAMPOS = ['nombre', 'nit', 'contacto', 'telefono', 'email', 'direccion', 'tipo_cambio_preferido', 'condiciones_pago', 'estado'];

r.get('/', requiere('proveedor.ver'), asyncH(async (_req, res) => {
  const { rows } = await query(`SELECT * FROM proveedores WHERE eliminado_en IS NULL ORDER BY nombre`);
  res.json(rows);
}));

r.post('/', requiere('proveedor.crear'), asyncH(async (req, res) => {
  const b = req.body || {};
  if (!b.nombre) throw new HttpError(400, 'El nombre es obligatorio');
  const row = await tx(async (c) => {
    const { rows } = await c.query(
      `INSERT INTO proveedores (nombre, nit, contacto, telefono, email, direccion, tipo_cambio_preferido, condiciones_pago, creado_por)
       VALUES ($1,$2,$3,$4,$5,$6,COALESCE($7::tipo_cambio_pref,'DEFECTO_SISTEMA'),$8,$9) RETURNING *`,
      [b.nombre, b.nit || null, b.contacto, b.telefono, b.email, b.direccion, b.tipo_cambio_preferido || null, b.condiciones_pago, req.user.id]);
    await audit(c, req, { tabla: 'proveedores', registroId: rows[0].id, accion: 'CREAR', despues: rows[0] });
    return rows[0];
  });
  res.status(201).json(row);
}));

r.put('/:id', requiere('proveedor.editar'), asyncH(async (req, res) => {
  const id = Number(req.params.id);
  const row = await tx(async (c) => {
    const { rows: prev } = await c.query(`SELECT * FROM proveedores WHERE id = $1 AND eliminado_en IS NULL`, [id]);
    if (!prev[0]) throw new HttpError(404, 'Proveedor no encontrado');
    const v = { ...prev[0], ...Object.fromEntries(CAMPOS.filter((k) => k in req.body).map((k) => [k, req.body[k]])) };
    const { rows } = await c.query(
      `UPDATE proveedores SET nombre=$2, nit=$3, contacto=$4, telefono=$5, email=$6, direccion=$7,
              tipo_cambio_preferido=$8, condiciones_pago=$9, estado=$10, actualizado_por=$11 WHERE id=$1 RETURNING *`,
      [id, v.nombre, v.nit || null, v.contacto, v.telefono, v.email, v.direccion, v.tipo_cambio_preferido, v.condiciones_pago, v.estado, req.user.id]);
    await audit(c, req, { tabla: 'proveedores', registroId: id, accion: 'EDITAR', antes: prev[0], despues: rows[0] });
    return rows[0];
  });
  res.json(row);
}));

r.delete('/:id', requiere('proveedor.anular'), asyncH(async (req, res) => {
  const id = Number(req.params.id);
  await tx(async (c) => {
    const { rowCount } = await c.query(
      `UPDATE proveedores SET eliminado_en = NOW(), eliminado_por = $2, estado = 'INACTIVO' WHERE id = $1 AND eliminado_en IS NULL`, [id, req.user.id]);
    if (!rowCount) throw new HttpError(404, 'Proveedor no encontrado');
    await audit(c, req, { tabla: 'proveedores', registroId: id, accion: 'ELIMINAR' });
  });
  res.json({ ok: true });
}));

export default r;
