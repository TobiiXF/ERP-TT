import { Router } from 'express';
import { query, tx } from '../db.js';
import { asyncH, HttpError, ip } from '../utils/http.js';
import { audit } from '../utils/audit.js';
import { requiere } from '../middleware/auth.js';

const r = Router();

r.get('/', asyncH(async (_req, res) => {
  const { rows } = await query(
    `SELECT t.id, t.fecha, to_char(t.hora, 'HH24:MI') AS hora, t.tipo, t.valor, t.fuente, u.username
       FROM tasas_de_cambio t LEFT JOIN usuarios u ON u.id = t.usuario_id
      ORDER BY t.fecha DESC, t.hora DESC, t.id DESC LIMIT 100`);
  res.json(rows);
}));

r.get('/activas', asyncH(async (_req, res) => {
  const { rows } = await query(
    `SELECT fn_tasa_activa('BCB') AS bcb, fn_tasa_activa('PARALELO') AS paralelo, fn_tasa_activa('DEFECTO_SISTEMA') AS sistema`);
  res.json(rows[0]);
}));

r.post('/', requiere('administrador.tasas_cambio'), asyncH(async (req, res) => {
  const { tipo, valor } = req.body || {};
  if (!['BCB', 'PARALELO'].includes(tipo) || !(Number(valor) > 0)) throw new HttpError(400, 'Tipo (BCB/PARALELO) y valor > 0 son obligatorios');
  const row = await tx(async (c) => {
    const { rows } = await c.query(
      `INSERT INTO tasas_de_cambio (tipo, valor, fuente, usuario_id, creado_por) VALUES ($1,$2,'MANUAL',$3,$3) RETURNING *`,
      [tipo, valor, req.user.id]);
    await audit(c, req, { tabla: 'tasas_de_cambio', registroId: rows[0].id, accion: 'CREAR', despues: { tipo, valor } });
    return rows[0];
  });
  res.status(201).json(row);
}));

r.post('/recalcular-precios', requiere('inventario.recalcular_precios'), asyncH(async (req, res) => {
  const { rows } = await query(`SELECT fn_recalcular_precios($1, $2) AS actualizados`, [req.user.id, ip(req)]);
  res.json(rows[0]);
}));

// Configuración del sistema
r.get('/config', asyncH(async (_req, res) => {
  const { rows } = await query(`SELECT clave, valor, descripcion FROM configuracion_sistema ORDER BY id`);
  res.json(rows);
}));

const VALIDOS = {
  redondeo_precios: ['NINGUNO', 'MEDIO_BOLIVIANO', 'ENTERO_SUPERIOR'],
  tipo_tasa_sistema: ['BCB', 'PARALELO'],
};

r.put('/config/:clave', requiere('administrador.editar'), asyncH(async (req, res) => {
  const { clave } = req.params;
  const valor = String(req.body?.valor ?? '').trim();
  if (VALIDOS[clave] && !VALIDOS[clave].includes(valor)) throw new HttpError(400, `Valor inválido. Opciones: ${VALIDOS[clave].join(', ')}`);
  if (['tasa_defecto', 'max_intentos_login'].includes(clave) && !(Number(valor) > 0)) throw new HttpError(400, 'Debe ser un número mayor a 0');
  await tx(async (c) => {
    const { rows } = await c.query(`SELECT valor FROM configuracion_sistema WHERE clave = $1`, [clave]);
    if (!rows[0]) throw new HttpError(404, 'Clave no encontrada');
    await c.query(`UPDATE configuracion_sistema SET valor = $2, actualizado_por = $3 WHERE clave = $1`, [clave, valor, req.user.id]);
    await audit(c, req, { tabla: 'configuracion_sistema', accion: 'EDITAR', antes: { [clave]: rows[0].valor }, despues: { [clave]: valor } });
  });
  res.json({ ok: true });
}));

export default r;
