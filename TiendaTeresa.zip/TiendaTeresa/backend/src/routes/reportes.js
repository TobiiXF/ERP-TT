import { Router } from 'express';
import { query } from '../db.js';
import { asyncH } from '../utils/http.js';
import { requiere, tiene } from '../middleware/auth.js';

const r = Router();

r.get('/dashboard', requiere('reportes.globales', 'reportes.ver'), asyncH(async (req, res) => {
  const desde = req.query.desde || null;
  const hasta = req.query.hasta || null;
  const filtro = `v.estado = 'COMPLETADA' AND v.eliminado_en IS NULL
                  AND ($1::date IS NULL OR v.fecha_venta::date >= $1) AND ($2::date IS NULL OR v.fecha_venta::date <= $2)`;
  const vendidos = await query(
    `SELECT p.id, p.nombre, SUM(d.cantidad) AS cantidad, SUM(d.subtotal_bob) AS total
       FROM detalle_ventas d JOIN ventas v ON v.id = d.venta_id JOIN productos p ON p.id = d.producto_id
      WHERE ${filtro} GROUP BY p.id, p.nombre`, [desde, hasta]);
  const sinVentas = await query(
    `SELECT p.id, p.nombre, 0 AS cantidad, 0 AS total FROM productos p
      WHERE p.eliminado_en IS NULL AND NOT EXISTS (
        SELECT 1 FROM detalle_ventas d JOIN ventas v ON v.id = d.venta_id WHERE d.producto_id = p.id AND ${filtro})
      ORDER BY p.nombre LIMIT 10`, [desde, hasta]);
  const ordenados = [...vendidos.rows].sort((a, b) => b.cantidad - a.cantidad);
  const menos = [...sinVentas.rows, ...[...ordenados].reverse()].slice(0, 10);
  const porDia = await query(
    `SELECT to_char(d::date, 'YYYY-MM-DD') AS dia, COALESCE(SUM(v.total_bob), 0) AS total, count(v.id) AS ventas
       FROM generate_series(CURRENT_DATE - 13, CURRENT_DATE, '1 day') d
       LEFT JOIN ventas v ON v.fecha_venta::date = d::date AND v.estado = 'COMPLETADA' AND v.eliminado_en IS NULL
      GROUP BY d ORDER BY d`);
  const kpi = await query(
    `SELECT
       (SELECT COALESCE(SUM(total_bob),0) FROM ventas WHERE fecha_venta::date = CURRENT_DATE AND estado='COMPLETADA') AS ventas_hoy,
       (SELECT count(*) FROM ventas WHERE fecha_venta::date = CURRENT_DATE AND estado='COMPLETADA') AS num_ventas_hoy,
       (SELECT COALESCE(SUM(total_bob),0) FROM ventas WHERE date_trunc('month', fecha_venta) = date_trunc('month', NOW()) AND estado='COMPLETADA') AS ventas_mes,
       (SELECT count(*) FROM v_stock_bajo) AS stock_bajo,
       (SELECT count(*) FROM productos WHERE eliminado_en IS NULL) AS productos,
       fn_tasa_activa('DEFECTO_SISTEMA') AS tasa`);
  res.json({ kpi: kpi.rows[0], mas_vendidos: ordenados.slice(0, 10), menos_vendidos: menos, ventas_por_dia: porDia.rows });
}));

r.get('/stock', requiere('reportes.stock', 'reportes.globales'), asyncH(async (req, res) => {
  const vista = req.query.bajo === '1' ? 'v_stock_bajo' : 'v_stock_actual';
  const { rows } = await query(`SELECT * FROM ${vista} ORDER BY nombre`);
  res.json(rows);
}));

r.get('/valorizacion', requiere('reportes.valorizacion', 'reportes.globales'), asyncH(async (_req, res) => {
  const { rows } = await query(`SELECT * FROM v_valorizacion_inventario ORDER BY categoria`);
  res.json(rows);
}));

// Arqueo: el cajero solo ve su propio turno
r.get('/arqueo', requiere('reportes.arqueo_propio', 'reportes.flujo_caja', 'reportes.globales', 'contabilidad.caja_ver'), asyncH(async (req, res) => {
  const propio = !tiene(req.user, 'reportes.flujo_caja', 'reportes.globales', 'contabilidad.caja_ver');
  const fecha = req.query.fecha || null;
  const resumen = await query(
    `SELECT * FROM v_arqueo_caja WHERE ($1::int IS NULL OR usuario_id = $1) AND fecha = COALESCE($2::date, CURRENT_DATE) ORDER BY username`,
    [propio ? req.user.id : null, fecha]);
  const movimientos = await query(
    `SELECT c.id, c.fecha_hora, c.tipo_movimiento, c.monto_bob, c.descripcion, c.documento_referencia, u.username
       FROM caja c JOIN usuarios u ON u.id = c.usuario_id
      WHERE ($1::int IS NULL OR c.usuario_id = $1) AND c.fecha_hora::date = COALESCE($2::date, CURRENT_DATE)
      ORDER BY c.id DESC`, [propio ? req.user.id : null, fecha]);
  res.json({ resumen: resumen.rows, movimientos: movimientos.rows });
}));

r.get('/libro-diario', requiere('contabilidad.ver', 'reportes.financieros', 'reportes.globales'), asyncH(async (req, res) => {
  const { rows } = await query(
    `SELECT a.id, a.fecha, a.descripcion, a.documento_origen, a.total_debe, a.total_haber, a.estado, u.username,
            json_agg(json_build_object('codigo', pc.codigo, 'cuenta', pc.nombre, 'debe', d.debe, 'haber', d.haber) ORDER BY d.id) AS lineas
       FROM asientos_contables a
       JOIN usuarios u ON u.id = a.usuario_id
       JOIN detalle_asientos d ON d.asiento_id = a.id AND d.eliminado_en IS NULL
       JOIN plan_cuentas pc ON pc.id = d.cuenta_id
      WHERE a.eliminado_en IS NULL
        AND a.fecha BETWEEN COALESCE($1::date, date_trunc('month', CURRENT_DATE)::date) AND COALESCE($2::date, CURRENT_DATE)
      GROUP BY a.id, u.username
      ORDER BY a.fecha DESC, a.id DESC
      LIMIT 500`, [req.query.desde || null, req.query.hasta || null]);
  res.json(rows);
}));

r.get('/bitacora', requiere('reportes.bitacora', 'administrador.ver_auditoria'), asyncH(async (req, res) => {
  const { rows } = await query(
    `SELECT b.id, b.fecha_hora, b.accion, b.tabla_afectada, b.registro_id, b.datos_anteriores, b.datos_nuevos, b.ip_origen, u.username
       FROM bitacora_auditoria b LEFT JOIN usuarios u ON u.id = b.usuario_id
      WHERE ($1::text IS NULL OR b.tabla_afectada = $1) AND ($2::text IS NULL OR b.accion::text = $2)
      ORDER BY b.id DESC LIMIT 300`, [req.query.tabla || null, req.query.accion || null]);
  res.json(rows);
}));

export default r;
