import { Router } from 'express';
import bcrypt from 'bcryptjs';
import crypto from 'crypto';
import { query, tx } from '../db.js';
import { asyncH, HttpError } from '../utils/http.js';
import { audit } from '../utils/audit.js';
import { requiere } from '../middleware/auth.js';

const r = Router();
const tempPassword = () => crypto.randomBytes(4).toString('hex'); // 8 caracteres

r.get('/roles', requiere('administrador.ver'), asyncH(async (_req, res) => {
  const { rows } = await query(`SELECT id, nombre, descripcion, es_sistema FROM roles WHERE eliminado_en IS NULL ORDER BY id`);
  res.json(rows);
}));

r.get('/sucursales', requiere('administrador.ver'), asyncH(async (_req, res) => {
  const { rows } = await query(`SELECT id, nombre FROM sucursales WHERE estado = 'ACTIVA' ORDER BY id`);
  res.json(rows);
}));

r.get('/', requiere('administrador.ver'), asyncH(async (_req, res) => {
  const { rows } = await query(
    `SELECT u.id, u.username, u.nombre_completo, u.rol_id, r.nombre AS rol, r.es_sistema, u.sucursal_id,
            u.estado, u.ultimo_acceso, u.debe_cambiar_password, u.intentos_fallidos, u.creado_en
       FROM usuarios u JOIN roles r ON r.id = u.rol_id
      WHERE u.eliminado_en IS NULL ORDER BY u.id`);
  res.json(rows);
}));

r.post('/', requiere('administrador.crear'), asyncH(async (req, res) => {
  const { username, nombre_completo, rol_id, sucursal_id = 1 } = req.body || {};
  if (!username || !nombre_completo || !rol_id) throw new HttpError(400, 'Usuario, nombre y rol son obligatorios');
  const temporal = tempPassword();
  const hash = await bcrypt.hash(temporal, 10);
  const user = await tx(async (c) => {
    const { rows: rol } = await c.query(`SELECT es_sistema FROM roles WHERE id = $1`, [rol_id]);
    if (!rol[0]) throw new HttpError(400, 'Rol inválido');
    if (rol[0].es_sistema) throw new HttpError(403, 'No se pueden crear usuarios con rol de sistema');
    const { rows } = await c.query(
      `INSERT INTO usuarios (username, nombre_completo, password_hash, rol_id, sucursal_id, debe_cambiar_password, creado_por)
       VALUES ($1,$2,$3,$4,$5,TRUE,$6) RETURNING id, username, nombre_completo, rol_id, estado`,
      [username.trim(), nombre_completo.trim(), hash, rol_id, sucursal_id, req.user.id]);
    await audit(c, req, { tabla: 'usuarios', registroId: rows[0].id, accion: 'CREAR', despues: rows[0] });
    return rows[0];
  });
  res.status(201).json({ ...user, password_temporal: temporal });
}));

r.put('/:id', requiere('administrador.editar'), asyncH(async (req, res) => {
  const id = Number(req.params.id);
  const { nombre_completo, rol_id, estado } = req.body || {};
  const out = await tx(async (c) => {
    const { rows: prev } = await c.query(`SELECT id, nombre_completo, rol_id, estado FROM usuarios WHERE id = $1 AND eliminado_en IS NULL`, [id]);
    if (!prev[0]) throw new HttpError(404, 'Usuario no encontrado');
    if (id === req.user.id && estado && estado !== 'ACTIVO') throw new HttpError(400, 'No puede desactivarse a sí mismo');
    const { rows } = await c.query(
      `UPDATE usuarios SET nombre_completo = COALESCE($2, nombre_completo), rol_id = COALESCE($3, rol_id),
              estado = COALESCE($4::estado_usuario, estado),
              intentos_fallidos = CASE WHEN $4 = 'ACTIVO' THEN 0 ELSE intentos_fallidos END,
              fecha_bloqueo = CASE WHEN $4 = 'ACTIVO' THEN NULL ELSE fecha_bloqueo END,
              actualizado_por = $5
        WHERE id = $1 RETURNING id, nombre_completo, rol_id, estado`,
      [id, nombre_completo || null, rol_id || null, estado || null, req.user.id]);
    await audit(c, req, { tabla: 'usuarios', registroId: id, accion: 'EDITAR', antes: prev[0], despues: rows[0] });
    return rows[0];
  });
  res.json(out);
}));

r.post('/:id/reset-password', requiere('administrador.resetear_password'), asyncH(async (req, res) => {
  const id = Number(req.params.id);
  const temporal = tempPassword();
  const hash = await bcrypt.hash(temporal, 10);
  await tx(async (c) => {
    const { rowCount } = await c.query(
      `UPDATE usuarios SET password_hash = $2, debe_cambiar_password = TRUE, intentos_fallidos = 0,
              estado = CASE WHEN estado = 'BLOQUEADO' THEN 'ACTIVO'::estado_usuario ELSE estado END,
              fecha_bloqueo = NULL, actualizado_por = $3
        WHERE id = $1 AND eliminado_en IS NULL`, [id, hash, req.user.id]);
    if (!rowCount) throw new HttpError(404, 'Usuario no encontrado');
    await audit(c, req, { tabla: 'usuarios', registroId: id, accion: 'RESET_PASSWORD' });
  });
  res.json({ password_temporal: temporal });
}));

r.delete('/:id', requiere('administrador.anular'), asyncH(async (req, res) => {
  const id = Number(req.params.id);
  if (id === req.user.id) throw new HttpError(400, 'No puede eliminarse a sí mismo');
  await tx(async (c) => {
    const { rowCount } = await c.query(
      `UPDATE usuarios SET eliminado_en = NOW(), eliminado_por = $2, estado = 'INACTIVO' WHERE id = $1 AND eliminado_en IS NULL`,
      [id, req.user.id]);
    if (!rowCount) throw new HttpError(404, 'Usuario no encontrado');
    await audit(c, req, { tabla: 'usuarios', registroId: id, accion: 'ELIMINAR' });
  });
  res.json({ ok: true });
}));

export default r;
