import { Router } from 'express';
import bcrypt from 'bcryptjs';
import jwt from 'jsonwebtoken';
import { query } from '../db.js';
import { asyncH, HttpError } from '../utils/http.js';
import { audit } from '../utils/audit.js';
import { auth, cargarUsuario } from '../middleware/auth.js';

const r = Router();

async function maxIntentos() {
  const { rows } = await query(`SELECT valor FROM configuracion_sistema WHERE clave = 'max_intentos_login'`);
  return Number(rows[0]?.valor || 5);
}

r.post('/login', asyncH(async (req, res) => {
  const { username, password } = req.body || {};
  if (!username || !password) throw new HttpError(400, 'Usuario y contraseña son obligatorios');
  const { rows } = await query(
    `SELECT id, password_hash, estado, intentos_fallidos FROM usuarios WHERE username = $1 AND eliminado_en IS NULL`,
    [username.trim()]);
  const u = rows[0];
  if (!u) {
    await audit(null, req, { tabla: 'usuarios', accion: 'LOGIN_FALLIDO', despues: { username }, usuarioId: null });
    throw new HttpError(401, 'Usuario o contraseña incorrectos');
  }
  if (u.estado === 'BLOQUEADO') throw new HttpError(423, 'Usuario bloqueado por intentos fallidos. Contacte al administrador.');
  if (u.estado !== 'ACTIVO') throw new HttpError(403, 'Usuario inactivo');

  const ok = await bcrypt.compare(password, u.password_hash);
  if (!ok) {
    const intentos = u.intentos_fallidos + 1;
    const bloquear = intentos >= (await maxIntentos());
    await query(
      `UPDATE usuarios SET intentos_fallidos = $2,
              estado = CASE WHEN $3 THEN 'BLOQUEADO'::estado_usuario ELSE estado END,
              fecha_bloqueo = CASE WHEN $3 THEN NOW() ELSE fecha_bloqueo END
        WHERE id = $1`, [u.id, intentos, bloquear]);
    await audit(null, req, { tabla: 'usuarios', registroId: u.id, accion: 'LOGIN_FALLIDO', despues: { intentos, bloqueado: bloquear }, usuarioId: u.id });
    throw new HttpError(401, bloquear ? 'Usuario bloqueado por exceso de intentos' : 'Usuario o contraseña incorrectos');
  }

  await query(`UPDATE usuarios SET intentos_fallidos = 0, ultimo_acceso = NOW() WHERE id = $1`, [u.id]);
  await audit(null, req, { tabla: 'usuarios', registroId: u.id, accion: 'LOGIN', usuarioId: u.id });
  const user = await cargarUsuario(u.id);
  const token = jwt.sign({ id: u.id }, process.env.JWT_SECRET, { expiresIn: process.env.JWT_EXPIRES || '10h' });
  res.json({ token, user });
}));

r.get('/me', auth, (req, res) => res.json(req.user));

r.post('/logout', auth, asyncH(async (req, res) => {
  await audit(null, req, { tabla: 'usuarios', registroId: req.user.id, accion: 'LOGOUT' });
  res.json({ ok: true });
}));

r.post('/cambiar-password', auth, asyncH(async (req, res) => {
  const { actual, nueva } = req.body || {};
  if (!nueva || nueva.length < 4) throw new HttpError(400, 'La nueva contraseña debe tener al menos 4 caracteres');
  const { rows } = await query(`SELECT password_hash FROM usuarios WHERE id = $1`, [req.user.id]);
  if (!(await bcrypt.compare(actual || '', rows[0].password_hash))) throw new HttpError(400, 'La contraseña actual no es correcta');
  if (actual === nueva) throw new HttpError(400, 'La nueva contraseña debe ser distinta a la actual');
  const hash = await bcrypt.hash(nueva, 10);
  await query(
    `UPDATE usuarios SET password_hash = $2, debe_cambiar_password = FALSE, actualizado_por = $1 WHERE id = $1`,
    [req.user.id, hash]);
  await audit(null, req, { tabla: 'usuarios', registroId: req.user.id, accion: 'EDITAR', despues: { cambio_password: true } });
  res.json({ user: await cargarUsuario(req.user.id) });
}));

export default r;
