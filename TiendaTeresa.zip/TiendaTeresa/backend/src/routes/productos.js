import { Router } from 'express';
import multer from 'multer';
import path from 'path';
import fs from 'fs';
import { query, tx } from '../db.js';
import { asyncH, HttpError } from '../utils/http.js';
import { audit } from '../utils/audit.js';
import { requiere, tiene } from '../middleware/auth.js';

const r = Router();

const UPLOADS = path.resolve(process.env.UPLOADS_DIR || 'public/uploads', 'productos');
fs.mkdirSync(UPLOADS, { recursive: true });
const upload = multer({
  storage: multer.diskStorage({
    destination: UPLOADS,
    filename: (_req, file, cb) => cb(null, `${Date.now()}-${Math.round(Math.random() * 1e6)}${path.extname(file.originalname).toLowerCase()}`),
  }),
  limits: { fileSize: 5 * 1024 * 1024 },
  fileFilter: (_req, file, cb) => cb(null, /^image\/(jpeg|png|webp|gif)$/.test(file.mimetype)),
});

// Jefe de Almacén no ve márgenes de ganancia
const ocultarMargen = (req, p) => {
  if (tiene(req.user, 'inventario.ver_margenes')) return p;
  const { margen_ganancia, ...rest } = p;
  return rest;
};

// ---------------- Categorías ----------------
r.get('/categorias', requiere('inventario.ver', 'VENTA.cobrar'), asyncH(async (_req, res) => {
  const { rows } = await query(`SELECT id, nombre, descripcion, categoria_padre_id FROM categorias WHERE eliminado_en IS NULL ORDER BY nombre`);
  res.json(rows);
}));

r.post('/categorias', requiere('inventario.crear'), asyncH(async (req, res) => {
  const { nombre, descripcion, categoria_padre_id } = req.body || {};
  if (!nombre) throw new HttpError(400, 'El nombre es obligatorio');
  const row = await tx(async (c) => {
    const { rows } = await c.query(
      `INSERT INTO categorias (nombre, descripcion, categoria_padre_id, creado_por) VALUES ($1,$2,$3,$4) RETURNING *`,
      [nombre, descripcion, categoria_padre_id || null, req.user.id]);
    await audit(c, req, { tabla: 'categorias', registroId: rows[0].id, accion: 'CREAR', despues: rows[0] });
    return rows[0];
  });
  res.status(201).json(row);
}));

r.delete('/categorias/:id', requiere('inventario.anular'), asyncH(async (req, res) => {
  const id = Number(req.params.id);
  await tx(async (c) => {
    const { rows } = await c.query(`SELECT count(*) AS n FROM productos WHERE categoria_id = $1 AND eliminado_en IS NULL`, [id]);
    if (rows[0].n > 0) throw new HttpError(400, 'La categoría tiene productos activos');
    await c.query(`UPDATE categorias SET eliminado_en = NOW(), eliminado_por = $2 WHERE id = $1`, [id, req.user.id]);
    await audit(c, req, { tabla: 'categorias', registroId: id, accion: 'ELIMINAR' });
  });
  res.json({ ok: true });
}));

// ---------------- Productos ----------------
r.get('/', requiere('inventario.ver'), asyncH(async (req, res) => {
  const q = `%${(req.query.q || '').trim()}%`;
  const { rows } = await query(
    `SELECT p.*, c.nombre AS categoria,
            (SELECT count(*) FROM variantes_productos v WHERE v.producto_id = p.id AND v.eliminado_en IS NULL) AS num_variantes
       FROM productos p JOIN categorias c ON c.id = p.categoria_id
      WHERE p.eliminado_en IS NULL AND (p.nombre ILIKE $1 OR p.codigo ILIKE $1)
        AND ($2::int IS NULL OR p.categoria_id = $2)
      ORDER BY p.nombre LIMIT 500`, [q, req.query.categoria_id || null]);
  res.json(rows.map((p) => ocultarMargen(req, p)));
}));

r.get('/:id', requiere('inventario.ver'), asyncH(async (req, res) => {
  const id = Number(req.params.id);
  const { rows } = await query(
    `SELECT p.*, c.nombre AS categoria FROM productos p JOIN categorias c ON c.id = p.categoria_id
      WHERE p.id = $1 AND p.eliminado_en IS NULL`, [id]);
  if (!rows[0]) throw new HttpError(404, 'Producto no encontrado');
  const variantes = await query(
    `SELECT * FROM variantes_productos WHERE producto_id = $1 AND eliminado_en IS NULL ORDER BY eje_x_valor, eje_y_valor`, [id]);
  const unidades = await query(`SELECT * FROM unidades_conversion WHERE producto_id = $1 ORDER BY factor_conversion`, [id]);
  const kardex = await query(
    `SELECT k.id, k.fecha_hora, k.tipo_movimiento, k.cantidad, k.stock_anterior, k.stock_nuevo, k.documento_referencia,
            v.codigo_variante, u.username
       FROM kardex_inventario k LEFT JOIN variantes_productos v ON v.id = k.variante_id JOIN usuarios u ON u.id = k.usuario_id
      WHERE k.producto_id = $1 ORDER BY k.id DESC LIMIT 50`, [id]);
  res.json({ ...ocultarMargen(req, rows[0]), variantes: variantes.rows, unidades: unidades.rows, kardex: kardex.rows });
}));

const precioDe = async (c, costo, margen, tipo) =>
  (await c.query(`SELECT fn_calcular_precio($1, $2, $3) AS p`, [costo, margen, tipo])).rows[0].p;

r.post('/', requiere('inventario.crear'), asyncH(async (req, res) => {
  const b = req.body || {};
  if (!b.codigo || !b.nombre || !b.categoria_id) throw new HttpError(400, 'Código, nombre y categoría son obligatorios');
  const row = await tx(async (c) => {
    const margen = tiene(req.user, 'inventario.ver_margenes') ? Number(b.margen_ganancia || 0) : 0;
    const tipo = b.tipo_cambio_preferido || 'DEFECTO_SISTEMA';
    const costo = Number(b.costo_base_usd || 0);
    const precio = b.es_matricial ? 0 : await precioDe(c, costo, margen, tipo);
    const { rows } = await c.query(
      `INSERT INTO productos (codigo, nombre, descripcion, categoria_id, es_matricial, unidad_base, costo_base_usd, margen_ganancia,
                              tipo_cambio_preferido, precio_venta_bob, stock_minimo, imagen_url, ubicacion_almacen, sucursal_id, creado_por)
       VALUES ($1,$2,$3,$4,$5,$6,$7,$8,$9,$10,$11,$12,$13,$14,$15) RETURNING *`,
      [b.codigo.trim(), b.nombre.trim(), b.descripcion, b.categoria_id, !!b.es_matricial, b.unidad_base || 'UNIDAD', costo, margen,
       tipo, precio, Number(b.stock_minimo || 0), b.imagen_url || null, b.ubicacion_almacen || null, req.user.sucursal_id, req.user.id]);
    const p = rows[0];
    // Stock inicial (solo productos simples) queda en kardex como AJUSTE
    const inicial = Number(b.stock_inicial || 0);
    if (!p.es_matricial && inicial > 0) {
      await c.query(`UPDATE productos SET stock_actual = $2 WHERE id = $1`, [p.id, inicial]);
      await c.query(
        `INSERT INTO kardex_inventario (producto_id, tipo_movimiento, cantidad, stock_anterior, stock_nuevo, costo_unitario_usd,
                                        documento_referencia, usuario_id, sucursal_id, creado_por)
         VALUES ($1,'AJUSTE',$2,0,$2,$3,'STOCK-INICIAL',$4,$5,$4)`, [p.id, inicial, costo, req.user.id, req.user.sucursal_id]);
      p.stock_actual = inicial;
    }
    await audit(c, req, { tabla: 'productos', registroId: p.id, accion: 'CREAR', despues: p });
    return p;
  });
  res.status(201).json(ocultarMargen(req, row));
}));

r.put('/:id', requiere('inventario.editar'), asyncH(async (req, res) => {
  const id = Number(req.params.id);
  const b = req.body || {};
  const row = await tx(async (c) => {
    const { rows: prev } = await c.query(`SELECT * FROM productos WHERE id = $1 AND eliminado_en IS NULL FOR UPDATE`, [id]);
    if (!prev[0]) throw new HttpError(404, 'Producto no encontrado');
    const o = prev[0];
    const v = {
      codigo: b.codigo ?? o.codigo, nombre: b.nombre ?? o.nombre, descripcion: b.descripcion ?? o.descripcion,
      categoria_id: b.categoria_id ?? o.categoria_id, unidad_base: b.unidad_base ?? o.unidad_base,
      costo_base_usd: Number(b.costo_base_usd ?? o.costo_base_usd),
      margen_ganancia: tiene(req.user, 'inventario.ver_margenes') ? Number(b.margen_ganancia ?? o.margen_ganancia) : o.margen_ganancia,
      tipo_cambio_preferido: b.tipo_cambio_preferido ?? o.tipo_cambio_preferido,
      stock_minimo: Number(b.stock_minimo ?? o.stock_minimo), imagen_url: b.imagen_url !== undefined ? b.imagen_url : o.imagen_url,
      ubicacion_almacen: b.ubicacion_almacen ?? o.ubicacion_almacen,
      es_matricial: b.es_matricial ?? o.es_matricial,
    };
    if (o.es_matricial && !v.es_matricial) {
      const n = (await c.query(`SELECT count(*) AS n FROM variantes_productos WHERE producto_id=$1 AND eliminado_en IS NULL`, [id])).rows[0].n;
      if (n > 0) throw new HttpError(400, 'Elimine primero las variantes para convertirlo en producto simple');
    }
    const precio = v.es_matricial ? o.precio_venta_bob : await precioDe(c, v.costo_base_usd, v.margen_ganancia, v.tipo_cambio_preferido);
    const { rows } = await c.query(
      `UPDATE productos SET codigo=$2, nombre=$3, descripcion=$4, categoria_id=$5, unidad_base=$6, costo_base_usd=$7, margen_ganancia=$8,
              tipo_cambio_preferido=$9, stock_minimo=$10, imagen_url=$11, ubicacion_almacen=$12, es_matricial=$13,
              precio_venta_bob=$14, actualizado_por=$15
        WHERE id=$1 RETURNING *`,
      [id, v.codigo, v.nombre, v.descripcion, v.categoria_id, v.unidad_base, v.costo_base_usd, v.margen_ganancia,
       v.tipo_cambio_preferido, v.stock_minimo, v.imagen_url, v.ubicacion_almacen, v.es_matricial, precio, req.user.id]);
    await audit(c, req, { tabla: 'productos', registroId: id, accion: 'EDITAR', antes: o, despues: rows[0] });
    return rows[0];
  });
  res.json(ocultarMargen(req, row));
}));

r.delete('/:id', requiere('inventario.anular'), asyncH(async (req, res) => {
  const id = Number(req.params.id);
  await tx(async (c) => {
    const { rowCount } = await c.query(
      `UPDATE productos SET eliminado_en = NOW(), eliminado_por = $2 WHERE id = $1 AND eliminado_en IS NULL`, [id, req.user.id]);
    if (!rowCount) throw new HttpError(404, 'Producto no encontrado');
    await audit(c, req, { tabla: 'productos', registroId: id, accion: 'ELIMINAR' });
  });
  res.json({ ok: true });
}));

r.post('/:id/imagen', requiere('inventario.editar'), upload.single('imagen'), asyncH(async (req, res) => {
  if (!req.file) throw new HttpError(400, 'Imagen inválida (jpg, png, webp o gif, máx. 5 MB)');
  const url = `/uploads/productos/${req.file.filename}`;
  const id = Number(req.params.id);
  await tx(async (c) => {
    const { rowCount } = await c.query(`UPDATE productos SET imagen_url = $2, actualizado_por = $3 WHERE id = $1 AND eliminado_en IS NULL`, [id, url, req.user.id]);
    if (!rowCount) throw new HttpError(404, 'Producto no encontrado');
    await audit(c, req, { tabla: 'productos', registroId: id, accion: 'EDITAR', despues: { imagen_url: url } });
  });
  res.json({ imagen_url: url });
}));

// Ajuste manual de stock (AJUSTE / MERMA) -> kardex
r.post('/:id/ajuste', requiere('inventario.editar'), asyncH(async (req, res) => {
  const id = Number(req.params.id);
  const { variante_id, cantidad, tipo = 'AJUSTE', motivo } = req.body || {};
  const cant = Number(cantidad);
  if (!cant) throw new HttpError(400, 'Cantidad inválida');
  if (!['AJUSTE', 'MERMA'].includes(tipo)) throw new HttpError(400, 'Tipo inválido');
  const delta = tipo === 'MERMA' ? -Math.abs(cant) : cant;
  const out = await tx(async (c) => {
    const s = await moverStock(c, req, { productoId: id, varianteId: variante_id || null, delta, tipo, documento: motivo || tipo });
    await audit(c, req, { tabla: variante_id ? 'variantes_productos' : 'productos', registroId: variante_id || id, accion: 'EDITAR',
      antes: { stock: s.anterior }, despues: { stock: s.nuevo, tipo, motivo } });
    return s;
  });
  res.json(out);
}));

// ---------------- Variantes (matriz) ----------------
r.post('/:id/variantes', requiere('inventario.crear'), asyncH(async (req, res) => {
  const id = Number(req.params.id);
  const lista = Array.isArray(req.body) ? req.body : [req.body];
  const out = await tx(async (c) => {
    const { rows: p } = await c.query(`SELECT * FROM productos WHERE id = $1 AND eliminado_en IS NULL`, [id]);
    if (!p[0]) throw new HttpError(404, 'Producto no encontrado');
    if (!p[0].es_matricial) throw new HttpError(400, 'El producto no es matricial');
    const creadas = [];
    for (const v of lista) {
      if (!v.eje_x_valor || !v.eje_y_valor) throw new HttpError(400, 'Eje X y Eje Y son obligatorios');
      const codigo = v.codigo_variante || `${p[0].codigo}-${v.eje_x_valor}-${v.eje_y_valor}`.toUpperCase().replace(/\s+/g, '');
      const costo = Number(v.costo_usd || 0);
      const precio = await precioDe(c, costo, p[0].margen_ganancia, p[0].tipo_cambio_preferido);
      const { rows } = await c.query(
        `INSERT INTO variantes_productos (producto_id, codigo_variante, eje_x_valor, eje_y_valor, costo_usd, precio_venta_bob, creado_por)
         VALUES ($1,$2,$3,$4,$5,$6,$7) RETURNING *`, [id, codigo, v.eje_x_valor, v.eje_y_valor, costo, precio, req.user.id]);
      const inicial = Number(v.stock_inicial || 0);
      if (inicial > 0) await moverStock(c, req, { productoId: id, varianteId: rows[0].id, delta: inicial, tipo: 'AJUSTE', documento: 'STOCK-INICIAL' });
      await audit(c, req, { tabla: 'variantes_productos', registroId: rows[0].id, accion: 'CREAR', despues: rows[0] });
      creadas.push(rows[0]);
    }
    return creadas;
  });
  res.status(201).json(out);
}));

r.put('/:id/variantes/:vid', requiere('inventario.editar'), asyncH(async (req, res) => {
  const vid = Number(req.params.vid);
  const out = await tx(async (c) => {
    const { rows: prev } = await c.query(
      `SELECT v.*, p.margen_ganancia, p.tipo_cambio_preferido FROM variantes_productos v JOIN productos p ON p.id = v.producto_id
        WHERE v.id = $1 AND v.producto_id = $2 AND v.eliminado_en IS NULL`, [vid, Number(req.params.id)]);
    if (!prev[0]) throw new HttpError(404, 'Variante no encontrada');
    const o = prev[0];
    const costo = Number(req.body.costo_usd ?? o.costo_usd);
    const precio = req.body.precio_venta_bob != null ? Number(req.body.precio_venta_bob)
      : await precioDe(c, costo, o.margen_ganancia, o.tipo_cambio_preferido);
    const { rows } = await c.query(
      `UPDATE variantes_productos SET eje_x_valor=$2, eje_y_valor=$3, costo_usd=$4, precio_venta_bob=$5, actualizado_por=$6 WHERE id=$1 RETURNING *`,
      [vid, req.body.eje_x_valor ?? o.eje_x_valor, req.body.eje_y_valor ?? o.eje_y_valor, costo, precio, req.user.id]);
    await audit(c, req, { tabla: 'variantes_productos', registroId: vid, accion: 'EDITAR', antes: o, despues: rows[0] });
    return rows[0];
  });
  res.json(out);
}));

r.delete('/:id/variantes/:vid', requiere('inventario.anular'), asyncH(async (req, res) => {
  const vid = Number(req.params.vid);
  await tx(async (c) => {
    const { rowCount } = await c.query(
      `UPDATE variantes_productos SET eliminado_en = NOW(), eliminado_por = $3 WHERE id = $1 AND producto_id = $2 AND eliminado_en IS NULL`,
      [vid, Number(req.params.id), req.user.id]);
    if (!rowCount) throw new HttpError(404, 'Variante no encontrada');
    await audit(c, req, { tabla: 'variantes_productos', registroId: vid, accion: 'ELIMINAR' });
  });
  res.json({ ok: true });
}));

// ---------------- Unidades de conversión ----------------
r.post('/:id/unidades', requiere('inventario.crear'), asyncH(async (req, res) => {
  const id = Number(req.params.id);
  const { nombre_unidad, factor_conversion, precio_venta_bob } = req.body || {};
  if (!nombre_unidad || !(Number(factor_conversion) > 0)) throw new HttpError(400, 'Unidad y factor (> 0) son obligatorios');
  const row = await tx(async (c) => {
    const { rows } = await c.query(
      `INSERT INTO unidades_conversion (producto_id, nombre_unidad, factor_conversion, precio_venta_bob, creado_por)
       VALUES ($1, UPPER($2), $3, $4, $5) RETURNING *`, [id, nombre_unidad.trim(), factor_conversion, Number(precio_venta_bob || 0), req.user.id]);
    await audit(c, req, { tabla: 'unidades_conversion', registroId: rows[0].id, accion: 'CREAR', despues: rows[0] });
    return rows[0];
  });
  res.status(201).json(row);
}));

r.put('/:id/unidades/:uid', requiere('inventario.editar'), asyncH(async (req, res) => {
  const uid = Number(req.params.uid);
  const row = await tx(async (c) => {
    const { rows: prev } = await c.query(`SELECT * FROM unidades_conversion WHERE id = $1 AND producto_id = $2`, [uid, Number(req.params.id)]);
    if (!prev[0]) throw new HttpError(404, 'Unidad no encontrada');
    const { rows } = await c.query(
      `UPDATE unidades_conversion SET factor_conversion=$2, precio_venta_bob=$3, actualizado_por=$4 WHERE id=$1 RETURNING *`,
      [uid, Number(req.body.factor_conversion ?? prev[0].factor_conversion), Number(req.body.precio_venta_bob ?? prev[0].precio_venta_bob), req.user.id]);
    await audit(c, req, { tabla: 'unidades_conversion', registroId: uid, accion: 'EDITAR', antes: prev[0], despues: rows[0] });
    return rows[0];
  });
  res.json(row);
}));

// ---------------- Helper de stock (usado también por compras/ventas) ----------------
export async function moverStock(c, req, { productoId, varianteId = null, delta, tipo, documento, ventaId = null, compraId = null, costoUsd = null }) {
  let anterior;
  if (varianteId) {
    const { rows } = await c.query(
      `SELECT stock_actual, costo_usd FROM variantes_productos WHERE id = $1 AND producto_id = $2 AND eliminado_en IS NULL FOR UPDATE`,
      [varianteId, productoId]);
    if (!rows[0]) throw new HttpError(400, `Variante ${varianteId} no existe`);
    anterior = rows[0].stock_actual;
    costoUsd ??= rows[0].costo_usd;
  } else {
    const { rows } = await c.query(
      `SELECT stock_actual, costo_base_usd, es_matricial, nombre FROM productos WHERE id = $1 AND eliminado_en IS NULL FOR UPDATE`, [productoId]);
    if (!rows[0]) throw new HttpError(400, `Producto ${productoId} no existe`);
    if (rows[0].es_matricial) throw new HttpError(400, `"${rows[0].nombre}" es matricial: debe indicar la variante`);
    anterior = rows[0].stock_actual;
    costoUsd ??= rows[0].costo_base_usd;
  }
  const nuevo = Math.round((anterior + delta) * 100) / 100;
  if (nuevo < 0) throw new HttpError(400, `Stock insuficiente (disponible: ${anterior})`);
  if (varianteId) await c.query(`UPDATE variantes_productos SET stock_actual = $2, actualizado_por = $3 WHERE id = $1`, [varianteId, nuevo, req.user.id]);
  else await c.query(`UPDATE productos SET stock_actual = $2, actualizado_por = $3 WHERE id = $1`, [productoId, nuevo, req.user.id]);
  await c.query(
    `INSERT INTO kardex_inventario (producto_id, variante_id, tipo_movimiento, cantidad, stock_anterior, stock_nuevo, costo_unitario_usd,
                                    documento_referencia, venta_id, compra_id, usuario_id, sucursal_id, creado_por)
     VALUES ($1,$2,$3,$4,$5,$6,$7,$8,$9,$10,$11,$12,$11)`,
    [productoId, varianteId, tipo, Math.abs(delta), anterior, nuevo, costoUsd, documento, ventaId, compraId, req.user.id, req.user.sucursal_id]);
  return { anterior, nuevo };
}

export default r;
