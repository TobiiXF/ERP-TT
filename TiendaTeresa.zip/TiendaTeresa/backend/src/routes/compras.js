import { Router } from 'express';
import { query, tx } from '../db.js';
import { asyncH, HttpError } from '../utils/http.js';
import { audit } from '../utils/audit.js';
import { requiere } from '../middleware/auth.js';
import { moverStock } from './productos.js';
import { asientoSimple, CUENTAS, siguienteNumero } from '../utils/contabilidad.js';

const r = Router();

r.get('/', requiere('proveedor.ver'), asyncH(async (req, res) => {
  const { rows } = await query(
    `SELECT c.id, c.numero_compra, c.fecha_compra, c.tipo_documento, c.numero_documento, c.subtotal_usd, c.tasa_cambio_aplicada,
            c.total_bob, c.estado, p.nombre AS proveedor, u.username
       FROM compras c JOIN proveedores p ON p.id = c.proveedor_id JOIN usuarios u ON u.id = c.usuario_id
      WHERE c.eliminado_en IS NULL
        AND ($1::date IS NULL OR c.fecha_compra >= $1) AND ($2::date IS NULL OR c.fecha_compra <= $2)
      ORDER BY c.id DESC LIMIT 300`, [req.query.desde || null, req.query.hasta || null]);
  res.json(rows);
}));

r.get('/:id', requiere('proveedor.ver'), asyncH(async (req, res) => {
  const id = Number(req.params.id);
  const { rows } = await query(
    `SELECT c.*, p.nombre AS proveedor, u.username FROM compras c JOIN proveedores p ON p.id = c.proveedor_id
       JOIN usuarios u ON u.id = c.usuario_id WHERE c.id = $1`, [id]);
  if (!rows[0]) throw new HttpError(404, 'Compra no encontrada');
  const det = await query(
    `SELECT d.*, pr.codigo, pr.nombre, v.codigo_variante FROM detalle_compras d JOIN productos pr ON pr.id = d.producto_id
       LEFT JOIN variantes_productos v ON v.id = d.variante_id WHERE d.compra_id = $1 ORDER BY d.id`, [id]);
  res.json({ ...rows[0], detalle: det.rows });
}));

// 7.1 Flujo de compras: todo atómico (compra + detalle + stock + kardex + caja + asiento)
r.post('/', requiere('proveedor.crear'), asyncH(async (req, res) => {
  const b = req.body || {};
  if (!b.proveedor_id || !b.tipo_documento) throw new HttpError(400, 'Proveedor y tipo de documento son obligatorios');
  if (!Array.isArray(b.items) || !b.items.length) throw new HttpError(400, 'Agregue al menos un producto');
  const compra = await tx(async (c) => {
    const { rows: prov } = await c.query(`SELECT * FROM proveedores WHERE id = $1 AND eliminado_en IS NULL`, [b.proveedor_id]);
    if (!prov[0]) throw new HttpError(400, 'Proveedor inválido');
    const tasa = b.tasa_cambio_aplicada && Number(b.tasa_cambio_aplicada) > 0
      ? Number(b.tasa_cambio_aplicada)
      : (await c.query(`SELECT fn_tasa_activa($1) AS t`, [prov[0].tipo_cambio_preferido])).rows[0].t;

    const items = [];
    for (const it of b.items) {
      const cantidad = Number(it.cantidad);
      const costo = Number(it.costo_unitario_usd);
      if (!(cantidad > 0) || !(costo >= 0)) throw new HttpError(400, 'Cantidad y costo inválidos');
      let factor = 1;
      if (it.unidad && it.unidad !== 'UNIDAD') {
        const u = await c.query(`SELECT factor_conversion FROM unidades_conversion WHERE producto_id = $1 AND nombre_unidad = $2`, [it.producto_id, it.unidad]);
        if (!u.rows[0]) throw new HttpError(400, `Unidad ${it.unidad} no configurada para el producto`);
        factor = u.rows[0].factor_conversion;
      }
      items.push({ ...it, cantidad, costo, factor, subtotal: Math.round(cantidad * costo * 10000) / 10000 });
    }
    const subtotalUsd = items.reduce((s, i) => s + i.subtotal, 0);
    const totalBob = Math.round(subtotalUsd * tasa * 100) / 100;
    const numero = await siguienteNumero(c, 'compras', 'numero_compra', 'C');

    const { rows } = await c.query(
      `INSERT INTO compras (numero_compra, proveedor_id, fecha_compra, tipo_documento, numero_documento, nit_proveedor, subtotal_usd,
                            tasa_cambio_aplicada, total_bob, metodo_pago, estado, observaciones, usuario_id, sucursal_id, creado_por)
       VALUES ($1,$2,COALESCE($3::date, CURRENT_DATE),$4,$5,$6,$7,$8,$9,'EFECTIVO','PAGADA',$10,$11,$12,$11) RETURNING *`,
      [numero, b.proveedor_id, b.fecha_compra || null, b.tipo_documento, b.numero_documento || null, prov[0].nit, subtotalUsd, tasa, totalBob,
       b.observaciones || null, req.user.id, req.user.sucursal_id]);
    const comp = rows[0];

    for (const i of items) {
      await c.query(
        `INSERT INTO detalle_compras (compra_id, producto_id, variante_id, cantidad, unidad, costo_unitario_usd, subtotal_usd, creado_por)
         VALUES ($1,$2,$3,$4,$5,$6,$7,$8)`,
        [comp.id, i.producto_id, i.variante_id || null, i.cantidad, i.unidad || 'UNIDAD', i.costo, i.subtotal, req.user.id]);
      await moverStock(c, req, { productoId: i.producto_id, varianteId: i.variante_id || null, delta: i.cantidad * i.factor,
        tipo: 'ENTRADA_COMPRA', documento: numero, compraId: comp.id, costoUsd: i.costo / i.factor });
    }

    await c.query(
      `INSERT INTO caja (tipo_movimiento, monto_bob, descripcion, documento_referencia, compra_id, usuario_id, sucursal_id, creado_por)
       VALUES ('SALIDA_COMPRA',$1,$2,$3,$4,$5,$6,$5)`,
      [totalBob, `Pago a ${prov[0].nombre}`, numero, comp.id, req.user.id, req.user.sucursal_id]);
    await asientoSimple(c, req, { descripcion: `Compra ${numero} - ${prov[0].nombre}`, documento: numero, compraId: comp.id,
      debeCodigo: CUENTAS.INVENTARIO, haberCodigo: CUENTAS.CAJA, monto: totalBob });
    await audit(c, req, { tabla: 'compras', registroId: comp.id, accion: 'CREAR', despues: { ...comp, items } });
    return comp;
  });
  res.status(201).json(compra);
}));

r.post('/:id/anular', requiere('proveedor.anular'), asyncH(async (req, res) => {
  const id = Number(req.params.id);
  const motivo = (req.body?.motivo || '').trim();
  if (!motivo) throw new HttpError(400, 'Indique el motivo de anulación');
  await tx(async (c) => {
    const { rows } = await c.query(`SELECT * FROM compras WHERE id = $1 FOR UPDATE`, [id]);
    const comp = rows[0];
    if (!comp) throw new HttpError(404, 'Compra no encontrada');
    if (comp.estado === 'ANULADA') throw new HttpError(400, 'La compra ya está anulada');
    const det = await c.query(`SELECT * FROM detalle_compras WHERE compra_id = $1`, [id]);
    for (const d of det.rows) {
      let factor = 1;
      if (d.unidad !== 'UNIDAD') {
        const u = await c.query(`SELECT factor_conversion FROM unidades_conversion WHERE producto_id = $1 AND nombre_unidad = $2`, [d.producto_id, d.unidad]);
        factor = u.rows[0]?.factor_conversion || 1;
      }
      await moverStock(c, req, { productoId: d.producto_id, varianteId: d.variante_id, delta: -d.cantidad * factor,
        tipo: 'AJUSTE', documento: `ANULA-${comp.numero_compra}`, compraId: id });
    }
    await c.query(`UPDATE compras SET estado = 'ANULADA', observaciones = COALESCE(observaciones || ' | ', '') || $2, actualizado_por = $3 WHERE id = $1`,
      [id, `ANULADA: ${motivo}`, req.user.id]);
    await c.query(`UPDATE asientos_contables SET estado = 'ANULADO', actualizado_por = $2 WHERE compra_id = $1`, [id, req.user.id]);
    await c.query(
      `INSERT INTO caja (tipo_movimiento, monto_bob, descripcion, documento_referencia, compra_id, usuario_id, sucursal_id, creado_por)
       VALUES ('AJUSTE',$1,$2,$3,$4,$5,$6,$5)`,
      [comp.total_bob, `Reversión por anulación: ${motivo}`, `ANULA-${comp.numero_compra}`, id, req.user.id, req.user.sucursal_id]);
    await audit(c, req, { tabla: 'compras', registroId: id, accion: 'ANULAR', antes: { estado: comp.estado }, despues: { estado: 'ANULADA', motivo } });
  });
  res.json({ ok: true });
}));

export default r;
