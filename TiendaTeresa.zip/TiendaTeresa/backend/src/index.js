import 'dotenv/config';
import express from 'express';
import cors from 'cors';
import path from 'path';
import fs from 'fs';
import { fileURLToPath } from 'url';
import { auth } from './middleware/auth.js';
import { errorHandler } from './utils/http.js';
import authRoutes from './routes/auth.js';
import usuarios from './routes/usuarios.js';
import productos from './routes/productos.js';
import proveedores from './routes/proveedores.js';
import compras from './routes/compras.js';
import ventas from './routes/ventas.js';
import tasas from './routes/tasas.js';
import reportes from './routes/reportes.js';

const __dirname = path.dirname(fileURLToPath(import.meta.url));
const app = express();
app.set('trust proxy', true);
app.use(cors());
app.use(express.json({ limit: '2mb' }));

// Imágenes locales: la BD guarda solo la ruta relativa (/uploads/productos/xxx.jpg)
app.use('/uploads', express.static(path.resolve(process.env.UPLOADS_DIR || 'public/uploads')));

app.get('/api/health', (_req, res) => res.json({ ok: true }));
app.use('/api/auth', authRoutes);
app.use('/api/usuarios', auth, usuarios);
app.use('/api/productos', auth, productos);
app.use('/api/proveedores', auth, proveedores);
app.use('/api/compras', auth, compras);
app.use('/api/ventas', auth, ventas);
app.use('/api/tasas', auth, tasas);
app.use('/api/reportes', auth, reportes);
app.use('/api', (_req, res) => res.status(404).json({ error: 'Ruta no encontrada' }));

// En producción (LAN) el backend sirve también el frontend compilado
const dist = path.resolve(__dirname, '../../frontend/dist');
if (fs.existsSync(dist)) {
  // index.html nunca se cachea: así el navegador siempre toma los archivos de la última compilación
  app.use('/assets', express.static(path.join(dist, 'assets'), { immutable: true, maxAge: '1y' }));
  app.use(express.static(dist, { index: false }));
  app.get('*', (_req, res) => {
    res.set('Cache-Control', 'no-cache, no-store, must-revalidate');
    res.sendFile(path.join(dist, 'index.html'));
  });
}

app.use(errorHandler);

const port = Number(process.env.PORT || 3000);
app.listen(port, process.env.HOST || '0.0.0.0', () => console.log(`TiendaTeresa en http://localhost:${port}`));
